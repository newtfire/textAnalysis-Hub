var networks = {"networkData-2.tsv": {
  "format_version" : "1.0",
  "generated_by" : "cytoscape-3.10.4",
  "target_cytoscapejs_version" : "~2.1",
  "data" : {
    "shared_name" : "networkData-2.tsv",
    "name" : "networkData-2.tsv",
    "SUID" : 30015,
    "__Annotations" : [ "edgeThickness=1.0|canvas=foreground|fillOpacity=100.0|color=-16777216|rotation=0.0|type=org.cytoscape.view.presentation.annotations.BoundedTextAnnotation|fontStyle=0|uuid=fa580009-623d-4ebe-9221-79d93037dfc3|shapeType=RECTANGLE|edgeColor=-8355712|fontFamily=.AppleSystemUIFont|edgeOpacity=100.0|name=OnePiece Q/A Sections: Adjectives by Volume|x=-1065.3098633517407|width=1782.765625|y=-846.7249758433707|z=0|fontSize=48|text=OnePiece Q/A Sections: Adjectives by Volume|height=88.796875" ],
    "selected" : true
  },
  "elements" : {
    "nodes" : [ {
      "data" : {
        "id" : "30924",
        "ClosenessCentrality" : 0.279467680608365,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9522549760644999,
        "Stress" : 2358,
        "TopologicalCoefficient" : 0.5493827160493827,
        "shared_name" : "angry",
        "BetweennessCentrality" : 5.553909938312301E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 3,
        "name" : "angry",
        "SelfLoops" : 0,
        "SUID" : 30924,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.578231292517007,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.5
      },
      "position" : {
        "x" : -278.9623902783644,
        "y" : 307.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30922",
        "ClosenessCentrality" : 0.36326194398682043,
        "Eccentricity" : 5,
        "Degree" : 45,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9675401024607374,
        "Stress" : 361428,
        "TopologicalCoefficient" : 0.17272727272727273,
        "shared_name" : "vol-9",
        "BetweennessCentrality" : 0.09072437106982043,
        "NumberOfUndirectedEdges" : 45,
        "name" : "vol-9",
        "SelfLoops" : 0,
        "SUID" : 30922,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.752834467120181,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.8
      },
      "position" : {
        "x" : -310.44025755340954,
        "y" : 194.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30920",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "awfull",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "awfull",
        "SelfLoops" : 0,
        "SUID" : 30920,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -319.79529104836536,
        "y" : 105.4713086348628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30918",
        "ClosenessCentrality" : 0.3668885191347753,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9680440077265474,
        "Stress" : 93948,
        "TopologicalCoefficient" : 0.16486486486486487,
        "shared_name" : "bad",
        "BetweennessCentrality" : 0.02080251690523912,
        "NumberOfUndirectedEdges" : 10,
        "synsetCount" : 17,
        "name" : "bad",
        "SelfLoops" : 0,
        "SUID" : 30918,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.72562358276644,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.7
      },
      "position" : {
        "x" : 55.03760972163536,
        "y" : 12.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30916",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "bald",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "bald",
        "SelfLoops" : 0,
        "SUID" : 30916,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -397.98199768637755,
        "y" : 213.08607807260626
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30914",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "complete",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 10,
        "name" : "complete",
        "SelfLoops" : 0,
        "SUID" : 30914,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -319.79529104836536,
        "y" : 283.4857049398014
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30912",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "dry",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 19,
        "name" : "dry",
        "SelfLoops" : 0,
        "SUID" : 30912,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -250.55475805114816,
        "y" : 127.9689215833231
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30910",
        "ClosenessCentrality" : 0.2801778907242694,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9524229444864366,
        "Stress" : 2518,
        "TopologicalCoefficient" : 0.5542168674698795,
        "shared_name" : "elementary",
        "BetweennessCentrality" : 6.064983039620878E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 3,
        "name" : "elementary",
        "SelfLoops" : 0,
        "SUID" : 30910,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.569160997732426,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.0
      },
      "position" : {
        "x" : -632.9623902783644,
        "y" : -238.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30908",
        "ClosenessCentrality" : 0.3012295081967213,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9570420760896952,
        "Stress" : 12828,
        "TopologicalCoefficient" : 0.3246268656716418,
        "shared_name" : "embarrassed",
        "BetweennessCentrality" : 0.0027401286640796737,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 4,
        "name" : "embarrassed",
        "SelfLoops" : 0,
        "SUID" : 30908,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3197278911564627,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.5
      },
      "position" : {
        "x" : -158.9623902783644,
        "y" : -54.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30906",
        "ClosenessCentrality" : 0.28414948453608246,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9533467708070882,
        "Stress" : 4446,
        "TopologicalCoefficient" : 0.3835125448028674,
        "shared_name" : "famous",
        "BetweennessCentrality" : 0.001360271335395718,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 1,
        "name" : "famous",
        "SelfLoops" : 0,
        "SUID" : 30906,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5192743764172336,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.666666666666664
      },
      "position" : {
        "x" : 223.0376097216356,
        "y" : 123.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30904",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "filthy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "filthy",
        "SelfLoops" : 0,
        "SUID" : 30904,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -355.1889948949387,
        "y" : 271.9855934374151
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30902",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "flintlock",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "flintlock",
        "SelfLoops" : 0,
        "SUID" : 30902,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -220.94278287035115,
        "y" : 194.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30900",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "flustered",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "flustered",
        "SelfLoops" : 0,
        "SUID" : 30900,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -282.7840169227029,
        "y" : 109.36135029804893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30898",
        "ClosenessCentrality" : 0.3145506419400856,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9596455866297136,
        "Stress" : 23848,
        "TopologicalCoefficient" : 0.2392638036809816,
        "shared_name" : "full",
        "BetweennessCentrality" : 0.0051463858318250765,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 13,
        "name" : "full",
        "SelfLoops" : 0,
        "SUID" : 30898,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.179138321995465,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 27.03760972163559,
        "y" : 258.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30896",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "golden",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "golden",
        "SelfLoops" : 0,
        "SUID" : 30896,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -397.98199768637755,
        "y" : 175.8709355020577
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30894",
        "ClosenessCentrality" : 0.4323529411764706,
        "Eccentricity" : 4,
        "Degree" : 17,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9756865709246662,
        "Stress" : 256518,
        "TopologicalCoefficient" : 0.11541759560967244,
        "shared_name" : "good",
        "BetweennessCentrality" : 0.06072446008779481,
        "NumberOfUndirectedEdges" : 17,
        "synsetCount" : 27,
        "name" : "good",
        "SelfLoops" : 0,
        "SUID" : 30894,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.312925170068027,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.588235294117645
      },
      "position" : {
        "x" : 52.03760972163559,
        "y" : 136.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30892",
        "ClosenessCentrality" : 0.3821490467937608,
        "Eccentricity" : 4,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9700596287897875,
        "Stress" : 111472,
        "TopologicalCoefficient" : 0.15724381625441697,
        "shared_name" : "great",
        "BetweennessCentrality" : 0.02885847543002481,
        "NumberOfUndirectedEdges" : 10,
        "synsetCount" : 7,
        "name" : "great",
        "SelfLoops" : 0,
        "SUID" : 30892,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.616780045351474,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.5
      },
      "position" : {
        "x" : -64.96239027836441,
        "y" : -24.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30890",
        "ClosenessCentrality" : 0.27735849056603773,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9517510707986899,
        "Stress" : 2342,
        "TopologicalCoefficient" : 0.5666666666666667,
        "shared_name" : "heavy",
        "BetweennessCentrality" : 4.522301972053728E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 30,
        "name" : "heavy",
        "SelfLoops" : 0,
        "SUID" : 30890,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6054421768707483,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.5
      },
      "position" : {
        "x" : 205.0376097216356,
        "y" : 296.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30888",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "inside",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 10,
        "name" : "inside",
        "SelfLoops" : 0,
        "SUID" : 30888,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -355.1889948949388,
        "y" : 116.97142013724886
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30886",
        "ClosenessCentrality" : 0.28053435114503816,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525069286974049,
        "Stress" : 2462,
        "TopologicalCoefficient" : 0.5476190476190477,
        "shared_name" : "kindred",
        "BetweennessCentrality" : 5.036943295338376E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 3,
        "name" : "kindred",
        "SelfLoops" : 0,
        "SUID" : 30886,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.564625850340136,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.0
      },
      "position" : {
        "x" : -681.9623902783644,
        "y" : -224.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30884",
        "ClosenessCentrality" : 0.3330815709969789,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9629209708574789,
        "Stress" : 46500,
        "TopologicalCoefficient" : 0.21677327647476902,
        "shared_name" : "left",
        "BetweennessCentrality" : 0.009049815883815891,
        "NumberOfUndirectedEdges" : 7,
        "synsetCount" : 24,
        "name" : "left",
        "SelfLoops" : 0,
        "SUID" : 30884,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.002267573696145,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.57142857142857
      },
      "position" : {
        "x" : 146.0376097216356,
        "y" : 144.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30882",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "light",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 47,
        "name" : "light",
        "SelfLoops" : 0,
        "SUID" : 30882,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -282.7840169227029,
        "y" : 279.595663276615
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30880",
        "ClosenessCentrality" : 0.30925666199158486,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9586377760980935,
        "Stress" : 20792,
        "TopologicalCoefficient" : 0.26052631578947366,
        "shared_name" : "long",
        "BetweennessCentrality" : 0.004848206150679624,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 12,
        "name" : "long",
        "SelfLoops" : 0,
        "SUID" : 30880,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.233560090702948,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.6
      },
      "position" : {
        "x" : 32.03760972163559,
        "y" : 388.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30878",
        "ClosenessCentrality" : 0.41138059701492535,
        "Eccentricity" : 4,
        "Degree" : 13,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9735029814394893,
        "Stress" : 183382,
        "TopologicalCoefficient" : 0.13635274382937934,
        "shared_name" : "many",
        "BetweennessCentrality" : 0.04065000534742882,
        "NumberOfUndirectedEdges" : 13,
        "synsetCount" : 1,
        "name" : "many",
        "SelfLoops" : 0,
        "SUID" : 30878,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.430839002267574,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.76923076923077
      },
      "position" : {
        "x" : -50.96239027836441,
        "y" : 26.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30876",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "medium",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 13,
        "name" : "medium",
        "SelfLoops" : 0,
        "SUID" : 30876,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -382.8452355256454,
        "y" : 141.87321105121134
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30874",
        "ClosenessCentrality" : 0.38481675392670156,
        "Eccentricity" : 6,
        "Degree" : 12,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9703955656336609,
        "Stress" : 137090,
        "TopologicalCoefficient" : 0.14634146341463414,
        "shared_name" : "more",
        "BetweennessCentrality" : 0.028696096026109393,
        "NumberOfUndirectedEdges" : 12,
        "synsetCount" : 5,
        "name" : "more",
        "SelfLoops" : 0,
        "SUID" : 30874,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.598639455782313,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.0
      },
      "position" : {
        "x" : 68.03760972163559,
        "y" : -67.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30872",
        "ClosenessCentrality" : 0.3252212389380531,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9615772234819855,
        "Stress" : 53696,
        "TopologicalCoefficient" : 0.20926640926640927,
        "shared_name" : "much",
        "BetweennessCentrality" : 0.010094837965459524,
        "NumberOfUndirectedEdges" : 7,
        "synsetCount" : 7,
        "name" : "much",
        "SelfLoops" : 0,
        "SUID" : 30872,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.074829931972789,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.714285714285715
      },
      "position" : {
        "x" : -127.6398952738805,
        "y" : -1.735919443963346
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30870",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "naughty",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "naughty",
        "SelfLoops" : 0,
        "SUID" : 30870,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -228.68024608621783,
        "y" : 158.07660437098355
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30868",
        "ClosenessCentrality" : 0.391651865008881,
        "Eccentricity" : 4,
        "Degree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9712354077433442,
        "Stress" : 162706,
        "TopologicalCoefficient" : 0.13432471964895173,
        "shared_name" : "next",
        "BetweennessCentrality" : 0.03490258425456297,
        "NumberOfUndirectedEdges" : 14,
        "synsetCount" : 4,
        "name" : "next",
        "SelfLoops" : 0,
        "SUID" : 30868,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.5532879818594103,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.357142857142854
      },
      "position" : {
        "x" : 133.0376097216356,
        "y" : 77.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30866",
        "ClosenessCentrality" : 0.3071030640668524,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9582178550432519,
        "Stress" : 15504,
        "TopologicalCoefficient" : 0.31,
        "shared_name" : "okay",
        "BetweennessCentrality" : 0.003715278061066209,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 4,
        "name" : "okay",
        "SelfLoops" : 0,
        "SUID" : 30866,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.256235827664399,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.5
      },
      "position" : {
        "x" : -237.9623902783644,
        "y" : -166.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30864",
        "ClosenessCentrality" : 0.3699664429530201,
        "Eccentricity" : 6,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9684639287813892,
        "Stress" : 99240,
        "TopologicalCoefficient" : 0.1661654135338346,
        "shared_name" : "old",
        "BetweennessCentrality" : 0.022215319953114977,
        "NumberOfUndirectedEdges" : 10,
        "synsetCount" : 9,
        "name" : "old",
        "SelfLoops" : 0,
        "SUID" : 30864,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7029478458049887,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.2
      },
      "position" : {
        "x" : -94.96239027836441,
        "y" : -71.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30862",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "pivoting",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "pivoting",
        "SelfLoops" : 0,
        "SUID" : 30862,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -382.8452355256453,
        "y" : 247.08380252345262
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30860",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "pleased",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "pleased",
        "SelfLoops" : 0,
        "SUID" : 30860,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -228.68024608621795,
        "y" : 230.88040920368064
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30858",
        "ClosenessCentrality" : 0.3012295081967213,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9570420760896952,
        "Stress" : 13390,
        "TopologicalCoefficient" : 0.31066176470588236,
        "shared_name" : "popular",
        "BetweennessCentrality" : 0.0030348634296804857,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 4,
        "name" : "popular",
        "SelfLoops" : 0,
        "SUID" : 30858,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3197278911564627,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.25
      },
      "position" : {
        "x" : 195.03760972163536,
        "y" : -140.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30856",
        "ClosenessCentrality" : 0.2947860962566845,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9556983287142017,
        "Stress" : 8044,
        "TopologicalCoefficient" : 0.3856749311294766,
        "shared_name" : "refined",
        "BetweennessCentrality" : 0.0019853211899773,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 11,
        "name" : "refined",
        "SelfLoops" : 0,
        "SUID" : 30856,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3922902494331066,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.666666666666664
      },
      "position" : {
        "x" : -295.9623902783644,
        "y" : -42.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30854",
        "ClosenessCentrality" : 0.45184426229508196,
        "Eccentricity" : 4,
        "Degree" : 17,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9775342235659695,
        "Stress" : 294660,
        "TopologicalCoefficient" : 0.11571313456889605,
        "shared_name" : "right",
        "BetweennessCentrality" : 0.0673207237073942,
        "NumberOfUndirectedEdges" : 17,
        "synsetCount" : 36,
        "name" : "right",
        "SelfLoops" : 0,
        "SUID" : 30854,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.2131519274376417,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.23529411764706
      },
      "position" : {
        "x" : -26.96239027836441,
        "y" : -26.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30852",
        "ClosenessCentrality" : 0.3191027496382055,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.960485428739397,
        "Stress" : 30908,
        "TopologicalCoefficient" : 0.23603082851637766,
        "shared_name" : "small",
        "BetweennessCentrality" : 0.007334688369872125,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 13,
        "name" : "small",
        "SelfLoops" : 0,
        "SUID" : 30852,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.133786848072562,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.833333333333336
      },
      "position" : {
        "x" : 118.03760972163559,
        "y" : 194.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30850",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "smelly",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "smelly",
        "SelfLoops" : 0,
        "SUID" : 30850,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -250.55475805114816,
        "y" : 260.98809199134087
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30848",
        "ClosenessCentrality" : 0.3083916083916084,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9584698076761569,
        "Stress" : 27852,
        "TopologicalCoefficient" : 0.25866666666666666,
        "shared_name" : "sorry",
        "BetweennessCentrality" : 0.005891629436900538,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 4,
        "name" : "sorry",
        "SelfLoops" : 0,
        "SUID" : 30848,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2426303854875282,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.8
      },
      "position" : {
        "x" : -70.96239027836441,
        "y" : -85.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30846",
        "ClosenessCentrality" : 0.30455801104972374,
        "Eccentricity" : 6,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9577139497774418,
        "Stress" : 18140,
        "TopologicalCoefficient" : 0.2727272727272727,
        "shared_name" : "surprised",
        "BetweennessCentrality" : 0.0038930222513594505,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 4,
        "name" : "surprised",
        "SelfLoops" : 0,
        "SUID" : 30846,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2834467120181405,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 267.0376097216356,
        "y" : -150.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30844",
        "ClosenessCentrality" : 0.3,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.95679012345679,
        "Stress" : 12594,
        "TopologicalCoefficient" : 0.32894736842105265,
        "shared_name" : "terrible",
        "BetweennessCentrality" : 0.0027758768708784826,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 4,
        "name" : "terrible",
        "SelfLoops" : 0,
        "SUID" : 30844,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3333333333333335,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.75
      },
      "position" : {
        "x" : -207.9623902783644,
        "y" : -244.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30842",
        "ClosenessCentrality" : 0.28053435114503816,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525069286974049,
        "Stress" : 2462,
        "TopologicalCoefficient" : 0.5476190476190477,
        "shared_name" : "third",
        "BetweennessCentrality" : 5.036943295338376E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 8,
        "name" : "third",
        "SelfLoops" : 0,
        "SUID" : 30842,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.564625850340136,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.0
      },
      "position" : {
        "x" : -668.9623902783644,
        "y" : -148.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30840",
        "ClosenessCentrality" : 0.3361280487804878,
        "Eccentricity" : 6,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9634248761232889,
        "Stress" : 49038,
        "TopologicalCoefficient" : 0.21462747778537253,
        "shared_name" : "true",
        "BetweennessCentrality" : 0.009778191660811368,
        "NumberOfUndirectedEdges" : 7,
        "synsetCount" : 15,
        "name" : "true",
        "SelfLoops" : 0,
        "SUID" : 30840,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.9750566893424035,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.857142857142854
      },
      "position" : {
        "x" : 94.03760972163559,
        "y" : -42.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30838",
        "ClosenessCentrality" : 0.30246913580246915,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9572940287226002,
        "Stress" : 13210,
        "TopologicalCoefficient" : 0.3129496402877698,
        "shared_name" : "whole",
        "BetweennessCentrality" : 0.003008675427419787,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 8,
        "name" : "whole",
        "SelfLoops" : 0,
        "SUID" : 30838,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.306122448979592,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.5
      },
      "position" : {
        "x" : -156.9623902783644,
        "y" : -205.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30836",
        "ClosenessCentrality" : 0.34944532488114105,
        "Eccentricity" : 4,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9655244813974972,
        "Stress" : 65648,
        "TopologicalCoefficient" : 0.2002164502164502,
        "shared_name" : "wrong",
        "BetweennessCentrality" : 0.013010345601946052,
        "NumberOfUndirectedEdges" : 8,
        "synsetCount" : 13,
        "name" : "wrong",
        "SelfLoops" : 0,
        "SUID" : 30836,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.8616780045351473,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.25
      },
      "position" : {
        "x" : 23.03760972163559,
        "y" : -87.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30834",
        "ClosenessCentrality" : 0.3214285714285714,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9609053497942386,
        "Stress" : 31154,
        "TopologicalCoefficient" : 0.25374531835205993,
        "shared_name" : "young",
        "BetweennessCentrality" : 0.005685993705765683,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 14,
        "name" : "young",
        "SelfLoops" : 0,
        "SUID" : 30834,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.111111111111111,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.166666666666664
      },
      "position" : {
        "x" : -70.96239027836441,
        "y" : -62.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30832",
        "ClosenessCentrality" : 0.2889908256880734,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9544385655496767,
        "Stress" : 6128,
        "TopologicalCoefficient" : 0.38782051282051283,
        "shared_name" : "-",
        "BetweennessCentrality" : 0.0016888936909373882,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 0,
        "name" : "-",
        "SelfLoops" : 0,
        "SUID" : 30832,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4603174603174605,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.333333333333336
      },
      "position" : {
        "x" : 174.0376097216356,
        "y" : 438.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30830",
        "ClosenessCentrality" : 0.36872909698996653,
        "Eccentricity" : 3,
        "Degree" : 52,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9682959603594524,
        "Stress" : 464510,
        "TopologicalCoefficient" : 0.15301003344481606,
        "shared_name" : "vol-8",
        "BetweennessCentrality" : 0.11729789923258804,
        "NumberOfUndirectedEdges" : 52,
        "name" : "vol-8",
        "SelfLoops" : 0,
        "SUID" : 30830,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7120181405895694,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.519230769230769
      },
      "position" : {
        "x" : 172.5376097216356,
        "y" : 571.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30828",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "153rd",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "153rd",
        "SelfLoops" : 0,
        "SUID" : 30828,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 100.72851524497901,
        "y" : 632.2334914778688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30826",
        "ClosenessCentrality" : 0.28451612903225804,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9534307550180566,
        "Stress" : 3334,
        "TopologicalCoefficient" : 0.543010752688172,
        "shared_name" : "3rd",
        "BetweennessCentrality" : 7.33635847988483E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 1,
        "name" : "3rd",
        "SelfLoops" : 0,
        "SUID" : 30826,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5147392290249435,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.5
      },
      "position" : {
        "x" : 308.0376097216356,
        "y" : 84.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30824",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "alien",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "alien",
        "SelfLoops" : 0,
        "SUID" : 30824,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 188.81540992995428,
        "y" : 479.66251440252233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30822",
        "ClosenessCentrality" : 0.3136557610241821,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.959477618207777,
        "Stress" : 23844,
        "TopologicalCoefficient" : 0.2716049382716049,
        "shared_name" : "amazing",
        "BetweennessCentrality" : 0.005198929907748124,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 4,
        "name" : "amazing",
        "SelfLoops" : 0,
        "SUID" : 30822,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : 104.03760972163559,
        "y" : -142.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30820",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "artificial",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "artificial",
        "SelfLoops" : 0,
        "SUID" : 30820,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 100.72851524497901,
        "y" : 511.72352209679536
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30818",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "astonishing",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "astonishing",
        "SelfLoops" : 0,
        "SUID" : 30818,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 78.797494351458,
        "y" : 571.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30816",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "astronomical",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "astronomical",
        "SelfLoops" : 0,
        "SUID" : 30816,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 219.40766740672439,
        "y" : 653.1598280515899
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30814",
        "ClosenessCentrality" : 0.3159025787965616,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9598975392626187,
        "Stress" : 37610,
        "TopologicalCoefficient" : 0.2319277108433735,
        "shared_name" : "careful",
        "BetweennessCentrality" : 0.006306033763745385,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 5,
        "name" : "careful",
        "SelfLoops" : 0,
        "SUID" : 30814,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.165532879818594,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.5
      },
      "position" : {
        "x" : 131.0376097216356,
        "y" : -98.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30812",
        "ClosenessCentrality" : 0.28378378378378377,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9532627865961198,
        "Stress" : 3326,
        "TopologicalCoefficient" : 0.5439560439560439,
        "shared_name" : "cheap",
        "BetweennessCentrality" : 8.542922054677832E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "cheap",
        "SelfLoops" : 0,
        "SUID" : 30812,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5238095238095237,
        "selected" : false,
        "NeighborhoodConnectivity" : 50.5
      },
      "position" : {
        "x" : -293.9623902783644,
        "y" : 64.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30810",
        "ClosenessCentrality" : 0.35507246376811596,
        "Eccentricity" : 4,
        "Degree" : 9,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9663643235071807,
        "Stress" : 78006,
        "TopologicalCoefficient" : 0.17962962962962964,
        "shared_name" : "cool",
        "BetweennessCentrality" : 0.018604257833446883,
        "NumberOfUndirectedEdges" : 9,
        "synsetCount" : 11,
        "name" : "cool",
        "SelfLoops" : 0,
        "SUID" : 30810,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.816326530612245,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.111111111111114
      },
      "position" : {
        "x" : 119.03760972163559,
        "y" : -8.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30808",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "courageous",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "courageous",
        "SelfLoops" : 0,
        "SUID" : 30808,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 84.45071503665986,
        "y" : 604.0395144816049
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30806",
        "ClosenessCentrality" : 0.3105633802816901,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9588897287309985,
        "Stress" : 20564,
        "TopologicalCoefficient" : 0.2658064516129032,
        "shared_name" : "curious",
        "BetweennessCentrality" : 0.005291166149809263,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 3,
        "name" : "curious",
        "SelfLoops" : 0,
        "SUID" : 30806,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2199546485260773,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.2
      },
      "position" : {
        "x" : 180.0376097216356,
        "y" : 147.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30804",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "earthling",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "earthling",
        "SelfLoops" : 0,
        "SUID" : 30804,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 219.40766740672393,
        "y" : 490.79718552307384
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30802",
        "ClosenessCentrality" : 0.3200290275761974,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9606533971613337,
        "Stress" : 30748,
        "TopologicalCoefficient" : 0.2361904761904762,
        "shared_name" : "easy",
        "BetweennessCentrality" : 0.006535775185677541,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 15,
        "name" : "easy",
        "SelfLoops" : 0,
        "SUID" : 30802,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.124716553287982,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.333333333333336
      },
      "position" : {
        "x" : -5.96239027836441,
        "y" : -74.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30800",
        "ClosenessCentrality" : 0.3012295081967213,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9570420760896952,
        "Stress" : 12140,
        "TopologicalCoefficient" : 0.31716417910447764,
        "shared_name" : "enough",
        "BetweennessCentrality" : 0.0025862367517849216,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 3,
        "name" : "enough",
        "SelfLoops" : 0,
        "SUID" : 30800,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3197278911564627,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.5
      },
      "position" : {
        "x" : -55.96239027836441,
        "y" : 436.47850678733187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30798",
        "ClosenessCentrality" : 0.2882352941176471,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.95427059712774,
        "Stress" : 53740,
        "TopologicalCoefficient" : 0.30445544554455445,
        "shared_name" : "entire",
        "BetweennessCentrality" : 0.0101485618434318,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 5,
        "name" : "entire",
        "SelfLoops" : 0,
        "SUID" : 30798,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4693877551020407,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.75
      },
      "position" : {
        "x" : -54.96239027836441,
        "y" : 1003.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30796",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "existent",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "existent",
        "SelfLoops" : 0,
        "SUID" : 30796,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 188.81540992995474,
        "y" : 664.2944991721419
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30794",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "fat",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 9,
        "name" : "fat",
        "SelfLoops" : 0,
        "SUID" : 30794,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 266.2777250918132,
        "y" : 571.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30792",
        "ClosenessCentrality" : 0.3730964467005076,
        "Eccentricity" : 4,
        "Degree" : 11,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9688838498362308,
        "Stress" : 128350,
        "TopologicalCoefficient" : 0.14654002713704206,
        "shared_name" : "first",
        "BetweennessCentrality" : 0.03212161151035365,
        "NumberOfUndirectedEdges" : 11,
        "synsetCount" : 16,
        "name" : "first",
        "SelfLoops" : 0,
        "SUID" : 30792,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.6802721088435373,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.27272727272727
      },
      "position" : {
        "x" : 69.03760972163559,
        "y" : -40.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30790",
        "ClosenessCentrality" : 0.2766624843161857,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9515831023767531,
        "Stress" : 1580,
        "TopologicalCoefficient" : 0.5492957746478874,
        "shared_name" : "giant",
        "BetweennessCentrality" : 4.315580595801766E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 8,
        "name" : "giant",
        "SelfLoops" : 0,
        "SUID" : 30790,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.614512471655329,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 443.0376097216356,
        "y" : 860.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30788",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "half",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "half",
        "SelfLoops" : 0,
        "SUID" : 30788,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 125.6675520365468,
        "y" : 653.1598280515899
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30786",
        "ClosenessCentrality" : 0.3310810810810811,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9625850340136054,
        "Stress" : 40696,
        "TopologicalCoefficient" : 0.19434372733865118,
        "shared_name" : "high",
        "BetweennessCentrality" : 0.011294016306372104,
        "NumberOfUndirectedEdges" : 7,
        "synsetCount" : 18,
        "name" : "high",
        "SelfLoops" : 0,
        "SUID" : 30786,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.020408163265306,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.285714285714285
      },
      "position" : {
        "x" : 78.03760972163559,
        "y" : 169.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30784",
        "ClosenessCentrality" : 0.2798223350253807,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9523389602754683,
        "Stress" : 2174,
        "TopologicalCoefficient" : 0.55625,
        "shared_name" : "impossible",
        "BetweennessCentrality" : 3.8103298752582214E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "impossible",
        "SelfLoops" : 0,
        "SUID" : 30784,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5736961451247167,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.5
      },
      "position" : {
        "x" : 596.0376097216356,
        "y" : 36.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30782",
        "ClosenessCentrality" : 0.2801778907242694,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9524229444864366,
        "Stress" : 2342,
        "TopologicalCoefficient" : 0.5617283950617284,
        "shared_name" : "last",
        "BetweennessCentrality" : 4.92851650561087E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 21,
        "name" : "last",
        "SelfLoops" : 0,
        "SUID" : 30782,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.569160997732426,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.5
      },
      "position" : {
        "x" : -236.9623902783644,
        "y" : 361.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30780",
        "ClosenessCentrality" : 0.3016415868673051,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9571260603006635,
        "Stress" : 10574,
        "TopologicalCoefficient" : 0.37745098039215685,
        "shared_name" : "like",
        "BetweennessCentrality" : 0.0024399533659872482,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 11,
        "name" : "like",
        "SelfLoops" : 0,
        "SUID" : 30780,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.315192743764172,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.333333333333336
      },
      "position" : {
        "x" : -119.96239027836452,
        "y" : -68.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30778",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "low",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 16,
        "name" : "low",
        "SelfLoops" : 0,
        "SUID" : 30778,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 244.34670419829195,
        "y" : 632.2334914778688
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30776",
        "ClosenessCentrality" : 0.28414948453608246,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9533467708070882,
        "Stress" : 3040,
        "TopologicalCoefficient" : 0.5543478260869565,
        "shared_name" : "natural",
        "BetweennessCentrality" : 5.322044378353072E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 13,
        "name" : "natural",
        "SelfLoops" : 0,
        "SUID" : 30776,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5192743764172336,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 651.0376097216356,
        "y" : 197.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30774",
        "ClosenessCentrality" : 0.2766624843161857,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9515831023767531,
        "Stress" : 1580,
        "TopologicalCoefficient" : 0.5492957746478874,
        "shared_name" : "non",
        "BetweennessCentrality" : 4.315580595801766E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 1,
        "name" : "non",
        "SelfLoops" : 0,
        "SUID" : 30774,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.614512471655329,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 293.0376097216356,
        "y" : 997.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30772",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "notorious",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "notorious",
        "SelfLoops" : 0,
        "SUID" : 30772,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 84.45071503665986,
        "y" : 539.9174990930593
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30770",
        "ClosenessCentrality" : 0.4075785582255083,
        "Eccentricity" : 4,
        "Degree" : 15,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9730830603846478,
        "Stress" : 204282,
        "TopologicalCoefficient" : 0.13121019108280255,
        "shared_name" : "other",
        "BetweennessCentrality" : 0.041322173012677155,
        "NumberOfUndirectedEdges" : 15,
        "synsetCount" : 4,
        "name" : "other",
        "SelfLoops" : 0,
        "SUID" : 30770,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.453514739229025,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.2
      },
      "position" : {
        "x" : 8.03760972163559,
        "y" : -18.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30768",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "rainy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "rainy",
        "SelfLoops" : 0,
        "SUID" : 30768,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 260.6245044066111,
        "y" : 539.9174990930586
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30766",
        "ClosenessCentrality" : 0.2819693094629156,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9528428655412782,
        "Stress" : 2636,
        "TopologicalCoefficient" : 0.5523255813953488,
        "shared_name" : "ridiculous",
        "BetweennessCentrality" : 4.955972400373356E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 3,
        "name" : "ridiculous",
        "SelfLoops" : 0,
        "SUID" : 30766,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.546485260770975,
        "selected" : false,
        "NeighborhoodConnectivity" : 48.5
      },
      "position" : {
        "x" : -182.9623902783644,
        "y" : 154.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30764",
        "ClosenessCentrality" : 0.4136960600375234,
        "Eccentricity" : 4,
        "Degree" : 15,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9737549340723944,
        "Stress" : 213422,
        "TopologicalCoefficient" : 0.12525879917184266,
        "shared_name" : "same",
        "BetweennessCentrality" : 0.04977273619573003,
        "NumberOfUndirectedEdges" : 15,
        "synsetCount" : 6,
        "name" : "same",
        "SelfLoops" : 0,
        "SUID" : 30764,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.417233560090703,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.333333333333336
      },
      "position" : {
        "x" : 31.03760972163559,
        "y" : -60.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30762",
        "ClosenessCentrality" : 0.334597875569044,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9631729234903837,
        "Stress" : 46534,
        "TopologicalCoefficient" : 0.21218487394957983,
        "shared_name" : "serious",
        "BetweennessCentrality" : 0.00963618006285687,
        "NumberOfUndirectedEdges" : 7,
        "synsetCount" : 6,
        "name" : "serious",
        "SelfLoops" : 0,
        "SUID" : 30762,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.9886621315192743,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.285714285714285
      },
      "position" : {
        "x" : -32.96239027836441,
        "y" : 322.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30760",
        "ClosenessCentrality" : 0.30667593880389427,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9581338708322836,
        "Stress" : 17740,
        "TopologicalCoefficient" : 0.26301369863013696,
        "shared_name" : "short",
        "BetweennessCentrality" : 0.005236827134596669,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 23,
        "name" : "short",
        "SelfLoops" : 0,
        "SUID" : 30760,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2607709750566896,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.4
      },
      "position" : {
        "x" : 58.03760972163559,
        "y" : 54.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30758",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "snowy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "snowy",
        "SelfLoops" : 0,
        "SUID" : 30758,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 244.34670419829172,
        "y" : 511.7235220967949
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30756",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "somethign",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "somethign",
        "SelfLoops" : 0,
        "SUID" : 30756,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 125.66755203654657,
        "y" : 490.7971855230743
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30754",
        "ClosenessCentrality" : 0.30205479452054795,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9572100445116318,
        "Stress" : 12892,
        "TopologicalCoefficient" : 0.31985294117647056,
        "shared_name" : "strong",
        "BetweennessCentrality" : 0.0025781142133262784,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 10,
        "name" : "strong",
        "SelfLoops" : 0,
        "SUID" : 30754,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.310657596371882,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.5
      },
      "position" : {
        "x" : 61.03760972163536,
        "y" : -161.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30752",
        "ClosenessCentrality" : 0.2971698113207547,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9562022339800117,
        "Stress" : 10202,
        "TopologicalCoefficient" : 0.3064516129032258,
        "shared_name" : "stupid",
        "BetweennessCentrality" : 0.0024543296295551037,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 4,
        "name" : "stupid",
        "SelfLoops" : 0,
        "SUID" : 30752,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.365079365079365,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.0
      },
      "position" : {
        "x" : -207.9623902783644,
        "y" : 14.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30750",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sunny",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "sunny",
        "SelfLoops" : 0,
        "SUID" : 30750,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 156.25980951331644,
        "y" : 664.2944991721419
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30748",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "waterproof",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "waterproof",
        "SelfLoops" : 0,
        "SUID" : 30748,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 260.6245044066111,
        "y" : 604.0395144816049
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30746",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "wooden",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "wooden",
        "SelfLoops" : 0,
        "SUID" : 30746,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 156.2598095133162,
        "y" : 479.66251440252233
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30744",
        "ClosenessCentrality" : 0.28378378378378377,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9532627865961198,
        "Stress" : 3196,
        "TopologicalCoefficient" : 0.5439560439560439,
        "shared_name" : "worth",
        "BetweennessCentrality" : 6.607868769320191E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 5,
        "name" : "worth",
        "SelfLoops" : 0,
        "SUID" : 30744,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5238095238095237,
        "selected" : false,
        "NeighborhoodConnectivity" : 50.5
      },
      "position" : {
        "x" : -26.96239027836441,
        "y" : -74.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30742",
        "ClosenessCentrality" : 0.3522364217252396,
        "Eccentricity" : 5,
        "Degree" : 32,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9659444024523389,
        "Stress" : 253154,
        "TopologicalCoefficient" : 0.23214285714285715,
        "shared_name" : "vol-16",
        "BetweennessCentrality" : 0.05574568452357031,
        "NumberOfUndirectedEdges" : 32,
        "name" : "vol-16",
        "SelfLoops" : 0,
        "SUID" : 30742,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.8390022675736963,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.875
      },
      "position" : {
        "x" : -4.947850566582474,
        "y" : -635.0214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30740",
        "ClosenessCentrality" : 0.26063829787234044,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9474678760393046,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "awesome",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "awesome",
        "SelfLoops" : 0,
        "SUID" : 30740,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.836734693877551,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : 9.365344778233066,
        "y" : -553.8473286729784
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30738",
        "ClosenessCentrality" : 0.347244094488189,
        "Eccentricity" : 6,
        "Degree" : 10,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9651885445536239,
        "Stress" : 75206,
        "TopologicalCoefficient" : 0.16784140969162994,
        "shared_name" : "big",
        "BetweennessCentrality" : 0.015177293205785421,
        "NumberOfUndirectedEdges" : 10,
        "synsetCount" : 17,
        "name" : "big",
        "SelfLoops" : 0,
        "SUID" : 30738,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.879818594104308,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.1
      },
      "position" : {
        "x" : 106.03760972163536,
        "y" : 66.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30736",
        "ClosenessCentrality" : 0.26063829787234044,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9474678760393046,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "convenient",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "convenient",
        "SelfLoops" : 0,
        "SUID" : 30736,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.836734693877551,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : 77.47855630461049,
        "y" : -635.0214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30734",
        "ClosenessCentrality" : 0.2967698519515478,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9561182497690434,
        "Stress" : 11542,
        "TopologicalCoefficient" : 0.328,
        "shared_name" : "deep",
        "BetweennessCentrality" : 0.002253463981569144,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 21,
        "name" : "deep",
        "SelfLoops" : 0,
        "SUID" : 30734,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.369614512471655,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -15.962390278364637,
        "y" : -430.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30732",
        "ClosenessCentrality" : 0.26063829787234044,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9474678760393046,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "delicious",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "delicious",
        "SelfLoops" : 0,
        "SUID" : 30732,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.836734693877551,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : -82.4033368613392,
        "y" : -663.2129847045732
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30730",
        "ClosenessCentrality" : 0.27459526774595266,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9510791971109431,
        "Stress" : 1680,
        "TopologicalCoefficient" : 0.5522388059701493,
        "shared_name" : "eld",
        "BetweennessCentrality" : 4.198383594168968E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 2,
        "name" : "eld",
        "SelfLoops" : 0,
        "SUID" : 30730,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6417233560090705,
        "selected" : false,
        "NeighborhoodConnectivity" : 38.0
      },
      "position" : {
        "x" : 239.0376097216356,
        "y" : -330.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30728",
        "ClosenessCentrality" : 0.32474226804123707,
        "Eccentricity" : 4,
        "Degree" : 8,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.961493239271017,
        "Stress" : 40234,
        "TopologicalCoefficient" : 0.1912568306010929,
        "shared_name" : "happy",
        "BetweennessCentrality" : 0.009527210591488575,
        "NumberOfUndirectedEdges" : 8,
        "synsetCount" : 4,
        "name" : "happy",
        "SelfLoops" : 0,
        "SUID" : 30728,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.0793650793650795,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.0
      },
      "position" : {
        "x" : 134.0376097216356,
        "y" : 30.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30726",
        "ClosenessCentrality" : 0.26063829787234044,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9474678760393046,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "horrendous",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "horrendous",
        "SelfLoops" : 0,
        "SUID" : 30726,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.836734693877551,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : 58.1944403833586,
        "y" : -688.0041662604522
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30724",
        "ClosenessCentrality" : 0.29959239130434784,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9567061392458217,
        "Stress" : 12810,
        "TopologicalCoefficient" : 0.325,
        "shared_name" : "huge",
        "BetweennessCentrality" : 0.0023244533852807185,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 1,
        "name" : "huge",
        "SelfLoops" : 0,
        "SUID" : 30724,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3378684807256236,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.25
      },
      "position" : {
        "x" : 5.037609721635363,
        "y" : 268.47850678733187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30722",
        "ClosenessCentrality" : 0.40090909090909094,
        "Eccentricity" : 4,
        "Degree" : 14,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9723272024859326,
        "Stress" : 182458,
        "TopologicalCoefficient" : 0.13585434173669467,
        "shared_name" : "little",
        "BetweennessCentrality" : 0.039934598103486936,
        "NumberOfUndirectedEdges" : 14,
        "synsetCount" : 10,
        "name" : "little",
        "SelfLoops" : 0,
        "SUID" : 30722,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.494331065759637,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.57142857142857
      },
      "position" : {
        "x" : -23.96239027836441,
        "y" : -100.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30720",
        "ClosenessCentrality" : 0.3177233429394813,
        "Eccentricity" : 4,
        "Degree" : 7,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9602334761064919,
        "Stress" : 31284,
        "TopologicalCoefficient" : 0.2121724429416737,
        "shared_name" : "nice",
        "BetweennessCentrality" : 0.00821259991008669,
        "NumberOfUndirectedEdges" : 7,
        "synsetCount" : 6,
        "name" : "nice",
        "SelfLoops" : 0,
        "SUID" : 30720,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.147392290249433,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.857142857142854
      },
      "position" : {
        "x" : -47.96239027836441,
        "y" : -63.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30718",
        "ClosenessCentrality" : 0.3071030640668524,
        "Eccentricity" : 6,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9582178550432519,
        "Stress" : 18598,
        "TopologicalCoefficient" : 0.26308724832214764,
        "shared_name" : "normal",
        "BetweennessCentrality" : 0.00453925773453376,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 5,
        "name" : "normal",
        "SelfLoops" : 0,
        "SUID" : 30718,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.256235827664399,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.2
      },
      "position" : {
        "x" : -129.2397571834123,
        "y" : -135.71647779371156
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30716",
        "ClosenessCentrality" : 0.2834190231362468,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9531788023851516,
        "Stress" : 4284,
        "TopologicalCoefficient" : 0.4175824175824176,
        "shared_name" : "only",
        "BetweennessCentrality" : 7.982632534286282E-4,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 9,
        "name" : "only",
        "SelfLoops" : 0,
        "SUID" : 30716,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5283446712018143,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.0
      },
      "position" : {
        "x" : -350.9623902783644,
        "y" : -5.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30714",
        "ClosenessCentrality" : 0.32331378299120234,
        "Eccentricity" : 6,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.961241286638112,
        "Stress" : 33760,
        "TopologicalCoefficient" : 0.2346014492753623,
        "shared_name" : "own",
        "BetweennessCentrality" : 0.008209223685048374,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 2,
        "name" : "own",
        "SelfLoops" : 0,
        "SUID" : 30714,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.0929705215419503,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.166666666666664
      },
      "position" : {
        "x" : -137.9623902783644,
        "y" : -112.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30712",
        "ClosenessCentrality" : 0.27735849056603773,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9517510707986899,
        "Stress" : 2044,
        "TopologicalCoefficient" : 0.54,
        "shared_name" : "quick",
        "BetweennessCentrality" : 4.3526928809509293E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 8,
        "name" : "quick",
        "SelfLoops" : 0,
        "SUID" : 30712,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6054421768707483,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.5
      },
      "position" : {
        "x" : 295.0376097216356,
        "y" : -826.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30710",
        "ClosenessCentrality" : 0.28053435114503816,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525069286974049,
        "Stress" : 4110,
        "TopologicalCoefficient" : 0.39759036144578314,
        "shared_name" : "ready",
        "BetweennessCentrality" : 0.0010505132672010843,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 8,
        "name" : "ready",
        "SelfLoops" : 0,
        "SUID" : 30710,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.564625850340136,
        "selected" : false,
        "NeighborhoodConnectivity" : 34.0
      },
      "position" : {
        "x" : 344.0376097216356,
        "y" : -227.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30708",
        "ClosenessCentrality" : 0.26063829787234044,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9474678760393046,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "shocked",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 8,
        "name" : "shocked",
        "SelfLoops" : 0,
        "SUID" : 30708,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.836734693877551,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : -82.4033368613392,
        "y" : -606.8300017207625
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30706",
        "ClosenessCentrality" : 0.26063829787234044,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9474678760393046,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sick",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 9,
        "name" : "sick",
        "SelfLoops" : 0,
        "SUID" : 30706,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.836734693877551,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : -46.161054002178844,
        "y" : -563.6381309195426
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30704",
        "ClosenessCentrality" : 0.3083916083916084,
        "Eccentricity" : 6,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9584698076761569,
        "Stress" : 23012,
        "TopologicalCoefficient" : 0.25496688741721857,
        "shared_name" : "such",
        "BetweennessCentrality" : 0.004133967408073868,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 2,
        "name" : "such",
        "SelfLoops" : 0,
        "SUID" : 30704,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2426303854875282,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.5
      },
      "position" : {
        "x" : 245.0376097216356,
        "y" : -236.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30702",
        "ClosenessCentrality" : 0.26063829787234044,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9474678760393046,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "super",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "super",
        "SelfLoops" : 0,
        "SUID" : 30702,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.836734693877551,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : 58.194440383358824,
        "y" : -582.0388201648836
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30700",
        "ClosenessCentrality" : 0.26063829787234044,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9474678760393046,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "trivial",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "trivial",
        "SelfLoops" : 0,
        "SUID" : 30700,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.836734693877551,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : 9.365344778233066,
        "y" : -716.1956577523573
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30698",
        "ClosenessCentrality" : 0.26063829787234044,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9474678760393046,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "twisty",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "twisty",
        "SelfLoops" : 0,
        "SUID" : 30698,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.836734693877551,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : -46.16105400217907,
        "y" : -706.4048555057931
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30696",
        "ClosenessCentrality" : 0.2739130434782609,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9509112286890065,
        "Stress" : 1624,
        "TopologicalCoefficient" : 0.5538461538461539,
        "shared_name" : "webbed",
        "BetweennessCentrality" : 3.4230966440417117E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 3,
        "name" : "webbed",
        "SelfLoops" : 0,
        "SUID" : 30696,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6507936507936507,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.0
      },
      "position" : {
        "x" : 153.0376097216356,
        "y" : -936.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30694",
        "ClosenessCentrality" : 0.3545016077170418,
        "Eccentricity" : 3,
        "Degree" : 28,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9662803392962124,
        "Stress" : 156322,
        "TopologicalCoefficient" : 0.16304347826086957,
        "shared_name" : "vol-17",
        "BetweennessCentrality" : 0.05171581925152732,
        "NumberOfUndirectedEdges" : 28,
        "name" : "vol-17",
        "SelfLoops" : 0,
        "SUID" : 30694,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.820861678004535,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.75
      },
      "position" : {
        "x" : 112.53760972163559,
        "y" : 771.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30692",
        "ClosenessCentrality" : 0.3016415868673051,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9571260603006635,
        "Stress" : 20498,
        "TopologicalCoefficient" : 0.23880597014925373,
        "shared_name" : "able",
        "BetweennessCentrality" : 0.0052085401784390944,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 4,
        "name" : "able",
        "SelfLoops" : 0,
        "SUID" : 30692,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.315192743764172,
        "selected" : false,
        "NeighborhoodConnectivity" : 33.0
      },
      "position" : {
        "x" : -193.9623902783644,
        "y" : 53.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30690",
        "ClosenessCentrality" : 0.27459526774595266,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9510791971109431,
        "Stress" : 1674,
        "TopologicalCoefficient" : 0.5384615384615384,
        "shared_name" : "ancient",
        "BetweennessCentrality" : 5.446248863876987E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "ancient",
        "SelfLoops" : 0,
        "SUID" : 30690,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6417233560090705,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.0
      },
      "position" : {
        "x" : 56.03760972163559,
        "y" : 434.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30688",
        "ClosenessCentrality" : 0.2784090909090909,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9520030234315948,
        "Stress" : 2040,
        "TopologicalCoefficient" : 0.5263157894736842,
        "shared_name" : "awful",
        "BetweennessCentrality" : 6.192447124550508E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 7,
        "name" : "awful",
        "SelfLoops" : 0,
        "SUID" : 30688,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5918367346938775,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -297.9623902783644,
        "y" : 382.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30686",
        "ClosenessCentrality" : 0.26187648456057006,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478038128831779,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "beautiful",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "beautiful",
        "SelfLoops" : 0,
        "SUID" : 30686,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.81859410430839,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 56.25333847417369,
        "y" : 715.6942355398702
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30684",
        "ClosenessCentrality" : 0.315450643776824,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9598135550516503,
        "Stress" : 28832,
        "TopologicalCoefficient" : 0.23737373737373738,
        "shared_name" : "correct",
        "BetweennessCentrality" : 0.006591098182819619,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 12,
        "name" : "correct",
        "SelfLoops" : 0,
        "SUID" : 30684,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.1700680272108843,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.166666666666664
      },
      "position" : {
        "x" : 91.03760972163559,
        "y" : 244.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30682",
        "ClosenessCentrality" : 0.28861256544502617,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9543545813387083,
        "Stress" : 5636,
        "TopologicalCoefficient" : 0.40129449838187703,
        "shared_name" : "difficult",
        "BetweennessCentrality" : 0.0012407793859171665,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 2,
        "name" : "difficult",
        "SelfLoops" : 0,
        "SUID" : 30682,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4648526077097506,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.333333333333336
      },
      "position" : {
        "x" : -423.9623902783644,
        "y" : 387.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30680",
        "ClosenessCentrality" : 0.2763157894736842,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9514991181657848,
        "Stress" : 1924,
        "TopologicalCoefficient" : 0.5142857142857142,
        "shared_name" : "extra",
        "BetweennessCentrality" : 8.533381571776958E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 7,
        "name" : "extra",
        "SelfLoops" : 0,
        "SUID" : 30680,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.619047619047619,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.0
      },
      "position" : {
        "x" : -75.96239027836441,
        "y" : 435.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30678",
        "ClosenessCentrality" : 0.26187648456057006,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478038128831779,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "horned",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "horned",
        "SelfLoops" : 0,
        "SUID" : 30678,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.81859410430839,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 168.8218809690975,
        "y" : 828.262778034794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30676",
        "ClosenessCentrality" : 0.26187648456057006,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478038128831779,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "mammalian",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "mammalian",
        "SelfLoops" : 0,
        "SUID" : 30676,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.81859410430839,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 192.13558946808212,
        "y" : 771.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30674",
        "ClosenessCentrality" : 0.26187648456057006,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478038128831779,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "official",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "official",
        "SelfLoops" : 0,
        "SUID" : 30674,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.81859410430839,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 168.82188096909726,
        "y" : 715.69423553987
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30672",
        "ClosenessCentrality" : 0.26187648456057006,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478038128831779,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "original",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "original",
        "SelfLoops" : 0,
        "SUID" : 30672,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.81859410430839,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 32.939629975188836,
        "y" : 771.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30670",
        "ClosenessCentrality" : 0.26187648456057006,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478038128831779,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "precise",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "precise",
        "SelfLoops" : 0,
        "SUID" : 30670,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.81859410430839,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 112.53760972163559,
        "y" : 851.5764865337788
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30668",
        "ClosenessCentrality" : 0.27735849056603773,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9517510707986899,
        "Stress" : 1816,
        "TopologicalCoefficient" : 0.5342465753424658,
        "shared_name" : "random",
        "BetweennessCentrality" : 4.5533305778224935E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 1,
        "name" : "random",
        "SelfLoops" : 0,
        "SUID" : 30668,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6054421768707483,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 268.0376097216356,
        "y" : 274.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30666",
        "ClosenessCentrality" : 0.3181818181818182,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9603174603174602,
        "Stress" : 27844,
        "TopologicalCoefficient" : 0.24463937621832357,
        "shared_name" : "sure",
        "BetweennessCentrality" : 0.005549022351243233,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 10,
        "name" : "sure",
        "SelfLoops" : 0,
        "SUID" : 30666,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.142857142857143,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.833333333333336
      },
      "position" : {
        "x" : 195.0376097216356,
        "y" : 119.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30664",
        "ClosenessCentrality" : 0.26187648456057006,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478038128831779,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "swedish",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "swedish",
        "SelfLoops" : 0,
        "SUID" : 30664,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.81859410430839,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 112.53760972163536,
        "y" : 692.3805270408853
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30662",
        "ClosenessCentrality" : 0.26187648456057006,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478038128831779,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "unnecessary",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "unnecessary",
        "SelfLoops" : 0,
        "SUID" : 30662,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.81859410430839,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 56.25333847417369,
        "y" : 828.262778034794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30660",
        "ClosenessCentrality" : 0.31100141043723556,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9589737129419669,
        "Stress" : 20044,
        "TopologicalCoefficient" : 0.2641025641025641,
        "shared_name" : "wonderful",
        "BetweennessCentrality" : 0.004970729953758876,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 1,
        "name" : "wonderful",
        "SelfLoops" : 0,
        "SUID" : 30660,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2154195011337867,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.2
      },
      "position" : {
        "x" : -205.9623902783644,
        "y" : -13.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30658",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "100th",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "100th",
        "SelfLoops" : 0,
        "SUID" : 30658,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 77.20665727994765,
        "y" : -315.0214932126678
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30656",
        "ClosenessCentrality" : 0.3602941176470588,
        "Eccentricity" : 5,
        "Degree" : 40,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9671201814058956,
        "Stress" : 305326,
        "TopologicalCoefficient" : 0.1965909090909091,
        "shared_name" : "vol-15",
        "BetweennessCentrality" : 0.07645935914799061,
        "NumberOfUndirectedEdges" : 40,
        "name" : "vol-15",
        "SelfLoops" : 0,
        "SUID" : 30656,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7755102040816326,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.325
      },
      "position" : {
        "x" : -252.51146687316705,
        "y" : -94.7582675486279
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30654",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "canadian",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "canadian",
        "SelfLoops" : 0,
        "SUID" : 30654,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : -96.13143783667647,
        "y" : -315.0214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30652",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "chure",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "chure",
        "SelfLoops" : 0,
        "SUID" : 30652,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : -28.748067686144395,
        "y" : -230.52541962585542
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30650",
        "ClosenessCentrality" : 0.2791139240506329,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9521709918535315,
        "Stress" : 2098,
        "TopologicalCoefficient" : 0.55625,
        "shared_name" : "exciting",
        "BetweennessCentrality" : 4.402275816425017E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 10,
        "name" : "exciting",
        "SelfLoops" : 0,
        "SUID" : 30650,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.582766439909297,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.5
      },
      "position" : {
        "x" : 149.0376097216356,
        "y" : -374.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30648",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "further",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 11,
        "name" : "further",
        "SelfLoops" : 0,
        "SUID" : 30648,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 9.823287129415576,
        "y" : -399.5175667994803
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30646",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "future",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "future",
        "SelfLoops" : 0,
        "SUID" : 30646,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : -63.49965756778147,
        "y" : -382.7820831492752
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30644",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "grand",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 10,
        "name" : "grand",
        "SelfLoops" : 0,
        "SUID" : 30644,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 9.823287129415348,
        "y" : -230.52541962585542
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30642",
        "ClosenessCentrality" : 0.2889908256880734,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9544385655496767,
        "Stress" : 5418,
        "TopologicalCoefficient" : 0.42948717948717946,
        "shared_name" : "important",
        "BetweennessCentrality" : 8.316422135055027E-4,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 5,
        "name" : "important",
        "SelfLoops" : 0,
        "SUID" : 30642,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4603174603174605,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.666666666666664
      },
      "position" : {
        "x" : 164.0376097216356,
        "y" : 192.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30640",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "knowledgeable",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "knowledgeable",
        "SelfLoops" : 0,
        "SUID" : 30640,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 68.62372338242903,
        "y" : -352.6257836330258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30638",
        "ClosenessCentrality" : 0.29244031830238726,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9551944234483918,
        "Stress" : 7534,
        "TopologicalCoefficient" : 0.39710144927536234,
        "shared_name" : "least",
        "BetweennessCentrality" : 0.0018673669799930761,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 3,
        "name" : "least",
        "SelfLoops" : 0,
        "SUID" : 30638,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.419501133786848,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.666666666666664
      },
      "position" : {
        "x" : -29.96239027836441,
        "y" : -477.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30636",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "live",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 19,
        "name" : "live",
        "SelfLoops" : 0,
        "SUID" : 30636,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : -87.54850393915774,
        "y" : -352.6257836330258
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30634",
        "ClosenessCentrality" : 0.3105633802816901,
        "Eccentricity" : 6,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9588897287309985,
        "Stress" : 21370,
        "TopologicalCoefficient" : 0.2713375796178344,
        "shared_name" : "middle",
        "BetweennessCentrality" : 0.004502101823398049,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 9,
        "name" : "middle",
        "SelfLoops" : 0,
        "SUID" : 30634,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2199546485260773,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.6
      },
      "position" : {
        "x" : 81.03760972163559,
        "y" : 46.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30632",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "olden",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "olden",
        "SelfLoops" : 0,
        "SUID" : 30632,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 44.57487701105288,
        "y" : -382.7820831492752
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30630",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "pathetic",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "pathetic",
        "SelfLoops" : 0,
        "SUID" : 30630,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : -63.49965756778158,
        "y" : -247.2609032760605
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30628",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "portuguese",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "portuguese",
        "SelfLoops" : 0,
        "SUID" : 30628,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 44.57487701105265,
        "y" : -247.2609032760605
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30626",
        "ClosenessCentrality" : 0.3141025641025641,
        "Eccentricity" : 6,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9595616024187452,
        "Stress" : 39982,
        "TopologicalCoefficient" : 0.2459349593495935,
        "shared_name" : "real",
        "BetweennessCentrality" : 0.006603730387430585,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 13,
        "name" : "real",
        "SelfLoops" : 0,
        "SUID" : 30626,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.183673469387755,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.333333333333336
      },
      "position" : {
        "x" : -25.96239027836441,
        "y" : -126.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30624",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "secondhand",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "secondhand",
        "SelfLoops" : 0,
        "SUID" : 30624,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : -28.748067686144168,
        "y" : -399.5175667994803
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30622",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "stupi",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "stupi",
        "SelfLoops" : 0,
        "SUID" : 30622,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : -87.54850393915774,
        "y" : -277.4172027923099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30620",
        "ClosenessCentrality" : 0.26502403846153844,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9486436549928613,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "tough",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 12,
        "name" : "tough",
        "SelfLoops" : 0,
        "SUID" : 30620,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7732426303854876,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.0
      },
      "position" : {
        "x" : 68.62372338242903,
        "y" : -277.4172027923099
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30618",
        "ClosenessCentrality" : 0.3626644736842105,
        "Eccentricity" : 5,
        "Degree" : 44,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9674561182497691,
        "Stress" : 315250,
        "TopologicalCoefficient" : 0.1415289256198347,
        "shared_name" : "vol-14",
        "BetweennessCentrality" : 0.09708722894695838,
        "NumberOfUndirectedEdges" : 44,
        "name" : "vol-14",
        "SelfLoops" : 0,
        "SUID" : 30618,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7573696145124718,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.113636363636363
      },
      "position" : {
        "x" : 250.03760972163582,
        "y" : -27.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30616",
        "ClosenessCentrality" : 0.29557640750670244,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9558662971361385,
        "Stress" : 8668,
        "TopologicalCoefficient" : 0.37398373983739835,
        "shared_name" : "4th",
        "BetweennessCentrality" : 0.0025843083739932804,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 1,
        "name" : "4th",
        "SelfLoops" : 0,
        "SUID" : 30616,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.383219954648526,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.0
      },
      "position" : {
        "x" : 309.0376097216356,
        "y" : -152.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30614",
        "ClosenessCentrality" : 0.2819693094629156,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9528428655412782,
        "Stress" : 2994,
        "TopologicalCoefficient" : 0.5284090909090909,
        "shared_name" : "ahem",
        "BetweennessCentrality" : 9.065614550323402E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 1,
        "name" : "ahem",
        "SelfLoops" : 0,
        "SUID" : 30614,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.546485260770975,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.5
      },
      "position" : {
        "x" : 219.0376097216356,
        "y" : -335.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30612",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "comic",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "comic",
        "SelfLoops" : 0,
        "SUID" : 30612,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 332.72249479276024,
        "y" : -61.77069401238805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30610",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "cross",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 16,
        "name" : "cross",
        "SelfLoops" : 0,
        "SUID" : 30610,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 250.0376097216356,
        "y" : -117.01896789572618
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30608",
        "ClosenessCentrality" : 0.30497925311203317,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9577979339884102,
        "Stress" : 14512,
        "TopologicalCoefficient" : 0.32413793103448274,
        "shared_name" : "cute",
        "BetweennessCentrality" : 0.0028673850758255564,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 2,
        "name" : "cute",
        "SelfLoops" : 0,
        "SUID" : 30608,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2789115646258504,
        "selected" : false,
        "NeighborhoodConnectivity" : 48.0
      },
      "position" : {
        "x" : -243.9623902783644,
        "y" : -192.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30606",
        "ClosenessCentrality" : 0.27735849056603773,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9517510707986899,
        "Stress" : 1998,
        "TopologicalCoefficient" : 0.54,
        "shared_name" : "drunk",
        "BetweennessCentrality" : 4.422489925782268E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 9,
        "name" : "drunk",
        "SelfLoops" : 0,
        "SUID" : 30606,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6054421768707483,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.5
      },
      "position" : {
        "x" : 751.0376097216356,
        "y" : -82.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30604",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "egyptian",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "egyptian",
        "SelfLoops" : 0,
        "SUID" : 30604,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 332.72249479276,
        "y" : 6.7277075870526915
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30602",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "esp",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "esp",
        "SelfLoops" : 0,
        "SUID" : 30602,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 215.78840892191533,
        "y" : -110.20637828379256
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30600",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "everyday",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "everyday",
        "SelfLoops" : 0,
        "SUID" : 30600,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 167.35272465051094,
        "y" : -61.7706940123885
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30598",
        "ClosenessCentrality" : 0.27876106194690264,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9520870076425632,
        "Stress" : 2114,
        "TopologicalCoefficient" : 0.5759493670886076,
        "shared_name" : "exact",
        "BetweennessCentrality" : 4.2323757644538294E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "exact",
        "SelfLoops" : 0,
        "SUID" : 30598,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5873015873015874,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.5
      },
      "position" : {
        "x" : -81.06638795573213,
        "y" : -154.12744846353257
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30596",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "excited",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 12,
        "name" : "excited",
        "SelfLoops" : 0,
        "SUID" : 30596,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 284.28681052135585,
        "y" : 55.16339185845686
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30594",
        "ClosenessCentrality" : 0.29205298013245035,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9551104392374233,
        "Stress" : 7088,
        "TopologicalCoefficient" : 0.391812865497076,
        "shared_name" : "expensive",
        "BetweennessCentrality" : 0.001647340702626931,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 1,
        "name" : "expensive",
        "SelfLoops" : 0,
        "SUID" : 30594,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4240362811791383,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.666666666666664
      },
      "position" : {
        "x" : 92.03760972163559,
        "y" : -64.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30592",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "henohenou_chi",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "henohenou_chi",
        "SelfLoops" : 0,
        "SUID" : 30592,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 160.5401350385771,
        "y" : -27.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30590",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "hey",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "hey",
        "SelfLoops" : 0,
        "SUID" : 30590,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 215.78840892191488,
        "y" : 55.16339185845686
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30588",
        "ClosenessCentrality" : 0.30497925311203317,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9577979339884102,
        "Stress" : 15200,
        "TopologicalCoefficient" : 0.3137931034482759,
        "shared_name" : "interested",
        "BetweennessCentrality" : 0.0036891186650349966,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 5,
        "name" : "interested",
        "SelfLoops" : 0,
        "SUID" : 30588,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2789115646258504,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.5
      },
      "position" : {
        "x" : 208.03760972163536,
        "y" : -417.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30586",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "italian",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "italian",
        "SelfLoops" : 0,
        "SUID" : 30586,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 284.2868105213563,
        "y" : -110.20637828379245
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30584",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "legged",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "legged",
        "SelfLoops" : 0,
        "SUID" : 30584,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 186.7533384741737,
        "y" : -90.80576446012992
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30582",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "maaa",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "maaa",
        "SelfLoops" : 0,
        "SUID" : 30582,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 186.75333847417346,
        "y" : 35.76277803479411
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30580",
        "ClosenessCentrality" : 0.27735849056603773,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9517510707986899,
        "Stress" : 1998,
        "TopologicalCoefficient" : 0.54,
        "shared_name" : "mean",
        "BetweennessCentrality" : 4.422489925782268E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 16,
        "name" : "mean",
        "SelfLoops" : 0,
        "SUID" : 30580,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6054421768707483,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.5
      },
      "position" : {
        "x" : 690.0376097216356,
        "y" : 150.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30578",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "miraculous",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "miraculous",
        "SelfLoops" : 0,
        "SUID" : 30578,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 339.53508440469386,
        "y" : -27.521493212667792
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30576",
        "ClosenessCentrality" : 0.3191027496382055,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.960485428739397,
        "Stress" : 28874,
        "TopologicalCoefficient" : 0.23699421965317918,
        "shared_name" : "new",
        "BetweennessCentrality" : 0.006611165101776388,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 12,
        "name" : "new",
        "SelfLoops" : 0,
        "SUID" : 30576,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.133786848072562,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : -96.96239027836441,
        "y" : -47.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30574",
        "ClosenessCentrality" : 0.27876106194690264,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9520870076425632,
        "Stress" : 2114,
        "TopologicalCoefficient" : 0.5759493670886076,
        "shared_name" : "odd",
        "BetweennessCentrality" : 4.2323757644538294E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 6,
        "name" : "odd",
        "SelfLoops" : 0,
        "SUID" : 30574,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5873015873015874,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.5
      },
      "position" : {
        "x" : -56.858392600996694,
        "y" : -198.91553796180324
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30572",
        "ClosenessCentrality" : 0.2808917197452229,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525909129083732,
        "Stress" : 2904,
        "TopologicalCoefficient" : 0.5352941176470588,
        "shared_name" : "raw",
        "BetweennessCentrality" : 9.278491128626697E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 14,
        "name" : "raw",
        "SelfLoops" : 0,
        "SUID" : 30572,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.560090702947846,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.5
      },
      "position" : {
        "x" : -160.9623902783644,
        "y" : -303.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30570",
        "ClosenessCentrality" : 0.27876106194690264,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9520870076425632,
        "Stress" : 2114,
        "TopologicalCoefficient" : 0.5759493670886076,
        "shared_name" : "striped",
        "BetweennessCentrality" : 4.2323757644538294E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 15,
        "name" : "striped",
        "SelfLoops" : 0,
        "SUID" : 30570,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5873015873015874,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.5
      },
      "position" : {
        "x" : -68.96239027836441,
        "y" : -176.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30568",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sweet",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 16,
        "name" : "sweet",
        "SelfLoops" : 0,
        "SUID" : 30568,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 167.35272465051094,
        "y" : 6.727707587052578
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30566",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "tyrannical",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "tyrannical",
        "SelfLoops" : 0,
        "SUID" : 30566,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 250.0376097216356,
        "y" : 61.97598147039048
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30564",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "usoooooopp",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "usoooooopp",
        "SelfLoops" : 0,
        "SUID" : 30564,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 313.32188096909726,
        "y" : 35.76277803479411
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30562",
        "ClosenessCentrality" : 0.2663043478260869,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9489795918367347,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "vulgar",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "vulgar",
        "SelfLoops" : 0,
        "SUID" : 30562,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7551020408163267,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 313.3218809690977,
        "y" : -90.80576446012958
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30560",
        "ClosenessCentrality" : 0.36326194398682043,
        "Eccentricity" : 5,
        "Degree" : 45,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9675401024607374,
        "Stress" : 379514,
        "TopologicalCoefficient" : 0.20404040404040405,
        "shared_name" : "vol-10",
        "BetweennessCentrality" : 0.07723519384941656,
        "NumberOfUndirectedEdges" : 45,
        "name" : "vol-10",
        "SelfLoops" : 0,
        "SUID" : 30560,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.752834467120181,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.488888888888889
      },
      "position" : {
        "x" : -218.7750285625757,
        "y" : -453.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30558",
        "ClosenessCentrality" : 0.287109375,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.954018644494835,
        "Stress" : 5288,
        "TopologicalCoefficient" : 0.39933993399339934,
        "shared_name" : "bottom",
        "BetweennessCentrality" : 0.0012452418948992732,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 12,
        "name" : "bottom",
        "SelfLoops" : 0,
        "SUID" : 30558,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4829931972789114,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.333333333333336
      },
      "position" : {
        "x" : 126.03760972163559,
        "y" : -201.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30556",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "bzzzt",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "bzzzt",
        "SelfLoops" : 0,
        "SUID" : 30556,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -165.64453755094374,
        "y" : -377.14916770674813
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30554",
        "ClosenessCentrality" : 0.3105633802816901,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9588897287309985,
        "Stress" : 20756,
        "TopologicalCoefficient" : 0.2787096774193548,
        "shared_name" : "certain",
        "BetweennessCentrality" : 0.004657152392059431,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 7,
        "name" : "certain",
        "SelfLoops" : 0,
        "SUID" : 30554,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2199546485260773,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.2
      },
      "position" : {
        "x" : -216.9623902783644,
        "y" : 48.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30552",
        "ClosenessCentrality" : 0.3028846153846154,
        "Eccentricity" : 6,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9573780129335684,
        "Stress" : 14778,
        "TopologicalCoefficient" : 0.28776978417266186,
        "shared_name" : "chinese",
        "BetweennessCentrality" : 0.0027724636771219407,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 4,
        "name" : "chinese",
        "SelfLoops" : 0,
        "SUID" : 30552,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3015873015873014,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -53.96239027836441,
        "y" : 287.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30550",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "crazy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "crazy",
        "SelfLoops" : 0,
        "SUID" : 30550,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -310.5242411413026,
        "y" : -419.0718323957868
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30548",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "decorative",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "decorative",
        "SelfLoops" : 0,
        "SUID" : 30548,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -261.7364930132887,
        "y" : -360.73710630283
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30546",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "dreadful",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "dreadful",
        "SelfLoops" : 0,
        "SUID" : 30546,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -143.48496180598363,
        "y" : -405.13550533980765
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30544",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "favorite",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "favorite",
        "SelfLoops" : 0,
        "SUID" : 30544,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -231.51184719796254,
        "y" : -542.108012648155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30542",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "final",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "final",
        "SelfLoops" : 0,
        "SUID" : 30542,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -304.6472266772115,
        "y" : -478.7358455859771
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30540",
        "ClosenessCentrality" : 0.2777078085642317,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9518350550096583,
        "Stress" : 2616,
        "TopologicalCoefficient" : 0.39111111111111113,
        "shared_name" : "fine",
        "BetweennessCentrality" : 6.102313948108642E-4,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 10,
        "name" : "fine",
        "SelfLoops" : 0,
        "SUID" : 30540,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.600907029478458,
        "selected" : false,
        "NeighborhoodConnectivity" : 30.333333333333332
      },
      "position" : {
        "x" : 136.0376097216356,
        "y" : -57.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30538",
        "ClosenessCentrality" : 0.30455801104972374,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9577139497774418,
        "Stress" : 14972,
        "TopologicalCoefficient" : 0.3350694444444444,
        "shared_name" : "funny",
        "BetweennessCentrality" : 0.0028820099680321354,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 5,
        "name" : "funny",
        "SelfLoops" : 0,
        "SUID" : 30538,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2834467120181405,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.25
      },
      "position" : {
        "x" : 101.03760972163536,
        "y" : -248.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30536",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "gigantic",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "gigantic",
        "SelfLoops" : 0,
        "SUID" : 30536,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -143.48496180598374,
        "y" : -501.9074810855284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30534",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "glad",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "glad",
        "SelfLoops" : 0,
        "SUID" : 30534,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -280.34054400044437,
        "y" : -526.0877274112894
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30532",
        "ClosenessCentrality" : 0.3123229461756374,
        "Eccentricity" : 4,
        "Degree" : 6,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.959225665574872,
        "Stress" : 23478,
        "TopologicalCoefficient" : 0.2542194092827004,
        "shared_name" : "main",
        "BetweennessCentrality" : 0.004060648359953511,
        "NumberOfUndirectedEdges" : 6,
        "synsetCount" : 5,
        "name" : "main",
        "SelfLoops" : 0,
        "SUID" : 30532,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.201814058956916,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.166666666666664
      },
      "position" : {
        "x" : 79.03760972163559,
        "y" : 140.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30530",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "pointless",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "pointless",
        "SelfLoops" : 0,
        "SUID" : 30530,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -280.7417044992534,
        "y" : -383.36509433055505
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30528",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sixth",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "sixth",
        "SelfLoops" : 0,
        "SUID" : 30528,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -129.2775538795173,
        "y" : -453.52149321266796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30526",
        "ClosenessCentrality" : 0.2834190231362468,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9531788023851516,
        "Stress" : 4392,
        "TopologicalCoefficient" : 0.41025641025641024,
        "shared_name" : "straight",
        "BetweennessCentrality" : 0.0010710004119741786,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 21,
        "name" : "straight",
        "SelfLoops" : 0,
        "SUID" : 30526,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5283446712018143,
        "selected" : false,
        "NeighborhoodConnectivity" : 38.333333333333336
      },
      "position" : {
        "x" : 216.0376097216356,
        "y" : -230.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30524",
        "ClosenessCentrality" : 0.30205479452054795,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9572100445116318,
        "Stress" : 14970,
        "TopologicalCoefficient" : 0.32065217391304346,
        "shared_name" : "sudden",
        "BetweennessCentrality" : 0.002928290289448312,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 1,
        "name" : "sudden",
        "SelfLoops" : 0,
        "SUID" : 30524,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.310657596371882,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.25
      },
      "position" : {
        "x" : 275.03760972163536,
        "y" : -204.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30522",
        "ClosenessCentrality" : 0.28053435114503816,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525069286974049,
        "Stress" : 2200,
        "TopologicalCoefficient" : 0.5773809523809523,
        "shared_name" : "tall",
        "BetweennessCentrality" : 3.400064166382223E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 5,
        "name" : "tall",
        "SelfLoops" : 0,
        "SUID" : 30522,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.564625850340136,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.5
      },
      "position" : {
        "x" : -812.9623902783644,
        "y" : -207.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30520",
        "ClosenessCentrality" : 0.2666263603385732,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9490635760477031,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "unyielding",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "unyielding",
        "SelfLoops" : 0,
        "SUID" : 30520,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.750566893424036,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -187.3645632494663,
        "y" : -533.945548527585
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30518",
        "ClosenessCentrality" : 0.29400000000000004,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.955530360292265,
        "Stress" : 7718,
        "TopologicalCoefficient" : 0.39775910364145656,
        "shared_name" : "upper",
        "BetweennessCentrality" : 0.0016605257231849073,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 6,
        "name" : "upper",
        "SelfLoops" : 0,
        "SUID" : 30518,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.401360544217687,
        "selected" : false,
        "NeighborhoodConnectivity" : 48.333333333333336
      },
      "position" : {
        "x" : -194.96239027836452,
        "y" : -763.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30516",
        "ClosenessCentrality" : 0.22408536585365857,
        "Eccentricity" : 5,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.935878054925674,
        "Stress" : 24294,
        "TopologicalCoefficient" : 0.5,
        "shared_name" : "vol-11",
        "BetweennessCentrality" : 0.0045351473922902496,
        "NumberOfUndirectedEdges" : 2,
        "name" : "vol-11",
        "SelfLoops" : 0,
        "SUID" : 30516,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.462585034013605,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.5
      },
      "position" : {
        "x" : -83.96239027836441,
        "y" : 1232.4785067873322
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30514",
        "ClosenessCentrality" : 0.18313953488372092,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9174015285126396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "frequent",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "frequent",
        "SelfLoops" : 0,
        "SUID" : 30514,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 5.4603174603174605,
        "selected" : false,
        "NeighborhoodConnectivity" : 2.0
      },
      "position" : {
        "x" : -90.96239027836441,
        "y" : 1291.4785067873322
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30512",
        "ClosenessCentrality" : 0.2612559241706161,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9476358444612414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "blurry",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "blurry",
        "SelfLoops" : 0,
        "SUID" : 30512,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8276643990929706,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 465.4594810759529,
        "y" : 17.58979920892284
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30510",
        "ClosenessCentrality" : 0.35336538461538464,
        "Eccentricity" : 5,
        "Degree" : 28,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9661123708742756,
        "Stress" : 145056,
        "TopologicalCoefficient" : 0.17045454545454544,
        "shared_name" : "vol-13",
        "BetweennessCentrality" : 0.05182875548094584,
        "NumberOfUndirectedEdges" : 28,
        "name" : "vol-13",
        "SelfLoops" : 0,
        "SUID" : 30510,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.8299319727891157,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.75
      },
      "position" : {
        "x" : 451.6374369470134,
        "y" : 95.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30508",
        "ClosenessCentrality" : 0.2725587144622992,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9505752918451331,
        "Stress" : 1258,
        "TopologicalCoefficient" : 0.5327868852459017,
        "shared_name" : "close",
        "BetweennessCentrality" : 3.5259684961386076E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 37,
        "name" : "close",
        "SelfLoops" : 0,
        "SUID" : 30508,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6689342403628116,
        "selected" : false,
        "NeighborhoodConnectivity" : 33.5
      },
      "position" : {
        "x" : 395.0376097216356,
        "y" : -70.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30506",
        "ClosenessCentrality" : 0.2612559241706161,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9476358444612414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "confusing",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "confusing",
        "SelfLoops" : 0,
        "SUID" : 30506,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8276643990929706,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 376.83980274981104,
        "y" : 123.2026192286454
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30504",
        "ClosenessCentrality" : 0.2612559241706161,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9476358444612414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "excellent",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "excellent",
        "SelfLoops" : 0,
        "SUID" : 30504,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8276643990929706,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 512.6130270152755,
        "y" : 44.81391165023604
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30502",
        "ClosenessCentrality" : 0.2612559241706161,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9476358444612414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "graphic",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "graphic",
        "SelfLoops" : 0,
        "SUID" : 30502,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8276643990929706,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 376.83980274981104,
        "y" : 68.75439434601878
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30500",
        "ClosenessCentrality" : 0.2612559241706161,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9476358444612414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "impressive",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "impressive",
        "SelfLoops" : 0,
        "SUID" : 30500,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8276643990929706,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 512.6130270152755,
        "y" : 147.14310192442815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30498",
        "ClosenessCentrality" : 0.2612559241706161,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9476358444612414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "likely",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "likely",
        "SelfLoops" : 0,
        "SUID" : 30498,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8276643990929706,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 531.2354166934599,
        "y" : 95.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30496",
        "ClosenessCentrality" : 0.28562176165803105,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9536827076509616,
        "Stress" : 5720,
        "TopologicalCoefficient" : 0.3929824561403509,
        "shared_name" : "naked",
        "BetweennessCentrality" : 0.0015579251812382936,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 5,
        "name" : "naked",
        "SelfLoops" : 0,
        "SUID" : 30496,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5011337868480727,
        "selected" : false,
        "NeighborhoodConnectivity" : 38.333333333333336
      },
      "position" : {
        "x" : 234.0376097216356,
        "y" : 430.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30494",
        "ClosenessCentrality" : 0.2612559241706161,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9476358444612414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "outward",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "outward",
        "SelfLoops" : 0,
        "SUID" : 30494,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8276643990929706,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 465.4594810759529,
        "y" : 174.36721436574146
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30492",
        "ClosenessCentrality" : 0.2612559241706161,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9476358444612414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sighted",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "sighted",
        "SelfLoops" : 0,
        "SUID" : 30492,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8276643990929706,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 411.8384470737899,
        "y" : 27.044634236990078
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30490",
        "ClosenessCentrality" : 0.2659831121833534,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488956076257664,
        "Stress" : 1976,
        "TopologicalCoefficient" : 0.5121951219512195,
        "shared_name" : "white",
        "BetweennessCentrality" : 5.222320593619123E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 25,
        "name" : "white",
        "SelfLoops" : 0,
        "SUID" : 30490,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.759637188208617,
        "selected" : false,
        "NeighborhoodConnectivity" : 22.0
      },
      "position" : {
        "x" : 403.0376097216356,
        "y" : 200.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30488",
        "ClosenessCentrality" : 0.2612559241706161,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9476358444612414,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "worthy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "worthy",
        "SelfLoops" : 0,
        "SUID" : 30488,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8276643990929706,
        "selected" : false,
        "NeighborhoodConnectivity" : 28.0
      },
      "position" : {
        "x" : 411.8384470737899,
        "y" : 164.91237933767422
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30486",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "41st",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "41st",
        "SelfLoops" : 0,
        "SUID" : 30486,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 317.39788577469244,
        "y" : -615.8035985239567
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30484",
        "ClosenessCentrality" : 0.3614754098360656,
        "Eccentricity" : 5,
        "Degree" : 42,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9672881498278324,
        "Stress" : 306252,
        "TopologicalCoefficient" : 0.16558441558441558,
        "shared_name" : "vol-12",
        "BetweennessCentrality" : 0.08341934564346609,
        "NumberOfUndirectedEdges" : 42,
        "name" : "vol-12",
        "SelfLoops" : 0,
        "SUID" : 30484,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.766439909297052,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.642857142857143
      },
      "position" : {
        "x" : 238.0376097216356,
        "y" : -654.0214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30482",
        "ClosenessCentrality" : 0.2901315789473684,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9546905181825817,
        "Stress" : 6276,
        "TopologicalCoefficient" : 0.40498442367601245,
        "shared_name" : "cold",
        "BetweennessCentrality" : 0.0013115570970996472,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 16,
        "name" : "cold",
        "SelfLoops" : 0,
        "SUID" : 30482,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4467120181405897,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.333333333333336
      },
      "position" : {
        "x" : 26.03760972163559,
        "y" : 280.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30480",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "complicated",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "complicated",
        "SelfLoops" : 0,
        "SUID" : 30480,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 183.11859469842852,
        "y" : -722.8877598352718
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30478",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "facial",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "facial",
        "SelfLoops" : 0,
        "SUID" : 30478,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 257.63797925212816,
        "y" : -568.1466633501118
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30476",
        "ClosenessCentrality" : 0.3083916083916084,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9584698076761569,
        "Stress" : 16088,
        "TopologicalCoefficient" : 0.3104575163398693,
        "shared_name" : "hard",
        "BetweennessCentrality" : 0.003670288535717778,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 22,
        "name" : "hard",
        "SelfLoops" : 0,
        "SUID" : 30476,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2426303854875282,
        "selected" : false,
        "NeighborhoodConnectivity" : 48.5
      },
      "position" : {
        "x" : -264.9623902783644,
        "y" : -337.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30474",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "hot",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 21,
        "name" : "hot",
        "SelfLoops" : 0,
        "SUID" : 30474,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 158.6773336685785,
        "y" : -615.8035985239568
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30472",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "la",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "la",
        "SelfLoops" : 0,
        "SUID" : 30472,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 292.95662474484266,
        "y" : -585.1552265900641
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30470",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "local",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "local",
        "SelfLoops" : 0,
        "SUID" : 30470,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 257.63797925212816,
        "y" : -739.8963230752239
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30468",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "lucky",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "lucky",
        "SelfLoops" : 0,
        "SUID" : 30468,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 149.9543486009502,
        "y" : -654.0214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30466",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "ooh",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "ooh",
        "SelfLoops" : 0,
        "SUID" : 30466,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 218.43724019114256,
        "y" : -568.1466633501118
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30464",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "part",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 18,
        "name" : "part",
        "SelfLoops" : 0,
        "SUID" : 30464,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 326.12087084232076,
        "y" : -654.0214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30462",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "previous",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "previous",
        "SelfLoops" : 0,
        "SUID" : 30462,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 218.43724019114256,
        "y" : -739.8963230752239
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30460",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "several",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "several",
        "SelfLoops" : 0,
        "SUID" : 30460,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 183.1185946984283,
        "y" : -585.1552265900641
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30458",
        "ClosenessCentrality" : 0.279467680608365,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9522549760644999,
        "Stress" : 2250,
        "TopologicalCoefficient" : 0.5617283950617284,
        "shared_name" : "sexy",
        "BetweennessCentrality" : 4.699983929869657E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 2,
        "name" : "sexy",
        "SelfLoops" : 0,
        "SUID" : 30458,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.578231292517007,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.5
      },
      "position" : {
        "x" : 372.0376097216356,
        "y" : -716.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30456",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "specific",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "specific",
        "SelfLoops" : 0,
        "SUID" : 30456,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 292.95662474484266,
        "y" : -722.8877598352717
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30454",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "splendid",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "splendid",
        "SelfLoops" : 0,
        "SUID" : 30454,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 158.6773336685785,
        "y" : -692.239387901379
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30452",
        "ClosenessCentrality" : 0.275625,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9513311497438481,
        "Stress" : 1582,
        "TopologicalCoefficient" : 0.5642857142857143,
        "shared_name" : "uhhh",
        "BetweennessCentrality" : 2.88469013707563E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 0,
        "name" : "uhhh",
        "SelfLoops" : 0,
        "SUID" : 30452,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6281179138321997,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.5
      },
      "position" : {
        "x" : 512.0376097216356,
        "y" : -805.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30450",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "unauthorized",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "unauthorized",
        "SelfLoops" : 0,
        "SUID" : 30450,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 317.39788577469244,
        "y" : -692.2393879013789
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30448",
        "ClosenessCentrality" : 0.2901315789473684,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9546905181825817,
        "Stress" : 6448,
        "TopologicalCoefficient" : 0.40672782874617736,
        "shared_name" : "2nd",
        "BetweennessCentrality" : 0.0013033094771709459,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 1,
        "name" : "2nd",
        "SelfLoops" : 0,
        "SUID" : 30448,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4467120181405897,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.333333333333336
      },
      "position" : {
        "x" : 388.0376097216356,
        "y" : -98.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30446",
        "ClosenessCentrality" : 0.3668885191347753,
        "Eccentricity" : 5,
        "Degree" : 51,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9680440077265474,
        "Stress" : 402646,
        "TopologicalCoefficient" : 0.1532976827094474,
        "shared_name" : "vol-23",
        "BetweennessCentrality" : 0.09949817658295823,
        "NumberOfUndirectedEdges" : 51,
        "name" : "vol-23",
        "SelfLoops" : 0,
        "SUID" : 30446,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.72562358276644,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.372549019607843
      },
      "position" : {
        "x" : 333.69619826611756,
        "y" : -446.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30444",
        "ClosenessCentrality" : 0.2777078085642317,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9518350550096583,
        "Stress" : 1700,
        "TopologicalCoefficient" : 0.5789473684210527,
        "shared_name" : "5th",
        "BetweennessCentrality" : 2.6679688161648573E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 1,
        "name" : "5th",
        "SelfLoops" : 0,
        "SUID" : 30444,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.600907029478458,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : 595.0376097216356,
        "y" : -728.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30442",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "6th",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "6th",
        "SelfLoops" : 0,
        "SUID" : 30442,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 386.14328829329384,
        "y" : -522.5042208045729
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30440",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "7th",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "7th",
        "SelfLoops" : 0,
        "SUID" : 30440,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 264.5892684283865,
        "y" : -507.74489064393805
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30438",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "afraid",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "afraid",
        "SelfLoops" : 0,
        "SUID" : 30438,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 264.5892684283863,
        "y" : -385.29809578139793
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30436",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "best",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 43,
        "name" : "best",
        "SelfLoops" : 0,
        "SUID" : 30436,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 386.14328829329384,
        "y" : -370.5387656207628
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30434",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "changed",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 13,
        "name" : "changed",
        "SelfLoops" : 0,
        "SUID" : 30434,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 344.8248559716096,
        "y" : -538.174235246381
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30432",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "dedicated",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "dedicated",
        "SelfLoops" : 0,
        "SUID" : 30432,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 244.0531193693489,
        "y" : -424.4264586905854
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30430",
        "ClosenessCentrality" : 0.2936085219707057,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9554463760812967,
        "Stress" : 8336,
        "TopologicalCoefficient" : 0.3347826086956522,
        "shared_name" : "different",
        "BetweennessCentrality" : 0.0013395339615090483,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 5,
        "name" : "different",
        "SelfLoops" : 0,
        "SUID" : 30430,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4058956916099774,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.5
      },
      "position" : {
        "x" : 115.03760972163536,
        "y" : 118.47850678733187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30428",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "duper",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "duper",
        "SelfLoops" : 0,
        "SUID" : 30428,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 415.44672434570475,
        "y" : -403.61550726274345
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30426",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "esoteric",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "esoteric",
        "SelfLoops" : 0,
        "SUID" : 30426,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 415.44672434570475,
        "y" : -489.42747916259236
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30424",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "fair",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 17,
        "name" : "fair",
        "SelfLoops" : 0,
        "SUID" : 30424,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 244.0531193693489,
        "y" : -468.6165277347506
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30422",
        "ClosenessCentrality" : 0.2728960396039604,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9506592760561015,
        "Stress" : 918,
        "TopologicalCoefficient" : 0.5806451612903226,
        "shared_name" : "foreign",
        "BetweennessCentrality" : 1.7867272661728574E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "foreign",
        "SelfLoops" : 0,
        "SUID" : 30422,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6643990929705215,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.0
      },
      "position" : {
        "x" : -59.96239027836441,
        "y" : -424.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30420",
        "ClosenessCentrality" : 0.28233034571062743,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9529268497522466,
        "Stress" : 2562,
        "TopologicalCoefficient" : 0.5674157303370787,
        "shared_name" : "free",
        "BetweennessCentrality" : 4.039677230998583E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 22,
        "name" : "free",
        "SelfLoops" : 0,
        "SUID" : 30420,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5419501133786846,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.5
      },
      "position" : {
        "x" : 824.0376097216356,
        "y" : -446.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30418",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "humorous",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "humorous",
        "SelfLoops" : 0,
        "SUID" : 30418,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 300.9569822844612,
        "y" : -532.847711023544
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30416",
        "ClosenessCentrality" : 0.2819693094629156,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9528428655412782,
        "Stress" : 2864,
        "TopologicalCoefficient" : 0.5397727272727273,
        "shared_name" : "ish",
        "BetweennessCentrality" : 6.799329626111266E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 0,
        "name" : "ish",
        "SelfLoops" : 0,
        "SUID" : 30416,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.546485260770975,
        "selected" : false,
        "NeighborhoodConnectivity" : 48.5
      },
      "position" : {
        "x" : 362.0376097216356,
        "y" : -12.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30414",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "professional",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 8,
        "name" : "professional",
        "SelfLoops" : 0,
        "SUID" : 30414,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 300.95698228446076,
        "y" : -360.19527540179195
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30412",
        "ClosenessCentrality" : 0.2808917197452229,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525909129083732,
        "Stress" : 3024,
        "TopologicalCoefficient" : 0.5352941176470588,
        "shared_name" : "proper",
        "BetweennessCentrality" : 6.977309908118682E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "proper",
        "SelfLoops" : 0,
        "SUID" : 30412,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.560090702947846,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.5
      },
      "position" : {
        "x" : 637.0376097216356,
        "y" : 17.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30410",
        "ClosenessCentrality" : 0.2728960396039604,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9506592760561015,
        "Stress" : 918,
        "TopologicalCoefficient" : 0.5806451612903226,
        "shared_name" : "strange",
        "BetweennessCentrality" : 1.7867272661728574E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 3,
        "name" : "strange",
        "SelfLoops" : 0,
        "SUID" : 30410,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6643990929705215,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.0
      },
      "position" : {
        "x" : 107.03760972163559,
        "y" : -326.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30408",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "western",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "western",
        "SelfLoops" : 0,
        "SUID" : 30408,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 344.8248559716094,
        "y" : -354.86875117895477
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30406",
        "ClosenessCentrality" : 0.2685749086479903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9495674813135131,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "worldly",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "worldly",
        "SelfLoops" : 0,
        "SUID" : 30406,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7233560090702946,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.0
      },
      "position" : {
        "x" : 426.0221000739223,
        "y" : -446.52149321266796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30404",
        "ClosenessCentrality" : 0.35055643879173287,
        "Eccentricity" : 5,
        "Degree" : 23,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.965692449819434,
        "Stress" : 110048,
        "TopologicalCoefficient" : 0.20948616600790515,
        "shared_name" : "vol-22",
        "BetweennessCentrality" : 0.033721186272447315,
        "NumberOfUndirectedEdges" : 23,
        "name" : "vol-22",
        "SelfLoops" : 0,
        "SUID" : 30404,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.852607709750567,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.608695652173913
      },
      "position" : {
        "x" : 379.57172439317515,
        "y" : 515.4785067873319
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30402",
        "ClosenessCentrality" : 0.2732342007434944,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9507432602670698,
        "Stress" : 1264,
        "TopologicalCoefficient" : 0.5317460317460317,
        "shared_name" : "basic",
        "BetweennessCentrality" : 4.0710975129751737E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 6,
        "name" : "basic",
        "SelfLoops" : 0,
        "SUID" : 30402,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6598639455782314,
        "selected" : false,
        "NeighborhoodConnectivity" : 34.5
      },
      "position" : {
        "x" : 41.03760972163559,
        "y" : 464.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30400",
        "ClosenessCentrality" : 0.2597173144876325,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9472159234063996,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "direct",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 24,
        "name" : "direct",
        "SelfLoops" : 0,
        "SUID" : 30400,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8503401360544216,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : 316.3197288660224,
        "y" : 469.5232420556507
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30398",
        "ClosenessCentrality" : 0.2597173144876325,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9472159234063996,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "expeditionary",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "expeditionary",
        "SelfLoops" : 0,
        "SUID" : 30398,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8503401360544216,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : 403.7318368282911,
        "y" : 589.8356870851918
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30396",
        "ClosenessCentrality" : 0.2705521472392638,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9500713865793231,
        "Stress" : 918,
        "TopologicalCoefficient" : 0.5454545454545454,
        "shared_name" : "green",
        "BetweennessCentrality" : 2.153273004600779E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 14,
        "name" : "green",
        "SelfLoops" : 0,
        "SUID" : 30396,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.696145124716553,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : 749.0376097216356,
        "y" : 239.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30394",
        "ClosenessCentrality" : 0.30246913580246915,
        "Eccentricity" : 4,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9572940287226002,
        "Stress" : 14084,
        "TopologicalCoefficient" : 0.275,
        "shared_name" : "japanese",
        "BetweennessCentrality" : 0.0025831736788353233,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 3,
        "name" : "japanese",
        "SelfLoops" : 0,
        "SUID" : 30394,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.306122448979592,
        "selected" : false,
        "NeighborhoodConnectivity" : 38.4
      },
      "position" : {
        "x" : 82.03760972163559,
        "y" : 69.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30392",
        "ClosenessCentrality" : 0.2597173144876325,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9472159234063996,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "korean",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "korean",
        "SelfLoops" : 0,
        "SUID" : 30392,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8503401360544216,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : 316.3197288660224,
        "y" : 561.4337715190135
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30390",
        "ClosenessCentrality" : 0.28378378378378377,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9532627865961198,
        "Stress" : 4164,
        "TopologicalCoefficient" : 0.39855072463768115,
        "shared_name" : "mysterious",
        "BetweennessCentrality" : 9.477102615540401E-4,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 2,
        "name" : "mysterious",
        "SelfLoops" : 0,
        "SUID" : 30390,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5238095238095237,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.666666666666664
      },
      "position" : {
        "x" : -186.96239027836452,
        "y" : 96.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30388",
        "ClosenessCentrality" : 0.2597173144876325,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9472159234063996,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "suigun",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "suigun",
        "SelfLoops" : 0,
        "SUID" : 30388,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8503401360544216,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : 403.7318368282911,
        "y" : 441.12132648947215
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30386",
        "ClosenessCentrality" : 0.2656626506024096,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9488116234147981,
        "Stress" : 512,
        "TopologicalCoefficient" : 0.55,
        "shared_name" : "unique",
        "BetweennessCentrality" : 1.3432984109958344E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "unique",
        "SelfLoops" : 0,
        "SUID" : 30386,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.764172335600907,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : 260.0376097216356,
        "y" : 128.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30384",
        "ClosenessCentrality" : 0.28748370273794005,
        "Eccentricity" : 6,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9541026287058033,
        "Stress" : 12982,
        "TopologicalCoefficient" : 0.3094059405940594,
        "shared_name" : "weird",
        "BetweennessCentrality" : 0.002495498462698946,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 3,
        "name" : "weird",
        "SelfLoops" : 0,
        "SUID" : 30384,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4784580498866213,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.25
      },
      "position" : {
        "x" : -14.962390278364637,
        "y" : -52.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30382",
        "ClosenessCentrality" : 0.2597173144876325,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9472159234063996,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "widespread",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "widespread",
        "SelfLoops" : 0,
        "SUID" : 30382,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8503401360544216,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : 457.7554905772488,
        "y" : 515.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30380",
        "ClosenessCentrality" : 0.28160919540229884,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9527588813303098,
        "Stress" : 2640,
        "TopologicalCoefficient" : 0.5632183908045977,
        "shared_name" : "17th",
        "BetweennessCentrality" : 5.147369147062584E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 1,
        "name" : "17th",
        "SelfLoops" : 0,
        "SUID" : 30380,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5510204081632653,
        "selected" : false,
        "NeighborhoodConnectivity" : 50.0
      },
      "position" : {
        "x" : -437.9623902783644,
        "y" : 253.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30378",
        "ClosenessCentrality" : 0.36872909698996653,
        "Eccentricity" : 5,
        "Degree" : 54,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9682959603594524,
        "Stress" : 484864,
        "TopologicalCoefficient" : 0.17255892255892255,
        "shared_name" : "vol-20",
        "BetweennessCentrality" : 0.10797911453827218,
        "NumberOfUndirectedEdges" : 54,
        "name" : "vol-20",
        "SelfLoops" : 0,
        "SUID" : 30378,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7120181405895694,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.796296296296297
      },
      "position" : {
        "x" : -774.4623902783644,
        "y" : 106.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30376",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "baroque",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "baroque",
        "SelfLoops" : 0,
        "SUID" : 30376,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -738.0484050780591,
        "y" : 194.88964371796226
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30374",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "dang",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "dang",
        "SelfLoops" : 0,
        "SUID" : 30374,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -810.8763754786694,
        "y" : 19.06736985670193
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30372",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "dear",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 8,
        "name" : "dear",
        "SelfLoops" : 0,
        "SUID" : 30372,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -869.6167192109151,
        "y" : 106.97850678733187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30370",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "dirty",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 13,
        "name" : "dirty",
        "SelfLoops" : 0,
        "SUID" : 30370,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -774.4623902783644,
        "y" : 202.13283571988256
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30368",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "editorial",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "editorial",
        "SelfLoops" : 0,
        "SUID" : 30368,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -679.3080613458136,
        "y" : 106.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30366",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "enthusiastic",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "enthusiastic",
        "SelfLoops" : 0,
        "SUID" : 30366,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -738.0484050780587,
        "y" : 19.067369856702044
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30364",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "extravagant",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "extravagant",
        "SelfLoops" : 0,
        "SUID" : 30364,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -841.7466615258261,
        "y" : 39.69423553987008
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30362",
        "ClosenessCentrality" : 0.2936085219707057,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9554463760812967,
        "Stress" : 7248,
        "TopologicalCoefficient" : 0.4166666666666667,
        "shared_name" : "female",
        "BetweennessCentrality" : 0.001114216006841021,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 5,
        "name" : "female",
        "SelfLoops" : 0,
        "SUID" : 30362,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4058956916099774,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.333333333333336
      },
      "position" : {
        "x" : -359.9623902783644,
        "y" : 80.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30360",
        "ClosenessCentrality" : 0.29051383399209485,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.95477450239355,
        "Stress" : 6276,
        "TopologicalCoefficient" : 0.396969696969697,
        "shared_name" : "former",
        "BetweennessCentrality" : 0.0011781000167693783,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 5,
        "name" : "former",
        "SelfLoops" : 0,
        "SUID" : 30360,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.442176870748299,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.666666666666664
      },
      "position" : {
        "x" : -138.96239027836452,
        "y" : -176.52149321266802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30358",
        "ClosenessCentrality" : 0.2763157894736842,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9514991181657848,
        "Stress" : 1366,
        "TopologicalCoefficient" : 0.5763888888888888,
        "shared_name" : "human",
        "BetweennessCentrality" : 2.4674412862320776E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "human",
        "SelfLoops" : 0,
        "SUID" : 30358,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.619047619047619,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.5
      },
      "position" : {
        "x" : -720.9623902783644,
        "y" : 577.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30356",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "impressed",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 8,
        "name" : "impressed",
        "SelfLoops" : 0,
        "SUID" : 30356,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -862.3735272089945,
        "y" : 70.56452158702677
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30354",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "ostentatious",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "ostentatious",
        "SelfLoops" : 0,
        "SUID" : 30354,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -810.8763754786696,
        "y" : 194.88964371796226
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30352",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "picky",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "picky",
        "SelfLoops" : 0,
        "SUID" : 30352,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -707.1781190309023,
        "y" : 39.69423553987053
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30350",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "prevalent",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "prevalent",
        "SelfLoops" : 0,
        "SUID" : 30350,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -774.4623902783642,
        "y" : 11.82417785478151
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30348",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "relentless",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "relentless",
        "SelfLoops" : 0,
        "SUID" : 30348,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -841.7466615258263,
        "y" : 174.262778034794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30346",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sacred",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "sacred",
        "SelfLoops" : 0,
        "SUID" : 30346,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -686.5512533477342,
        "y" : 143.3924919876373
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30344",
        "ClosenessCentrality" : 0.28233034571062743,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9529268497522466,
        "Stress" : 2644,
        "TopologicalCoefficient" : 0.5674157303370787,
        "shared_name" : "scary",
        "BetweennessCentrality" : 4.3479762756947854E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 1,
        "name" : "scary",
        "SelfLoops" : 0,
        "SUID" : 30344,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5419501133786846,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.5
      },
      "position" : {
        "x" : -865.9623902783644,
        "y" : -324.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30342",
        "ClosenessCentrality" : 0.293218085106383,
        "Eccentricity" : 4,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9553623918703283,
        "Stress" : 6862,
        "TopologicalCoefficient" : 0.4289855072463768,
        "shared_name" : "secret",
        "BetweennessCentrality" : 9.641785894128876E-4,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 14,
        "name" : "secret",
        "SelfLoops" : 0,
        "SUID" : 30342,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4104308390022675,
        "selected" : false,
        "NeighborhoodConnectivity" : 50.333333333333336
      },
      "position" : {
        "x" : -1.9623902783644098,
        "y" : 341.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30340",
        "ClosenessCentrality" : 0.30969101123595505,
        "Eccentricity" : 6,
        "Degree" : 5,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.958721760309062,
        "Stress" : 30636,
        "TopologicalCoefficient" : 0.2632258064516129,
        "shared_name" : "simple",
        "BetweennessCentrality" : 0.005877261541319001,
        "NumberOfUndirectedEdges" : 5,
        "synsetCount" : 9,
        "name" : "simple",
        "SelfLoops" : 0,
        "SUID" : 30340,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.2290249433106575,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.8
      },
      "position" : {
        "x" : -43.96239027836441,
        "y" : 0.47850678733209406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30338",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "tense",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 8,
        "name" : "tense",
        "SelfLoops" : 0,
        "SUID" : 30338,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -707.1781190309025,
        "y" : 174.262778034794
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30336",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "tootin",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "tootin",
        "SelfLoops" : 0,
        "SUID" : 30336,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -686.551253347734,
        "y" : 70.56452158702723
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30334",
        "ClosenessCentrality" : 0.2830551989730424,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9530948181741833,
        "Stress" : 2984,
        "TopologicalCoefficient" : 0.554945054945055,
        "shared_name" : "top",
        "BetweennessCentrality" : 6.424328706710823E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 22,
        "name" : "top",
        "SelfLoops" : 0,
        "SUID" : 30334,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5328798185941044,
        "selected" : false,
        "NeighborhoodConnectivity" : 51.5
      },
      "position" : {
        "x" : -1069.9623902783644,
        "y" : -231.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30332",
        "ClosenessCentrality" : 0.26955990220048903,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.949819433946418,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "witted",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "witted",
        "SelfLoops" : 0,
        "SUID" : 30332,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.709750566893424,
        "selected" : false,
        "NeighborhoodConnectivity" : 54.0
      },
      "position" : {
        "x" : -862.3735272089946,
        "y" : 143.3924919876373
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30330",
        "ClosenessCentrality" : 0.35970636215334423,
        "Eccentricity" : 5,
        "Degree" : 39,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9670361971949274,
        "Stress" : 305852,
        "TopologicalCoefficient" : 0.22377622377622378,
        "shared_name" : "vol-21",
        "BetweennessCentrality" : 0.058813019507805826,
        "NumberOfUndirectedEdges" : 39,
        "name" : "vol-21",
        "SelfLoops" : 0,
        "SUID" : 30330,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7800453514739227,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.923076923076923
      },
      "position" : {
        "x" : 584.261452122962,
        "y" : -324.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30328",
        "ClosenessCentrality" : 0.2647058823529412,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.948559670781893,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "boring",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "boring",
        "SelfLoops" : 0,
        "SUID" : 30328,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7777777777777777,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.0
      },
      "position" : {
        "x" : 514.1447197619968,
        "y" : -375.4642811976787
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30326",
        "ClosenessCentrality" : 0.2784090909090909,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9520030234315948,
        "Stress" : 1990,
        "TopologicalCoefficient" : 0.5512820512820513,
        "shared_name" : "current",
        "BetweennessCentrality" : 3.164491927801198E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "current",
        "SelfLoops" : 0,
        "SUID" : 30326,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5918367346938775,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 153.0376097216356,
        "y" : -316.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30324",
        "ClosenessCentrality" : 0.2882352941176471,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.95427059712774,
        "Stress" : 6724,
        "TopologicalCoefficient" : 0.4166666666666667,
        "shared_name" : "large",
        "BetweennessCentrality" : 9.420739252456765E-4,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 11,
        "name" : "large",
        "SelfLoops" : 0,
        "SUID" : 30324,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.4693877551020407,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.333333333333336
      },
      "position" : {
        "x" : 917.0376097216356,
        "y" : 82.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30322",
        "ClosenessCentrality" : 0.2647058823529412,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.948559670781893,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "lonely",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "lonely",
        "SelfLoops" : 0,
        "SUID" : 30322,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7777777777777777,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.0
      },
      "position" : {
        "x" : 611.0436607047709,
        "y" : -406.9486556540952
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30320",
        "ClosenessCentrality" : 0.2647058823529412,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.948559670781893,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "most",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "most",
        "SelfLoops" : 0,
        "SUID" : 30320,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7777777777777777,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.0
      },
      "position" : {
        "x" : 611.0436607047709,
        "y" : -242.0943307712406
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30318",
        "ClosenessCentrality" : 0.27735849056603773,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9517510707986899,
        "Stress" : 1884,
        "TopologicalCoefficient" : 0.5533333333333333,
        "shared_name" : "orange",
        "BetweennessCentrality" : 3.565796329433346E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 6,
        "name" : "orange",
        "SelfLoops" : 0,
        "SUID" : 30318,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6054421768707483,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.5
      },
      "position" : {
        "x" : 422.0376097216356,
        "y" : -12.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30316",
        "ClosenessCentrality" : 0.2784090909090909,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9520030234315948,
        "Stress" : 1990,
        "TopologicalCoefficient" : 0.5512820512820513,
        "shared_name" : "second",
        "BetweennessCentrality" : 3.164491927801198E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 15,
        "name" : "second",
        "SelfLoops" : 0,
        "SUID" : 30316,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.5918367346938775,
        "selected" : false,
        "NeighborhoodConnectivity" : 44.0
      },
      "position" : {
        "x" : 126.03760972163559,
        "y" : -293.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30314",
        "ClosenessCentrality" : 0.2647058823529412,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.948559670781893,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sober",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "sober",
        "SelfLoops" : 0,
        "SUID" : 30314,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7777777777777777,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.0
      },
      "position" : {
        "x" : 670.9304996812741,
        "y" : -324.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30312",
        "ClosenessCentrality" : 0.2647058823529412,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.948559670781893,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "uhhhhhh",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "uhhhhhh",
        "SelfLoops" : 0,
        "SUID" : 30312,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7777777777777777,
        "selected" : false,
        "NeighborhoodConnectivity" : 39.0
      },
      "position" : {
        "x" : 514.1447197619971,
        "y" : -273.578705227657
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30310",
        "ClosenessCentrality" : 0.2718865598027127,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9504073234231964,
        "Stress" : 1504,
        "TopologicalCoefficient" : 0.5338983050847458,
        "shared_name" : "american",
        "BetweennessCentrality" : 2.961542083568261E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 5,
        "name" : "american",
        "SelfLoops" : 0,
        "SUID" : 30310,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6780045351473922,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.5
      },
      "position" : {
        "x" : 390.0376097216356,
        "y" : -27.521493212667906
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30308",
        "ClosenessCentrality" : 0.35795454545454547,
        "Eccentricity" : 5,
        "Degree" : 42,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9667842445620224,
        "Stress" : 393238,
        "TopologicalCoefficient" : 0.1893424036281179,
        "shared_name" : "vol-25",
        "BetweennessCentrality" : 0.09002521714627576,
        "NumberOfUndirectedEdges" : 42,
        "name" : "vol-25",
        "SelfLoops" : 0,
        "SUID" : 30308,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7936507936507935,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.976190476190476
      },
      "position" : {
        "x" : 740.5376097216356,
        "y" : 350.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30306",
        "ClosenessCentrality" : 0.2863636363636364,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9538506760728983,
        "Stress" : 6168,
        "TopologicalCoefficient" : 0.4006734006734007,
        "shared_name" : "dangerous",
        "BetweennessCentrality" : 0.0011874508694171468,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 2,
        "name" : "dangerous",
        "SelfLoops" : 0,
        "SUID" : 30306,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.492063492063492,
        "selected" : false,
        "NeighborhoodConnectivity" : 40.666666666666664
      },
      "position" : {
        "x" : 47.03760972163559,
        "y" : 339.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30304",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "english",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "english",
        "SelfLoops" : 0,
        "SUID" : 30304,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 821.9159318278839,
        "y" : 316.770502087758
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30302",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "fast",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 15,
        "name" : "fast",
        "SelfLoops" : 0,
        "SUID" : 30302,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 802.8218809690977,
        "y" : 288.1942355398704
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30300",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "favourite",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "favourite",
        "SelfLoops" : 0,
        "SUID" : 30300,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 678.2533384741737,
        "y" : 288.19423553986996
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30298",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "floaty",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "floaty",
        "SelfLoops" : 0,
        "SUID" : 30298,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 659.159287615387,
        "y" : 384.18651148690617
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30296",
        "ClosenessCentrality" : 0.28053435114503816,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525069286974049,
        "Stress" : 3166,
        "TopologicalCoefficient" : 0.5297619047619048,
        "shared_name" : "fun",
        "BetweennessCentrality" : 9.356451211724663E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "fun",
        "SelfLoops" : 0,
        "SUID" : 30296,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.564625850340136,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.5
      },
      "position" : {
        "x" : 34.03760972163559,
        "y" : -109.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30294",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "fuzzy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "fuzzy",
        "SelfLoops" : 0,
        "SUID" : 30294,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 821.9159318278839,
        "y" : 384.1865114869064
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30292",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "honorific",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "honorific",
        "SelfLoops" : 0,
        "SUID" : 30292,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 659.1592876153873,
        "y" : 316.77050208775756
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30290",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "late",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 11,
        "name" : "late",
        "SelfLoops" : 0,
        "SUID" : 30290,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 740.5376097216356,
        "y" : 438.56176790801726
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30288",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "massive",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "massive",
        "SelfLoops" : 0,
        "SUID" : 30288,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 706.8296050220615,
        "y" : 269.10018468108353
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30286",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "merry",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "merry",
        "SelfLoops" : 0,
        "SUID" : 30286,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 652.4543486009504,
        "y" : 350.47850678733187
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30284",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "near",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 9,
        "name" : "near",
        "SelfLoops" : 0,
        "SUID" : 30284,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 802.8218809690975,
        "y" : 412.76277803479377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30282",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "north",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 9,
        "name" : "north",
        "SelfLoops" : 0,
        "SUID" : 30282,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 774.2456144212101,
        "y" : 269.100184681084
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30280",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "related",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "related",
        "SelfLoops" : 0,
        "SUID" : 30280,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 678.2533384741735,
        "y" : 412.76277803479377
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30278",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "ro",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "ro",
        "SelfLoops" : 0,
        "SUID" : 30278,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 774.2456144212099,
        "y" : 431.8568288935802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30276",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "single",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 10,
        "name" : "single",
        "SelfLoops" : 0,
        "SUID" : 30276,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 740.5376097216358,
        "y" : 262.39524566664693
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30274",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sumo",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "sumo",
        "SelfLoops" : 0,
        "SUID" : 30274,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 706.8296050220613,
        "y" : 431.8568288935802
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30272",
        "ClosenessCentrality" : 0.263755980861244,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9483077181489881,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "violent",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "violent",
        "SelfLoops" : 0,
        "SUID" : 30272,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7913832199546484,
        "selected" : false,
        "NeighborhoodConnectivity" : 42.0
      },
      "position" : {
        "x" : 828.6208708423208,
        "y" : 350.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30270",
        "ClosenessCentrality" : 0.2621878715814506,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478877970941463,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "8th",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "8th",
        "SelfLoops" : 0,
        "SUID" : 30270,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8140589569161,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : -407.88879714955726,
        "y" : 505.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30268",
        "ClosenessCentrality" : 0.35507246376811596,
        "Eccentricity" : 5,
        "Degree" : 31,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9663643235071807,
        "Stress" : 206780,
        "TopologicalCoefficient" : 0.24486803519061584,
        "shared_name" : "vol-19",
        "BetweennessCentrality" : 0.04795068764883084,
        "NumberOfUndirectedEdges" : 31,
        "name" : "vol-19",
        "SelfLoops" : 0,
        "SUID" : 30268,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.816326530612245,
        "selected" : false,
        "NeighborhoodConnectivity" : 6.387096774193548
      },
      "position" : {
        "x" : -325.4623902783644,
        "y" : 505.9785067873323
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30266",
        "ClosenessCentrality" : 0.2621878715814506,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478877970941463,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "bloody",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "bloody",
        "SelfLoops" : 0,
        "SUID" : 30266,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8140589569161,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : -267.1781190309025,
        "y" : 564.2627780347938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30264",
        "ClosenessCentrality" : 0.2621878715814506,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478877970941463,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "fried",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "fried",
        "SelfLoops" : 0,
        "SUID" : 30264,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8140589569161,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : -325.4623902783644,
        "y" : 423.5520999161391
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30262",
        "ClosenessCentrality" : 0.2621878715814506,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478877970941463,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "possible",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "possible",
        "SelfLoops" : 0,
        "SUID" : 30262,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8140589569161,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : -383.7466615258262,
        "y" : 564.2627780347938
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30260",
        "ClosenessCentrality" : 0.2621878715814506,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478877970941463,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sayeen",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "sayeen",
        "SelfLoops" : 0,
        "SUID" : 30260,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8140589569161,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : -243.03598340717156,
        "y" : 505.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30258",
        "ClosenessCentrality" : 0.2621878715814506,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478877970941463,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "slow",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 11,
        "name" : "slow",
        "SelfLoops" : 0,
        "SUID" : 30258,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8140589569161,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : -383.7466615258263,
        "y" : 447.69423553986996
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30256",
        "ClosenessCentrality" : 0.2971698113207547,
        "Eccentricity" : 4,
        "Degree" : 4,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9562022339800117,
        "Stress" : 10112,
        "TopologicalCoefficient" : 0.32661290322580644,
        "shared_name" : "special",
        "BetweennessCentrality" : 0.0018228177736561483,
        "NumberOfUndirectedEdges" : 4,
        "synsetCount" : 10,
        "name" : "special",
        "SelfLoops" : 0,
        "SUID" : 30256,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.365079365079365,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.5
      },
      "position" : {
        "x" : -379.9623902783644,
        "y" : 54.478506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30254",
        "ClosenessCentrality" : 0.2621878715814506,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478877970941463,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "surprising",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "surprising",
        "SelfLoops" : 0,
        "SUID" : 30254,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8140589569161,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : -325.4623902783643,
        "y" : 588.4049136585248
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30252",
        "ClosenessCentrality" : 0.2791139240506329,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9521709918535315,
        "Stress" : 9908,
        "TopologicalCoefficient" : 0.4050632911392405,
        "shared_name" : "well",
        "BetweennessCentrality" : 0.001410869248630466,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 22,
        "name" : "well",
        "SelfLoops" : 0,
        "SUID" : 30252,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.582766439909297,
        "selected" : false,
        "NeighborhoodConnectivity" : 33.0
      },
      "position" : {
        "x" : 195.0376097216356,
        "y" : 338.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30250",
        "ClosenessCentrality" : 0.2621878715814506,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9478877970941463,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "worried",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 8,
        "name" : "worried",
        "SelfLoops" : 0,
        "SUID" : 30250,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8140589569161,
        "selected" : false,
        "NeighborhoodConnectivity" : 31.0
      },
      "position" : {
        "x" : -267.1781190309026,
        "y" : 447.69423553986996
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30248",
        "ClosenessCentrality" : 0.2672727272727273,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9492315444696396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "MOST",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "MOST",
        "SelfLoops" : 0,
        "SUID" : 30248,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.741496598639456,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -486.7611858892153,
        "y" : 737.5884459057171
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30246",
        "ClosenessCentrality" : 0.36446280991735536,
        "Eccentricity" : 3,
        "Degree" : 45,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9677080708826741,
        "Stress" : 390694,
        "TopologicalCoefficient" : 0.2038647342995169,
        "shared_name" : "vol-18",
        "BetweennessCentrality" : 0.07320086259037424,
        "NumberOfUndirectedEdges" : 45,
        "name" : "vol-18",
        "SelfLoops" : 0,
        "SUID" : 30246,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.743764172335601,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.688888888888889
      },
      "position" : {
        "x" : -402.6610693505718,
        "y" : 706.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30244",
        "ClosenessCentrality" : 0.2672727272727273,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9492315444696396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "actual",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "actual",
        "SelfLoops" : 0,
        "SUID" : 30244,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.741496598639456,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -387.1199959660664,
        "y" : 795.1163137302218
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30242",
        "ClosenessCentrality" : 0.2672727272727273,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9492315444696396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "beloved",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "beloved",
        "SelfLoops" : 0,
        "SUID" : 30242,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.741496598639456,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -334.1020261964335,
        "y" : 764.5063746118368
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30240",
        "ClosenessCentrality" : 0.2672727272727273,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9492315444696396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "embarrassing",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "embarrassing",
        "SelfLoops" : 0,
        "SUID" : 30240,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.741496598639456,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -313.1635946675134,
        "y" : 706.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30238",
        "ClosenessCentrality" : 0.2777078085642317,
        "Eccentricity" : 4,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9518350550096583,
        "Stress" : 1774,
        "TopologicalCoefficient" : 0.5675675675675675,
        "shared_name" : "hilarious",
        "BetweennessCentrality" : 2.9212728461640406E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 1,
        "name" : "hilarious",
        "SelfLoops" : 0,
        "SUID" : 30238,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.600907029478458,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.0
      },
      "position" : {
        "x" : -755.9623902783644,
        "y" : 436.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30236",
        "ClosenessCentrality" : 0.2672727272727273,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9492315444696396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "incredible",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "incredible",
        "SelfLoops" : 0,
        "SUID" : 30236,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.741496598639456,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -334.1020261964336,
        "y" : 649.4506389628272
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30234",
        "ClosenessCentrality" : 0.2672727272727273,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9492315444696396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "male",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "male",
        "SelfLoops" : 0,
        "SUID" : 30234,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.741496598639456,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -486.7611858892153,
        "y" : 676.3685676689469
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30232",
        "ClosenessCentrality" : 0.2672727272727273,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9492315444696396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "mighty",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "mighty",
        "SelfLoops" : 0,
        "SUID" : 30232,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.741496598639456,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -447.4098066921009,
        "y" : 784.4855934374153
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30230",
        "ClosenessCentrality" : 0.2672727272727273,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9492315444696396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "open",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 36,
        "name" : "open",
        "SelfLoops" : 0,
        "SUID" : 30230,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.741496598639456,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -387.11999596606654,
        "y" : 618.8406998444424
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30228",
        "ClosenessCentrality" : 0.2672727272727273,
        "Eccentricity" : 4,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9492315444696396,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "unapologetic",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "unapologetic",
        "SelfLoops" : 0,
        "SUID" : 30228,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.741496598639456,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -447.4098066921009,
        "y" : 629.4714201372489
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30226",
        "ClosenessCentrality" : 0.36386138613861385,
        "Eccentricity" : 5,
        "Degree" : 46,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9676240866717057,
        "Stress" : 357988,
        "TopologicalCoefficient" : 0.15810276679841898,
        "shared_name" : "vol-24",
        "BetweennessCentrality" : 0.09520374519802566,
        "NumberOfUndirectedEdges" : 46,
        "name" : "vol-24",
        "SelfLoops" : 0,
        "SUID" : 30226,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.748299319727891,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.478260869565218
      },
      "position" : {
        "x" : -65.96239027836441,
        "y" : 143.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30224",
        "ClosenessCentrality" : 0.2808917197452229,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525909129083732,
        "Stress" : 2540,
        "TopologicalCoefficient" : 0.5470588235294118,
        "shared_name" : "armed",
        "BetweennessCentrality" : 5.287100598546134E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 5,
        "name" : "armed",
        "SelfLoops" : 0,
        "SUID" : 30224,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.560090702947846,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.5
      },
      "position" : {
        "x" : -167.8544906021982,
        "y" : -159.7502166712535
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30222",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "calm",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 8,
        "name" : "calm",
        "SelfLoops" : 0,
        "SUID" : 30222,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 14.672048166956074,
        "y" : 105.14700783026763
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30220",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "clever",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "clever",
        "SelfLoops" : 0,
        "SUID" : 30220,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -134.22732797735776,
        "y" : 57.83641205238391
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30218",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "common",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 10,
        "name" : "common",
        "SelfLoops" : 0,
        "SUID" : 30218,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -121.76315303536148,
        "y" : 213.9504500959323
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30216",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "drawn",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 38,
        "name" : "drawn",
        "SelfLoops" : 0,
        "SUID" : 30216,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -10.161627521367336,
        "y" : 213.9504500959323
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30214",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "erotic",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "erotic",
        "SelfLoops" : 0,
        "SUID" : 30214,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -121.76315303536137,
        "y" : 74.00656347873166
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30212",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "instant",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "instant",
        "SelfLoops" : 0,
        "SUID" : 30212,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -46.0473286251588,
        "y" : 231.2320929256315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30210",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "jealous",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "jealous",
        "SelfLoops" : 0,
        "SUID" : 30210,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 14.672048166956074,
        "y" : 182.81000574439634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30208",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "major",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 13,
        "name" : "major",
        "SelfLoops" : 0,
        "SUID" : 30208,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -46.0473286251588,
        "y" : 56.72492064903247
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30206",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "marine",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "marine",
        "SelfLoops" : 0,
        "SUID" : 30206,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -146.5968287236849,
        "y" : 182.81000574439634
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30204",
        "ClosenessCentrality" : 0.2808917197452229,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525909129083732,
        "Stress" : 2540,
        "TopologicalCoefficient" : 0.5470588235294118,
        "shared_name" : "personal",
        "BetweennessCentrality" : 5.287100598546134E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 6,
        "name" : "personal",
        "SelfLoops" : 0,
        "SUID" : 30204,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.560090702947846,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.5
      },
      "position" : {
        "x" : -210.0702899545306,
        "y" : -131.29276975408231
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30202",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "presumptuous",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "presumptuous",
        "SelfLoops" : 0,
        "SUID" : 30202,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -146.5968287236849,
        "y" : 105.14700783026763
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30200",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "private",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "private",
        "SelfLoops" : 0,
        "SUID" : 30200,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -85.87745193157014,
        "y" : 231.2320929256315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30198",
        "ClosenessCentrality" : 0.2777078085642317,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9518350550096583,
        "Stress" : 1996,
        "TopologicalCoefficient" : 0.5592105263157895,
        "shared_name" : "proud",
        "BetweennessCentrality" : 4.501996784118074E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 2,
        "name" : "proud",
        "SelfLoops" : 0,
        "SUID" : 30198,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.600907029478458,
        "selected" : false,
        "NeighborhoodConnectivity" : 43.5
      },
      "position" : {
        "x" : -321.9623902783644,
        "y" : 312.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30196",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "red",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "red",
        "SelfLoops" : 0,
        "SUID" : 30196,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : 23.535084404693862,
        "y" : 143.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30194",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "regular",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 17,
        "name" : "regular",
        "SelfLoops" : 0,
        "SUID" : 30194,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -10.161627521367336,
        "y" : 74.00656347873178
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30192",
        "ClosenessCentrality" : 0.2669491525423729,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9491475602586713,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "royalist",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "royalist",
        "SelfLoops" : 0,
        "SUID" : 30192,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.746031746031746,
        "selected" : false,
        "NeighborhoodConnectivity" : 46.0
      },
      "position" : {
        "x" : -155.45986496142268,
        "y" : 143.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30190",
        "ClosenessCentrality" : 0.2819693094629156,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9528428655412782,
        "Stress" : 3076,
        "TopologicalCoefficient" : 0.5284090909090909,
        "shared_name" : "similar",
        "BetweennessCentrality" : 9.75554025306775E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 5,
        "name" : "similar",
        "SelfLoops" : 0,
        "SUID" : 30190,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.546485260770975,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.5
      },
      "position" : {
        "x" : -377.9623902783644,
        "y" : -148.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30188",
        "ClosenessCentrality" : 0.2808917197452229,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9525909129083732,
        "Stress" : 2540,
        "TopologicalCoefficient" : 0.5470588235294118,
        "shared_name" : "weekly",
        "BetweennessCentrality" : 5.287100598546134E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 3,
        "name" : "weekly",
        "SelfLoops" : 0,
        "SUID" : 30188,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.560090702947846,
        "selected" : false,
        "NeighborhoodConnectivity" : 47.5
      },
      "position" : {
        "x" : -188.9623902783644,
        "y" : -145.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30186",
        "ClosenessCentrality" : 0.35055643879173287,
        "Eccentricity" : 5,
        "Degree" : 23,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.965692449819434,
        "Stress" : 102272,
        "TopologicalCoefficient" : 0.20355731225296442,
        "shared_name" : "vol-26",
        "BetweennessCentrality" : 0.024705456179151413,
        "NumberOfUndirectedEdges" : 23,
        "name" : "vol-26",
        "SelfLoops" : 0,
        "SUID" : 30186,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.852607709750567,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.478260869565218
      },
      "position" : {
        "x" : 31.03760972163559,
        "y" : -137.5214932126678
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30184",
        "ClosenessCentrality" : 0.2597173144876325,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9472159234063996,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "few",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "few",
        "SelfLoops" : 0,
        "SUID" : 30184,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8503401360544216,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -20.96239027836441,
        "y" : -158.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30182",
        "ClosenessCentrality" : 0.2739130434782609,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9509112286890065,
        "Stress" : 1014,
        "TopologicalCoefficient" : 0.5615384615384615,
        "shared_name" : "french",
        "BetweennessCentrality" : 1.7264553321271888E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 5,
        "name" : "french",
        "SelfLoops" : 0,
        "SUID" : 30182,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6507936507936507,
        "selected" : false,
        "NeighborhoodConnectivity" : 37.5
      },
      "position" : {
        "x" : 284.0376097216356,
        "y" : -268.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30180",
        "ClosenessCentrality" : 0.27155172413793105,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9503233392122281,
        "Stress" : 1048,
        "TopologicalCoefficient" : 0.5344827586206896,
        "shared_name" : "interesting",
        "BetweennessCentrality" : 2.5373396057063987E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 4,
        "name" : "interesting",
        "SelfLoops" : 0,
        "SUID" : 30180,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6825396825396823,
        "selected" : false,
        "NeighborhoodConnectivity" : 32.0
      },
      "position" : {
        "x" : -320.9623902783644,
        "y" : -136.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30178",
        "ClosenessCentrality" : 0.2597173144876325,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9472159234063996,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "international",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "international",
        "SelfLoops" : 0,
        "SUID" : 30178,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.8503401360544216,
        "selected" : false,
        "NeighborhoodConnectivity" : 23.0
      },
      "position" : {
        "x" : -19.96239027836441,
        "y" : -177.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30176",
        "ClosenessCentrality" : 0.27459526774595266,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9510791971109431,
        "Stress" : 1412,
        "TopologicalCoefficient" : 0.5223880597014925,
        "shared_name" : "silly",
        "BetweennessCentrality" : 4.3298837622745445E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 5,
        "name" : "silly",
        "SelfLoops" : 0,
        "SUID" : 30176,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6417233560090705,
        "selected" : false,
        "NeighborhoodConnectivity" : 36.0
      },
      "position" : {
        "x" : -252.9623902783644,
        "y" : -279.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30174",
        "ClosenessCentrality" : 0.3675,
        "Eccentricity" : 5,
        "Degree" : 52,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9681279919375158,
        "Stress" : 500226,
        "TopologicalCoefficient" : 0.2097902097902098,
        "shared_name" : "vol-27",
        "BetweennessCentrality" : 0.09408216944359922,
        "NumberOfUndirectedEdges" : 52,
        "name" : "vol-27",
        "SelfLoops" : 0,
        "SUID" : 30174,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7210884353741496,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.615384615384615
      },
      "position" : {
        "x" : 753.5376097216356,
        "y" : 33.978506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30172",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "ashamed",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "ashamed",
        "SelfLoops" : 0,
        "SUID" : 30172,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 672.3562884573776,
        "y" : 80.84856447242089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30170",
        "ClosenessCentrality" : 0.2728960396039604,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9506592760561015,
        "Stress" : 4664,
        "TopologicalCoefficient" : 0.532258064516129,
        "shared_name" : "black",
        "BetweennessCentrality" : 4.1950261479392745E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 22,
        "name" : "black",
        "SelfLoops" : 0,
        "SUID" : 30170,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.6643990929705215,
        "selected" : false,
        "NeighborhoodConnectivity" : 34.0
      },
      "position" : {
        "x" : 900.0376097216356,
        "y" : 330.4785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30168",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "careless",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "careless",
        "SelfLoops" : 0,
        "SUID" : 30168,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 834.7189309858936,
        "y" : 80.84856447242089
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30166",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "convinced",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "convinced",
        "SelfLoops" : 0,
        "SUID" : 30166,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 672.3562884573776,
        "y" : -12.891550897756701
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30164",
        "ClosenessCentrality" : 0.2947860962566845,
        "Eccentricity" : 6,
        "Degree" : 3,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9556983287142017,
        "Stress" : 7896,
        "TopologicalCoefficient" : 0.4049586776859504,
        "shared_name" : "fake",
        "BetweennessCentrality" : 0.0014695720462121972,
        "NumberOfUndirectedEdges" : 3,
        "synsetCount" : 8,
        "name" : "fake",
        "SelfLoops" : 0,
        "SUID" : 30164,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.3922902494331066,
        "selected" : false,
        "NeighborhoodConnectivity" : 50.0
      },
      "position" : {
        "x" : 122.03760972163559,
        "y" : -243.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30162",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "horrible",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "horrible",
        "SelfLoops" : 0,
        "SUID" : 30162,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 659.797494351458,
        "y" : 33.978506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30160",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "maximum",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "maximum",
        "SelfLoops" : 0,
        "SUID" : 30160,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 753.5376097216356,
        "y" : -59.76160858284538
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30158",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "opposite",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 11,
        "name" : "opposite",
        "SelfLoops" : 0,
        "SUID" : 30158,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 800.4076674067244,
        "y" : 115.1598280515899
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30156",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "queenly",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "queenly",
        "SelfLoops" : 0,
        "SUID" : 30156,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 800.4076674067244,
        "y" : -47.20281447692582
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30154",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "rude",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "rude",
        "SelfLoops" : 0,
        "SUID" : 30154,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 706.6675520365468,
        "y" : 115.1598280515899
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30152",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sisterly",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "sisterly",
        "SelfLoops" : 0,
        "SUID" : 30152,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 847.2777250918132,
        "y" : 33.97850678733221
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30150",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "stuck",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 18,
        "name" : "stuck",
        "SelfLoops" : 0,
        "SUID" : 30150,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 706.6675520365468,
        "y" : -47.20281447692582
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30148",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "traditional",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "traditional",
        "SelfLoops" : 0,
        "SUID" : 30148,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 753.5376097216356,
        "y" : 127.71862215750969
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30146",
        "ClosenessCentrality" : 0.26890243902439026,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9496514655244814,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "wide",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 11,
        "name" : "wide",
        "SelfLoops" : 0,
        "SUID" : 30146,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7188208616780045,
        "selected" : false,
        "NeighborhoodConnectivity" : 52.0
      },
      "position" : {
        "x" : 834.7189309858934,
        "y" : -12.891550897756815
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30144",
        "ClosenessCentrality" : 0.3656716417910448,
        "Eccentricity" : 5,
        "Degree" : 49,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9678760393046106,
        "Stress" : 429304,
        "TopologicalCoefficient" : 0.1790352504638219,
        "shared_name" : "vol-6",
        "BetweennessCentrality" : 0.09357737332561747,
        "NumberOfUndirectedEdges" : 49,
        "name" : "vol-6",
        "SelfLoops" : 0,
        "SUID" : 30144,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7346938775510203,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.938775510204081
      },
      "position" : {
        "x" : -430.83231414866145,
        "y" : -394.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30142",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "accurate",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "accurate",
        "SelfLoops" : 0,
        "SUID" : 30142,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -491.2929219686806,
        "y" : -324.7462322195465
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30140",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "brown",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 8,
        "name" : "brown",
        "SelfLoops" : 0,
        "SUID" : 30140,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -338.50641234085685,
        "y" : -394.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30138",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "disgusting",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "disgusting",
        "SelfLoops" : 0,
        "SUID" : 30138,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -519.4183682158719,
        "y" : -368.5102808336643
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30136",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "handy",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "handy",
        "SelfLoops" : 0,
        "SUID" : 30136,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -392.4787484487615,
        "y" : -478.50408749700654
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30134",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "hungry",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "hungry",
        "SelfLoops" : 0,
        "SUID" : 30134,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -519.4183682158719,
        "y" : -420.5327055916714
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30132",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "key",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 21,
        "name" : "key",
        "SelfLoops" : 0,
        "SUID" : 30132,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -353.1628230810211,
        "y" : -344.60634218697123
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30130",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "occasional",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "occasional",
        "SelfLoops" : 0,
        "SUID" : 30130,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -443.97165993287433,
        "y" : -303.13533596230934
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30128",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "relaxing",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 9,
        "name" : "relaxing",
        "SelfLoops" : 0,
        "SUID" : 30128,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -443.97165993287433,
        "y" : -485.9076504630264
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30126",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "useful",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "useful",
        "SelfLoops" : 0,
        "SUID" : 30126,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -353.1628230810212,
        "y" : -444.43664423836475
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30124",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "various",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "various",
        "SelfLoops" : 0,
        "SUID" : 30124,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -491.2929219686806,
        "y" : -464.29675420578917
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30122",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "weirdo",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "weirdo",
        "SelfLoops" : 0,
        "SUID" : 30122,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -392.4787484487614,
        "y" : -310.53889892832933
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30120",
        "ClosenessCentrality" : 0.3656716417910448,
        "Eccentricity" : 5,
        "Degree" : 49,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9678760393046106,
        "Stress" : 388276,
        "TopologicalCoefficient" : 0.1437847866419295,
        "shared_name" : "vol-7",
        "BetweennessCentrality" : 0.11182768321986199,
        "NumberOfUndirectedEdges" : 49,
        "name" : "vol-7",
        "SelfLoops" : 0,
        "SUID" : 30120,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7346938775510203,
        "selected" : false,
        "NeighborhoodConnectivity" : 4.163265306122449
      },
      "position" : {
        "x" : -687.0919927597778,
        "y" : -471.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30118",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "artistic",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "artistic",
        "SelfLoops" : 0,
        "SUID" : 30118,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -768.2901999562096,
        "y" : -515.4637654878893
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30116",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "braided",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "braided",
        "SelfLoops" : 0,
        "SUID" : 30116,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -724.1788850929322,
        "y" : -386.9718949777066
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30114",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "broken",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 72,
        "name" : "broken",
        "SelfLoops" : 0,
        "SUID" : 30114,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -614.2338835766855,
        "y" : -414.8137506117763
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30112",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "circular",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "circular",
        "SelfLoops" : 0,
        "SUID" : 30112,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -651.1025108030442,
        "y" : -561.534739785001
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30110",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "clear",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 45,
        "name" : "clear",
        "SelfLoops" : 0,
        "SUID" : 30110,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -778.1586896047556,
        "y" : -456.32514923231315
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30108",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "double",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 21,
        "name" : "double",
        "SelfLoops" : 0,
        "SUID" : 30108,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -749.6226246379315,
        "y" : -403.5951196782064
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30106",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "dumb",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "dumb",
        "SelfLoops" : 0,
        "SUID" : 30106,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -636.594510819007,
        "y" : -394.2293431438161
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30104",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "funky",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "funky",
        "SelfLoops" : 0,
        "SUID" : 30104,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -749.6226246379314,
        "y" : -539.4478667471294
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30102",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "mad",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "mad",
        "SelfLoops" : 0,
        "SUID" : 30102,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -594.7660909519732,
        "y" : -471.52149321266796
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30100",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "mammoth",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "mammoth",
        "SelfLoops" : 0,
        "SUID" : 30100,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -640.6944532730777,
        "y" : -539.0762799531009
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30098",
        "ClosenessCentrality" : 0.2801778907242694,
        "Eccentricity" : 6,
        "Degree" : 2,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9524229444864366,
        "Stress" : 2628,
        "TopologicalCoefficient" : 0.5301204819277109,
        "shared_name" : "nervous",
        "BetweennessCentrality" : 7.916206934432641E-4,
        "NumberOfUndirectedEdges" : 2,
        "synsetCount" : 5,
        "name" : "nervous",
        "SelfLoops" : 0,
        "SUID" : 30098,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.569160997732426,
        "selected" : false,
        "NeighborhoodConnectivity" : 45.0
      },
      "position" : {
        "x" : -973.9623902783644,
        "y" : -114.5214932126679
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30096",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "ok",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "ok",
        "SelfLoops" : 0,
        "SUID" : 30096,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -664.4273237787753,
        "y" : -382.02073944709366
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30094",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "perfect",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "perfect",
        "SelfLoops" : 0,
        "SUID" : 30094,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -614.2338835766852,
        "y" : -528.2292358135592
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30092",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "powerful",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "powerful",
        "SelfLoops" : 0,
        "SUID" : 30092,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -724.178885092932,
        "y" : -556.0710914476292
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30090",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "spanish",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "spanish",
        "SelfLoops" : 0,
        "SUID" : 30090,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -599.7685629743962,
        "y" : -501.49966452350526
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30088",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "strained",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 13,
        "name" : "strained",
        "SelfLoops" : 0,
        "SUID" : 30088,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -694.7162053012089,
        "y" : -572.7569257788421
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30086",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "technical",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "technical",
        "SelfLoops" : 0,
        "SUID" : 30086,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -768.2901999562096,
        "y" : -427.5792209374465
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30084",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "tidal",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "tidal",
        "SelfLoops" : 0,
        "SUID" : 30084,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -694.7162053012091,
        "y" : -379.51093116815343
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30082",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "tired",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 6,
        "name" : "tired",
        "SelfLoops" : 0,
        "SUID" : 30082,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -599.7685629743964,
        "y" : -441.54332190183004
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30080",
        "ClosenessCentrality" : 0.26792223572296475,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9493995128915764,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "valuable",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "valuable",
        "SelfLoops" : 0,
        "SUID" : 30080,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7324263038548753,
        "selected" : false,
        "NeighborhoodConnectivity" : 49.0
      },
      "position" : {
        "x" : -778.1586896047556,
        "y" : -486.71783719302283
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30078",
        "ClosenessCentrality" : 0.33257918552036203,
        "Eccentricity" : 5,
        "Degree" : 16,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.9628369866465105,
        "Stress" : 135038,
        "TopologicalCoefficient" : 0.140625,
        "shared_name" : "vol-5",
        "BetweennessCentrality" : 0.02626455757401506,
        "NumberOfUndirectedEdges" : 16,
        "name" : "vol-5",
        "SelfLoops" : 0,
        "SUID" : 30078,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.006802721088435,
        "selected" : false,
        "NeighborhoodConnectivity" : 3.8125
      },
      "position" : {
        "x" : 425.4768605282818,
        "y" : 302.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30076",
        "ClosenessCentrality" : 0.24971687429218575,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9443604602334761,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "damn",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "damn",
        "SelfLoops" : 0,
        "SUID" : 30076,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.00453514739229,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : 365.6572334180348,
        "y" : 259.5170036823155
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30074",
        "ClosenessCentrality" : 0.24971687429218575,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9443604602334761,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "donnnn",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 0,
        "name" : "donnnn",
        "SelfLoops" : 0,
        "SUID" : 30074,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.00453514739229,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : 365.6572334180348,
        "y" : 346.4400098923487
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30072",
        "ClosenessCentrality" : 0.24971687429218575,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9443604602334761,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "german",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "german",
        "SelfLoops" : 0,
        "SUID" : 30072,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.00453514739229,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : 499.4179860252359,
        "y" : 302.9785067873321
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30070",
        "ClosenessCentrality" : 0.24971687429218575,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9443604602334761,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "partial",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "partial",
        "SelfLoops" : 0,
        "SUID" : 30070,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.00453514739229,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : 448.3259248900513,
        "y" : 232.65631756125583
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30068",
        "ClosenessCentrality" : 0.24971687429218575,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9443604602334761,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sound",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 24,
        "name" : "sound",
        "SelfLoops" : 0,
        "SUID" : 30068,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 4.00453514739229,
        "selected" : false,
        "NeighborhoodConnectivity" : 16.0
      },
      "position" : {
        "x" : 448.3259248900513,
        "y" : 373.3006960134081
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30066",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "Most",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 5,
        "name" : "Most",
        "SelfLoops" : 0,
        "SUID" : 30066,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -564.9623902783644,
        "y" : 138.06176790801726
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30064",
        "ClosenessCentrality" : 0.3608837970540098,
        "Eccentricity" : 5,
        "Degree" : 41,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "",
        "Radiality" : 0.967204165616864,
        "Stress" : 316610,
        "TopologicalCoefficient" : 0.18625277161862527,
        "shared_name" : "vol-4",
        "BetweennessCentrality" : 0.07758844386354624,
        "NumberOfUndirectedEdges" : 41,
        "name" : "vol-4",
        "SelfLoops" : 0,
        "SUID" : 30064,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 2.7709750566893425,
        "selected" : false,
        "NeighborhoodConnectivity" : 5.097560975609756
      },
      "position" : {
        "x" : -564.9623902783644,
        "y" : 49.978506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30062",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "alive",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "alive",
        "SelfLoops" : 0,
        "SUID" : 30062,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -488.6800484996728,
        "y" : 5.936876226989398
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30060",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "axe",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "axe",
        "SelfLoops" : 0,
        "SUID" : 30060,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -609.004020838707,
        "y" : -26.30383499135951
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30058",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "cruel",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 1,
        "name" : "cruel",
        "SelfLoops" : 0,
        "SUID" : 30058,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -609.004020838707,
        "y" : 126.26084856602358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30056",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "d",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "d",
        "SelfLoops" : 0,
        "SUID" : 30056,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -520.9207597180217,
        "y" : 126.26084856602358
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30054",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "dead",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 21,
        "name" : "dead",
        "SelfLoops" : 0,
        "SUID" : 30054,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -520.9207597180218,
        "y" : -26.30383499135951
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30052",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "disrespectful",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 2,
        "name" : "disrespectful",
        "SelfLoops" : 0,
        "SUID" : 30052,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -641.2447320570559,
        "y" : 5.936876226989398
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30050",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "honest",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "honest",
        "SelfLoops" : 0,
        "SUID" : 30050,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -476.87912915767913,
        "y" : 49.97850678733221
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30048",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "painful",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 4,
        "name" : "painful",
        "SelfLoops" : 0,
        "SUID" : 30048,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -653.0456513990496,
        "y" : 49.978506787332094
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30046",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "patient",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 3,
        "name" : "patient",
        "SelfLoops" : 0,
        "SUID" : 30046,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -641.244732057056,
        "y" : 94.02013734767468
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30044",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "secondary",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 7,
        "name" : "secondary",
        "SelfLoops" : 0,
        "SUID" : 30044,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -488.6800484996728,
        "y" : 94.02013734767468
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30042",
        "ClosenessCentrality" : 0.26534296028880866,
        "Eccentricity" : 6,
        "Degree" : 1,
        "PartnerOfMultiEdgedNodePairs" : 0,
        "ClusteringCoefficient" : 0.0,
        "nodeType" : "ADJ",
        "Radiality" : 0.9487276392038296,
        "Stress" : 0,
        "TopologicalCoefficient" : 0.0,
        "shared_name" : "sharp",
        "BetweennessCentrality" : 0.0,
        "NumberOfUndirectedEdges" : 1,
        "synsetCount" : 15,
        "name" : "sharp",
        "SelfLoops" : 0,
        "SUID" : 30042,
        "IsSingleNode" : false,
        "NumberOfDirectedEdges" : 0,
        "AverageShortestPathLength" : 3.7687074829931975,
        "selected" : false,
        "NeighborhoodConnectivity" : 41.0
      },
      "position" : {
        "x" : -564.9623902783644,
        "y" : -38.104754333353185
      },
      "selected" : false
    } ],
    "edges" : [ {
      "data" : {
        "id" : "32762",
        "source" : "30924",
        "target" : "30922",
        "EdgeBetweenness" : 563.4909422219655,
        "shared_name" : "angry (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "angry (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32762,
        "BEND_MAP_ID" : 197,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32760",
        "source" : "30924",
        "target" : "30226",
        "EdgeBetweenness" : 534.0451946640584,
        "shared_name" : "angry (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "angry (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32760,
        "BEND_MAP_ID" : 3166,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32758",
        "source" : "30920",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "awfull (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "awfull (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32758,
        "BEND_MAP_ID" : 207,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32756",
        "source" : "30918",
        "target" : "30922",
        "EdgeBetweenness" : 951.7975260300992,
        "shared_name" : "bad (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bad (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32756,
        "BEND_MAP_ID" : 213,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32754",
        "source" : "30918",
        "target" : "30830",
        "EdgeBetweenness" : 1136.0452355091556,
        "shared_name" : "bad (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "bad (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32754,
        "BEND_MAP_ID" : 518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32752",
        "source" : "30918",
        "target" : "30656",
        "EdgeBetweenness" : 794.5713317983099,
        "shared_name" : "bad (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bad (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32752,
        "BEND_MAP_ID" : 1073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32750",
        "source" : "30918",
        "target" : "30446",
        "EdgeBetweenness" : 1100.9104105678846,
        "shared_name" : "bad (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bad (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32750,
        "BEND_MAP_ID" : 2015,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32748",
        "source" : "30918",
        "target" : "30404",
        "EdgeBetweenness" : 703.0860174667127,
        "shared_name" : "bad (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bad (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32748,
        "BEND_MAP_ID" : 2194,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32746",
        "source" : "30918",
        "target" : "30268",
        "EdgeBetweenness" : 606.3158057108744,
        "shared_name" : "bad (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bad (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32746,
        "BEND_MAP_ID" : 2871,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32744",
        "source" : "30918",
        "target" : "30246",
        "EdgeBetweenness" : 738.6998945533353,
        "shared_name" : "bad (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "bad (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32744,
        "BEND_MAP_ID" : 3002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32742",
        "source" : "30918",
        "target" : "30174",
        "EdgeBetweenness" : 727.8441679788983,
        "shared_name" : "bad (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bad (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32742,
        "BEND_MAP_ID" : 3449,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32740",
        "source" : "30918",
        "target" : "30144",
        "EdgeBetweenness" : 922.6484792474945,
        "shared_name" : "bad (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bad (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32740,
        "BEND_MAP_ID" : 3652,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32738",
        "source" : "30918",
        "target" : "30120",
        "EdgeBetweenness" : 1273.1218917224314,
        "shared_name" : "bad (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "bad (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32738,
        "BEND_MAP_ID" : 3834,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32736",
        "source" : "30916",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "bald (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "bald (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32736,
        "BEND_MAP_ID" : 219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32734",
        "source" : "30914",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "complete (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "complete (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32734,
        "BEND_MAP_ID" : 225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32732",
        "source" : "30912",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "dry (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dry (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32732,
        "BEND_MAP_ID" : 231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32730",
        "source" : "30910",
        "target" : "30922",
        "EdgeBetweenness" : 570.9514463990406,
        "shared_name" : "elementary (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "elementary (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32730,
        "BEND_MAP_ID" : 237,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32728",
        "source" : "30910",
        "target" : "30120",
        "EdgeBetweenness" : 546.4184154025664,
        "shared_name" : "elementary (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "elementary (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32728,
        "BEND_MAP_ID" : 3879,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32726",
        "source" : "30908",
        "target" : "30922",
        "EdgeBetweenness" : 500.3605908265104,
        "shared_name" : "embarrassed (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "embarrassed (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32726,
        "BEND_MAP_ID" : 243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32724",
        "source" : "30908",
        "target" : "30484",
        "EdgeBetweenness" : 475.60986919154277,
        "shared_name" : "embarrassed (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "embarrassed (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32724,
        "BEND_MAP_ID" : 1821,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32722",
        "source" : "30908",
        "target" : "30246",
        "EdgeBetweenness" : 452.7905293413244,
        "shared_name" : "embarrassed (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "embarrassed (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32722,
        "BEND_MAP_ID" : 3035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32720",
        "source" : "30908",
        "target" : "30226",
        "EdgeBetweenness" : 516.6281425966637,
        "shared_name" : "embarrassed (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "embarrassed (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32720,
        "BEND_MAP_ID" : 3214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32718",
        "source" : "30906",
        "target" : "30922",
        "EdgeBetweenness" : 516.6093256981304,
        "shared_name" : "famous (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "famous (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32718,
        "BEND_MAP_ID" : 249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32716",
        "source" : "30906",
        "target" : "30484",
        "EdgeBetweenness" : 523.2107544937944,
        "shared_name" : "famous (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "famous (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32716,
        "BEND_MAP_ID" : 1830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32714",
        "source" : "30906",
        "target" : "30404",
        "EdgeBetweenness" : 370.0740196484445,
        "shared_name" : "famous (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "famous (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32714,
        "BEND_MAP_ID" : 2221,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32712",
        "source" : "30904",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "filthy (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "filthy (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32712,
        "BEND_MAP_ID" : 255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32710",
        "source" : "30902",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "flintlock (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "flintlock (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32710,
        "BEND_MAP_ID" : 261,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32708",
        "source" : "30900",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "flustered (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "flustered (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32708,
        "BEND_MAP_ID" : 267,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32706",
        "source" : "30898",
        "target" : "30922",
        "EdgeBetweenness" : 599.2046598832314,
        "shared_name" : "full (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "full (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32706,
        "BEND_MAP_ID" : 273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32704",
        "source" : "30898",
        "target" : "30694",
        "EdgeBetweenness" : 544.4185259975064,
        "shared_name" : "full (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "full (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 32704,
        "BEND_MAP_ID" : 978,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32702",
        "source" : "30898",
        "target" : "30560",
        "EdgeBetweenness" : 474.0050469192428,
        "shared_name" : "full (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "full (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32702,
        "BEND_MAP_ID" : 1536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32700",
        "source" : "30898",
        "target" : "30330",
        "EdgeBetweenness" : 408.06639303710114,
        "shared_name" : "full (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "full (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32700,
        "BEND_MAP_ID" : 2576,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32698",
        "source" : "30898",
        "target" : "30268",
        "EdgeBetweenness" : 370.29571073541314,
        "shared_name" : "full (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "full (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32698,
        "BEND_MAP_ID" : 2898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32696",
        "source" : "30898",
        "target" : "30174",
        "EdgeBetweenness" : 483.21907704218194,
        "shared_name" : "full (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "full (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32696,
        "BEND_MAP_ID" : 3497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32694",
        "source" : "30896",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "golden (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "golden (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32694,
        "BEND_MAP_ID" : 279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32692",
        "source" : "30894",
        "target" : "30922",
        "EdgeBetweenness" : 1666.1337556916108,
        "shared_name" : "good (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "good (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32692,
        "BEND_MAP_ID" : 285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32690",
        "source" : "30894",
        "target" : "30830",
        "EdgeBetweenness" : 1830.8681747963603,
        "shared_name" : "good (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "good (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32690,
        "BEND_MAP_ID" : 599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32688",
        "source" : "30894",
        "target" : "30742",
        "EdgeBetweenness" : 1151.5886473798748,
        "shared_name" : "good (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "good (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32688,
        "BEND_MAP_ID" : 802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32686",
        "source" : "30894",
        "target" : "30694",
        "EdgeBetweenness" : 1649.16650501771,
        "shared_name" : "good (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "good (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 32686,
        "BEND_MAP_ID" : 984,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32684",
        "source" : "30894",
        "target" : "30656",
        "EdgeBetweenness" : 1487.78051018473,
        "shared_name" : "good (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "good (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32684,
        "BEND_MAP_ID" : 1115,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32682",
        "source" : "30894",
        "target" : "30618",
        "EdgeBetweenness" : 2156.5053583892836,
        "shared_name" : "good (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "good (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32682,
        "BEND_MAP_ID" : 1333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32680",
        "source" : "30894",
        "target" : "30560",
        "EdgeBetweenness" : 1158.9240862523982,
        "shared_name" : "good (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "good (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32680,
        "BEND_MAP_ID" : 1557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32678",
        "source" : "30894",
        "target" : "30510",
        "EdgeBetweenness" : 1784.0329498049052,
        "shared_name" : "good (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "good (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 32678,
        "BEND_MAP_ID" : 1711,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32676",
        "source" : "30894",
        "target" : "30404",
        "EdgeBetweenness" : 1214.0710850790003,
        "shared_name" : "good (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "good (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32676,
        "BEND_MAP_ID" : 2227,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32674",
        "source" : "30894",
        "target" : "30378",
        "EdgeBetweenness" : 1558.3547767088196,
        "shared_name" : "good (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "good (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32674,
        "BEND_MAP_ID" : 2373,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32672",
        "source" : "30894",
        "target" : "30330",
        "EdgeBetweenness" : 976.4349408950801,
        "shared_name" : "good (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "good (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32672,
        "BEND_MAP_ID" : 2579,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32670",
        "source" : "30894",
        "target" : "30308",
        "EdgeBetweenness" : 1713.8639674620952,
        "shared_name" : "good (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "good (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32670,
        "BEND_MAP_ID" : 2734,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32668",
        "source" : "30894",
        "target" : "30268",
        "EdgeBetweenness" : 940.6679530109442,
        "shared_name" : "good (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "good (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32668,
        "BEND_MAP_ID" : 2901,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32666",
        "source" : "30894",
        "target" : "30246",
        "EdgeBetweenness" : 1061.4252183548745,
        "shared_name" : "good (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "good (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32666,
        "BEND_MAP_ID" : 3053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32664",
        "source" : "30894",
        "target" : "30174",
        "EdgeBetweenness" : 1252.8668268697556,
        "shared_name" : "good (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "good (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32664,
        "BEND_MAP_ID" : 3503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32662",
        "source" : "30894",
        "target" : "30144",
        "EdgeBetweenness" : 1454.2517250631656,
        "shared_name" : "good (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "good (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32662,
        "BEND_MAP_ID" : 3691,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32660",
        "source" : "30894",
        "target" : "30064",
        "EdgeBetweenness" : 1391.011989910767,
        "shared_name" : "good (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "good (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32660,
        "BEND_MAP_ID" : 4153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32658",
        "source" : "30892",
        "target" : "30922",
        "EdgeBetweenness" : 1189.8045968052356,
        "shared_name" : "great (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "great (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32658,
        "BEND_MAP_ID" : 291,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32656",
        "source" : "30892",
        "target" : "30830",
        "EdgeBetweenness" : 1361.1655320581067,
        "shared_name" : "great (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "great (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32656,
        "BEND_MAP_ID" : 602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32654",
        "source" : "30892",
        "target" : "30618",
        "EdgeBetweenness" : 1415.9840748059032,
        "shared_name" : "great (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "great (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32654,
        "BEND_MAP_ID" : 1336,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32652",
        "source" : "30892",
        "target" : "30560",
        "EdgeBetweenness" : 810.5156895078518,
        "shared_name" : "great (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "great (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32652,
        "BEND_MAP_ID" : 1560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32650",
        "source" : "30892",
        "target" : "30510",
        "EdgeBetweenness" : 1073.5201578148328,
        "shared_name" : "great (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "great (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 32650,
        "BEND_MAP_ID" : 1720,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32648",
        "source" : "30892",
        "target" : "30446",
        "EdgeBetweenness" : 1347.0385824199711,
        "shared_name" : "great (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "great (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32648,
        "BEND_MAP_ID" : 2090,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32646",
        "source" : "30892",
        "target" : "30378",
        "EdgeBetweenness" : 1164.189013556617,
        "shared_name" : "great (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "great (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32646,
        "BEND_MAP_ID" : 2376,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32644",
        "source" : "30892",
        "target" : "30226",
        "EdgeBetweenness" : 1282.0061412406112,
        "shared_name" : "great (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "great (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32644,
        "BEND_MAP_ID" : 3229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32642",
        "source" : "30892",
        "target" : "30120",
        "EdgeBetweenness" : 1397.2568621428263,
        "shared_name" : "great (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "great (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32642,
        "BEND_MAP_ID" : 3900,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32640",
        "source" : "30892",
        "target" : "30064",
        "EdgeBetweenness" : 1039.9164945320576,
        "shared_name" : "great (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "great (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32640,
        "BEND_MAP_ID" : 4156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32638",
        "source" : "30890",
        "target" : "30922",
        "EdgeBetweenness" : 548.6613176053902,
        "shared_name" : "heavy (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "heavy (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32638,
        "BEND_MAP_ID" : 297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32636",
        "source" : "30890",
        "target" : "30308",
        "EdgeBetweenness" : 508.8401773260705,
        "shared_name" : "heavy (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "heavy (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32636,
        "BEND_MAP_ID" : 2737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32634",
        "source" : "30888",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "inside (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "inside (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32634,
        "BEND_MAP_ID" : 303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32632",
        "source" : "30886",
        "target" : "30922",
        "EdgeBetweenness" : 512.1323590282925,
        "shared_name" : "kindred (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "kindred (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32632,
        "BEND_MAP_ID" : 309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32630",
        "source" : "30886",
        "target" : "30144",
        "EdgeBetweenness" : 565.3413363771986,
        "shared_name" : "kindred (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "kindred (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32630,
        "BEND_MAP_ID" : 3721,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32628",
        "source" : "30884",
        "target" : "30922",
        "EdgeBetweenness" : 708.4283995540792,
        "shared_name" : "left (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "left (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32628,
        "BEND_MAP_ID" : 315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32626",
        "source" : "30884",
        "target" : "30830",
        "EdgeBetweenness" : 824.1070668198688,
        "shared_name" : "left (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "left (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32626,
        "BEND_MAP_ID" : 629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32624",
        "source" : "30884",
        "target" : "30446",
        "EdgeBetweenness" : 758.1524930042178,
        "shared_name" : "left (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "left (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32624,
        "BEND_MAP_ID" : 2114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32622",
        "source" : "30884",
        "target" : "30330",
        "EdgeBetweenness" : 448.10627894764707,
        "shared_name" : "left (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "left (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32622,
        "BEND_MAP_ID" : 2597,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32620",
        "source" : "30884",
        "target" : "30308",
        "EdgeBetweenness" : 655.0368251805378,
        "shared_name" : "left (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "left (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32620,
        "BEND_MAP_ID" : 2761,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32618",
        "source" : "30884",
        "target" : "30268",
        "EdgeBetweenness" : 428.11895361096254,
        "shared_name" : "left (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "left (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32618,
        "BEND_MAP_ID" : 2910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32616",
        "source" : "30884",
        "target" : "30174",
        "EdgeBetweenness" : 572.102531073951,
        "shared_name" : "left (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "left (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32616,
        "BEND_MAP_ID" : 3521,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32614",
        "source" : "30882",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "light (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "light (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32614,
        "BEND_MAP_ID" : 321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32612",
        "source" : "30880",
        "target" : "30922",
        "EdgeBetweenness" : 609.1781943240205,
        "shared_name" : "long (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "long (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32612,
        "BEND_MAP_ID" : 327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32610",
        "source" : "30880",
        "target" : "30830",
        "EdgeBetweenness" : 692.1847391124153,
        "shared_name" : "long (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "long (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32610,
        "BEND_MAP_ID" : 638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32608",
        "source" : "30880",
        "target" : "30404",
        "EdgeBetweenness" : 357.1267066165508,
        "shared_name" : "long (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "long (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32608,
        "BEND_MAP_ID" : 2251,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32606",
        "source" : "30880",
        "target" : "30308",
        "EdgeBetweenness" : 564.9613519594155,
        "shared_name" : "long (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "long (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32606,
        "BEND_MAP_ID" : 2764,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32604",
        "source" : "30880",
        "target" : "30064",
        "EdgeBetweenness" : 540.0408509433449,
        "shared_name" : "long (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "long (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32604,
        "BEND_MAP_ID" : 4180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32602",
        "source" : "30878",
        "target" : "30922",
        "EdgeBetweenness" : 1283.4068523850462,
        "shared_name" : "many (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "many (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32602,
        "BEND_MAP_ID" : 333,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32600",
        "source" : "30878",
        "target" : "30830",
        "EdgeBetweenness" : 1636.867080296798,
        "shared_name" : "many (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "many (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32600,
        "BEND_MAP_ID" : 647,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32598",
        "source" : "30878",
        "target" : "30742",
        "EdgeBetweenness" : 1014.574637764177,
        "shared_name" : "many (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "many (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32598,
        "BEND_MAP_ID" : 829,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32596",
        "source" : "30878",
        "target" : "30618",
        "EdgeBetweenness" : 1686.5185937113586,
        "shared_name" : "many (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "many (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32596,
        "BEND_MAP_ID" : 1378,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32594",
        "source" : "30878",
        "target" : "30560",
        "EdgeBetweenness" : 980.3111176921215,
        "shared_name" : "many (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "many (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32594,
        "BEND_MAP_ID" : 1572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32592",
        "source" : "30878",
        "target" : "30378",
        "EdgeBetweenness" : 1253.7120991444137,
        "shared_name" : "many (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "many (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32592,
        "BEND_MAP_ID" : 2403,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32590",
        "source" : "30878",
        "target" : "30308",
        "EdgeBetweenness" : 1429.9488139889338,
        "shared_name" : "many (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "many (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32590,
        "BEND_MAP_ID" : 2767,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32588",
        "source" : "30878",
        "target" : "30268",
        "EdgeBetweenness" : 785.9254877258276,
        "shared_name" : "many (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "many (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32588,
        "BEND_MAP_ID" : 2916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32586",
        "source" : "30878",
        "target" : "30226",
        "EdgeBetweenness" : 1496.4882837848568,
        "shared_name" : "many (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "many (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32586,
        "BEND_MAP_ID" : 3256,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32584",
        "source" : "30878",
        "target" : "30174",
        "EdgeBetweenness" : 1049.971769643567,
        "shared_name" : "many (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "many (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32584,
        "BEND_MAP_ID" : 3530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32582",
        "source" : "30878",
        "target" : "30144",
        "EdgeBetweenness" : 1157.885362717806,
        "shared_name" : "many (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "many (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32582,
        "BEND_MAP_ID" : 3727,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32580",
        "source" : "30878",
        "target" : "30120",
        "EdgeBetweenness" : 1710.975852491246,
        "shared_name" : "many (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "many (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32580,
        "BEND_MAP_ID" : 3924,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32578",
        "source" : "30878",
        "target" : "30064",
        "EdgeBetweenness" : 1170.868123883974,
        "shared_name" : "many (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 5,
        "name" : "many (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32578,
        "BEND_MAP_ID" : 4183,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32576",
        "source" : "30876",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "medium (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "medium (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32576,
        "BEND_MAP_ID" : 339,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32574",
        "source" : "30874",
        "target" : "30922",
        "EdgeBetweenness" : 1038.2297662366925,
        "shared_name" : "more (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "more (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32574,
        "BEND_MAP_ID" : 345,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32572",
        "source" : "30874",
        "target" : "30742",
        "EdgeBetweenness" : 852.4947045148616,
        "shared_name" : "more (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32572,
        "BEND_MAP_ID" : 832,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32570",
        "source" : "30874",
        "target" : "30656",
        "EdgeBetweenness" : 929.1394665232565,
        "shared_name" : "more (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32570,
        "BEND_MAP_ID" : 1154,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32568",
        "source" : "30874",
        "target" : "30560",
        "EdgeBetweenness" : 832.2455832033052,
        "shared_name" : "more (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32568,
        "BEND_MAP_ID" : 1575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32566",
        "source" : "30874",
        "target" : "30404",
        "EdgeBetweenness" : 780.9761479237586,
        "shared_name" : "more (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32566,
        "BEND_MAP_ID" : 2254,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32564",
        "source" : "30874",
        "target" : "30378",
        "EdgeBetweenness" : 1049.0628510603024,
        "shared_name" : "more (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32564,
        "BEND_MAP_ID" : 2409,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32562",
        "source" : "30874",
        "target" : "30330",
        "EdgeBetweenness" : 758.9278452512807,
        "shared_name" : "more (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32562,
        "BEND_MAP_ID" : 2612,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32560",
        "source" : "30874",
        "target" : "30308",
        "EdgeBetweenness" : 1162.2836416628966,
        "shared_name" : "more (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32560,
        "BEND_MAP_ID" : 2785,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32558",
        "source" : "30874",
        "target" : "30226",
        "EdgeBetweenness" : 1229.878621797041,
        "shared_name" : "more (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "more (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32558,
        "BEND_MAP_ID" : 3265,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32556",
        "source" : "30874",
        "target" : "30174",
        "EdgeBetweenness" : 864.6340124052725,
        "shared_name" : "more (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32556,
        "BEND_MAP_ID" : 3539,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32554",
        "source" : "30874",
        "target" : "30144",
        "EdgeBetweenness" : 1046.794658585142,
        "shared_name" : "more (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32554,
        "BEND_MAP_ID" : 3730,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32552",
        "source" : "30874",
        "target" : "30120",
        "EdgeBetweenness" : 1473.713646648718,
        "shared_name" : "more (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "more (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32552,
        "BEND_MAP_ID" : 3927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32550",
        "source" : "30872",
        "target" : "30922",
        "EdgeBetweenness" : 787.6062102992423,
        "shared_name" : "much (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "much (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32550,
        "BEND_MAP_ID" : 351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32548",
        "source" : "30872",
        "target" : "30830",
        "EdgeBetweenness" : 806.6491126093041,
        "shared_name" : "much (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "much (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32548,
        "BEND_MAP_ID" : 650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32546",
        "source" : "30872",
        "target" : "30656",
        "EdgeBetweenness" : 665.2877493898031,
        "shared_name" : "much (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "much (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32546,
        "BEND_MAP_ID" : 1157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32544",
        "source" : "30872",
        "target" : "30330",
        "EdgeBetweenness" : 545.0756949620285,
        "shared_name" : "much (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "much (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32544,
        "BEND_MAP_ID" : 2621,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32542",
        "source" : "30872",
        "target" : "30246",
        "EdgeBetweenness" : 574.2813773557382,
        "shared_name" : "much (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "much (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32542,
        "BEND_MAP_ID" : 3098,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32540",
        "source" : "30872",
        "target" : "30078",
        "EdgeBetweenness" : 803.9440239875867,
        "shared_name" : "much (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "much (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 32540,
        "BEND_MAP_ID" : 4061,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32538",
        "source" : "30872",
        "target" : "30064",
        "EdgeBetweenness" : 616.7605490318252,
        "shared_name" : "much (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "much (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32538,
        "BEND_MAP_ID" : 4186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32536",
        "source" : "30870",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "naughty (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "naughty (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32536,
        "BEND_MAP_ID" : 357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32534",
        "source" : "30868",
        "target" : "30922",
        "EdgeBetweenness" : 1214.72607339362,
        "shared_name" : "next (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "next (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32534,
        "BEND_MAP_ID" : 363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32532",
        "source" : "30868",
        "target" : "30742",
        "EdgeBetweenness" : 872.3743856506477,
        "shared_name" : "next (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "next (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32532,
        "BEND_MAP_ID" : 835,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32530",
        "source" : "30868",
        "target" : "30656",
        "EdgeBetweenness" : 1047.28183873303,
        "shared_name" : "next (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "next (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32530,
        "BEND_MAP_ID" : 1160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32528",
        "source" : "30868",
        "target" : "30484",
        "EdgeBetweenness" : 1364.8756136143086,
        "shared_name" : "next (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "next (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32528,
        "BEND_MAP_ID" : 1878,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32526",
        "source" : "30868",
        "target" : "30446",
        "EdgeBetweenness" : 1324.937476596797,
        "shared_name" : "next (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "next (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32526,
        "BEND_MAP_ID" : 2129,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32524",
        "source" : "30868",
        "target" : "30404",
        "EdgeBetweenness" : 871.3364164305368,
        "shared_name" : "next (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "next (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32524,
        "BEND_MAP_ID" : 2263,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32522",
        "source" : "30868",
        "target" : "30378",
        "EdgeBetweenness" : 1265.2285981383768,
        "shared_name" : "next (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "next (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32522,
        "BEND_MAP_ID" : 2412,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32520",
        "source" : "30868",
        "target" : "30330",
        "EdgeBetweenness" : 736.315390424153,
        "shared_name" : "next (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "next (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32520,
        "BEND_MAP_ID" : 2624,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32518",
        "source" : "30868",
        "target" : "30308",
        "EdgeBetweenness" : 1217.6941758160162,
        "shared_name" : "next (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "next (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32518,
        "BEND_MAP_ID" : 2797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32516",
        "source" : "30868",
        "target" : "30268",
        "EdgeBetweenness" : 726.2881409271899,
        "shared_name" : "next (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "next (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32516,
        "BEND_MAP_ID" : 2922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32514",
        "source" : "30868",
        "target" : "30246",
        "EdgeBetweenness" : 819.1222391110551,
        "shared_name" : "next (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "next (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32514,
        "BEND_MAP_ID" : 3107,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32512",
        "source" : "30868",
        "target" : "30226",
        "EdgeBetweenness" : 1330.1268871116317,
        "shared_name" : "next (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "next (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32512,
        "BEND_MAP_ID" : 3268,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32510",
        "source" : "30868",
        "target" : "30186",
        "EdgeBetweenness" : 721.1116731884166,
        "shared_name" : "next (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "next (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 32510,
        "BEND_MAP_ID" : 3408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32508",
        "source" : "30868",
        "target" : "30174",
        "EdgeBetweenness" : 915.5759883749788,
        "shared_name" : "next (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "next (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32508,
        "BEND_MAP_ID" : 3545,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32506",
        "source" : "30866",
        "target" : "30922",
        "EdgeBetweenness" : 516.2090087481703,
        "shared_name" : "okay (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "okay (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32506,
        "BEND_MAP_ID" : 369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32504",
        "source" : "30866",
        "target" : "30484",
        "EdgeBetweenness" : 586.9568240283307,
        "shared_name" : "okay (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "okay (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32504,
        "BEND_MAP_ID" : 1881,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32502",
        "source" : "30866",
        "target" : "30378",
        "EdgeBetweenness" : 614.4224239740392,
        "shared_name" : "okay (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "okay (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32502,
        "BEND_MAP_ID" : 2421,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32500",
        "source" : "30866",
        "target" : "30120",
        "EdgeBetweenness" : 606.2368531880379,
        "shared_name" : "okay (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "okay (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32500,
        "BEND_MAP_ID" : 3942,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32498",
        "source" : "30864",
        "target" : "30922",
        "EdgeBetweenness" : 961.0725688278826,
        "shared_name" : "old (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "old (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32498,
        "BEND_MAP_ID" : 375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32496",
        "source" : "30864",
        "target" : "30618",
        "EdgeBetweenness" : 1215.9678016448302,
        "shared_name" : "old (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "old (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32496,
        "BEND_MAP_ID" : 1405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32494",
        "source" : "30864",
        "target" : "30560",
        "EdgeBetweenness" : 739.238011358718,
        "shared_name" : "old (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "old (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32494,
        "BEND_MAP_ID" : 1584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32492",
        "source" : "30864",
        "target" : "30484",
        "EdgeBetweenness" : 1107.3874561084342,
        "shared_name" : "old (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "old (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32492,
        "BEND_MAP_ID" : 1884,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32490",
        "source" : "30864",
        "target" : "30378",
        "EdgeBetweenness" : 959.3940936973092,
        "shared_name" : "old (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "old (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32490,
        "BEND_MAP_ID" : 2424,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32488",
        "source" : "30864",
        "target" : "30268",
        "EdgeBetweenness" : 666.089346733256,
        "shared_name" : "old (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 5,
        "name" : "old (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32488,
        "BEND_MAP_ID" : 2928,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32486",
        "source" : "30864",
        "target" : "30174",
        "EdgeBetweenness" : 820.7867155942172,
        "shared_name" : "old (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "old (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32486,
        "BEND_MAP_ID" : 3548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32484",
        "source" : "30864",
        "target" : "30144",
        "EdgeBetweenness" : 844.454308571808,
        "shared_name" : "old (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "old (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32484,
        "BEND_MAP_ID" : 3748,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32482",
        "source" : "30864",
        "target" : "30120",
        "EdgeBetweenness" : 1227.1580415150506,
        "shared_name" : "old (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "old (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32482,
        "BEND_MAP_ID" : 3945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32480",
        "source" : "30864",
        "target" : "30064",
        "EdgeBetweenness" : 961.7730233533504,
        "shared_name" : "old (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 6,
        "name" : "old (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32480,
        "BEND_MAP_ID" : 4201,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32478",
        "source" : "30862",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "pivoting (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "pivoting (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32478,
        "BEND_MAP_ID" : 381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32476",
        "source" : "30860",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "pleased (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "pleased (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32476,
        "BEND_MAP_ID" : 387,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32474",
        "source" : "30858",
        "target" : "30922",
        "EdgeBetweenness" : 533.7175415732855,
        "shared_name" : "popular (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "popular (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32474,
        "BEND_MAP_ID" : 393,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32472",
        "source" : "30858",
        "target" : "30742",
        "EdgeBetweenness" : 410.72073616698816,
        "shared_name" : "popular (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "popular (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32472,
        "BEND_MAP_ID" : 862,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32470",
        "source" : "30858",
        "target" : "30618",
        "EdgeBetweenness" : 557.0956262584878,
        "shared_name" : "popular (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "popular (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32470,
        "BEND_MAP_ID" : 1411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32468",
        "source" : "30858",
        "target" : "30174",
        "EdgeBetweenness" : 558.2358957916422,
        "shared_name" : "popular (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "popular (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32468,
        "BEND_MAP_ID" : 3560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32466",
        "source" : "30856",
        "target" : "30922",
        "EdgeBetweenness" : 526.3545758624272,
        "shared_name" : "refined (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "refined (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32466,
        "BEND_MAP_ID" : 399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32464",
        "source" : "30856",
        "target" : "30618",
        "EdgeBetweenness" : 541.4377782244967,
        "shared_name" : "refined (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "refined (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32464,
        "BEND_MAP_ID" : 1420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32462",
        "source" : "30856",
        "target" : "30378",
        "EdgeBetweenness" : 584.6710933194652,
        "shared_name" : "refined (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "refined (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32462,
        "BEND_MAP_ID" : 2457,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32460",
        "source" : "30854",
        "target" : "30922",
        "EdgeBetweenness" : 1638.5682996669373,
        "shared_name" : "right (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 5,
        "name" : "right (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32460,
        "BEND_MAP_ID" : 405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32458",
        "source" : "30854",
        "target" : "30830",
        "EdgeBetweenness" : 2002.6567823130783,
        "shared_name" : "right (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "right (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32458,
        "BEND_MAP_ID" : 689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32456",
        "source" : "30854",
        "target" : "30742",
        "EdgeBetweenness" : 1208.4719204365401,
        "shared_name" : "right (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "right (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32456,
        "BEND_MAP_ID" : 877,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32454",
        "source" : "30854",
        "target" : "30694",
        "EdgeBetweenness" : 1677.3086642089565,
        "shared_name" : "right (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "right (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 32454,
        "BEND_MAP_ID" : 1032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32452",
        "source" : "30854",
        "target" : "30656",
        "EdgeBetweenness" : 1583.5807859374497,
        "shared_name" : "right (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "right (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32452,
        "BEND_MAP_ID" : 1196,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32450",
        "source" : "30854",
        "target" : "30618",
        "EdgeBetweenness" : 2232.9233823671225,
        "shared_name" : "right (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "right (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32450,
        "BEND_MAP_ID" : 1423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32448",
        "source" : "30854",
        "target" : "30560",
        "EdgeBetweenness" : 1240.1059922294799,
        "shared_name" : "right (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "right (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32448,
        "BEND_MAP_ID" : 1602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32446",
        "source" : "30854",
        "target" : "30484",
        "EdgeBetweenness" : 1801.6407852860063,
        "shared_name" : "right (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "right (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32446,
        "BEND_MAP_ID" : 1908,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32444",
        "source" : "30854",
        "target" : "30378",
        "EdgeBetweenness" : 1628.0938547344447,
        "shared_name" : "right (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "right (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32444,
        "BEND_MAP_ID" : 2466,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32442",
        "source" : "30854",
        "target" : "30330",
        "EdgeBetweenness" : 1038.427337948768,
        "shared_name" : "right (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "right (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32442,
        "BEND_MAP_ID" : 2636,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32440",
        "source" : "30854",
        "target" : "30308",
        "EdgeBetweenness" : 1830.2202339310666,
        "shared_name" : "right (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "right (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32440,
        "BEND_MAP_ID" : 2818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32438",
        "source" : "30854",
        "target" : "30268",
        "EdgeBetweenness" : 1003.2811503012108,
        "shared_name" : "right (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "right (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32438,
        "BEND_MAP_ID" : 2943,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32436",
        "source" : "30854",
        "target" : "30246",
        "EdgeBetweenness" : 1169.6877377087183,
        "shared_name" : "right (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 6,
        "name" : "right (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32436,
        "BEND_MAP_ID" : 3119,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32434",
        "source" : "30854",
        "target" : "30226",
        "EdgeBetweenness" : 1934.5084082923938,
        "shared_name" : "right (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "right (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32434,
        "BEND_MAP_ID" : 3319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32432",
        "source" : "30854",
        "target" : "30174",
        "EdgeBetweenness" : 1291.785912459604,
        "shared_name" : "right (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "right (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32432,
        "BEND_MAP_ID" : 3575,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32430",
        "source" : "30854",
        "target" : "30144",
        "EdgeBetweenness" : 1499.7536023362582,
        "shared_name" : "right (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "right (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32430,
        "BEND_MAP_ID" : 3766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32428",
        "source" : "30854",
        "target" : "30120",
        "EdgeBetweenness" : 2226.8116062075233,
        "shared_name" : "right (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "right (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32428,
        "BEND_MAP_ID" : 3963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32426",
        "source" : "30852",
        "target" : "30922",
        "EdgeBetweenness" : 664.0123210952634,
        "shared_name" : "small (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "small (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32426,
        "BEND_MAP_ID" : 411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32424",
        "source" : "30852",
        "target" : "30560",
        "EdgeBetweenness" : 553.2386803542025,
        "shared_name" : "small (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "small (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32424,
        "BEND_MAP_ID" : 1614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32422",
        "source" : "30852",
        "target" : "30510",
        "EdgeBetweenness" : 651.2704263032053,
        "shared_name" : "small (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "small (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 32422,
        "BEND_MAP_ID" : 1774,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32420",
        "source" : "30852",
        "target" : "30308",
        "EdgeBetweenness" : 690.3129580005334,
        "shared_name" : "small (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "small (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32420,
        "BEND_MAP_ID" : 2839,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32418",
        "source" : "30852",
        "target" : "30246",
        "EdgeBetweenness" : 514.6499172795308,
        "shared_name" : "small (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "small (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32418,
        "BEND_MAP_ID" : 3131,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32416",
        "source" : "30852",
        "target" : "30226",
        "EdgeBetweenness" : 654.9615595472291,
        "shared_name" : "small (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "small (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32416,
        "BEND_MAP_ID" : 3340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32414",
        "source" : "30850",
        "target" : "30922",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "smelly (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "smelly (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32414,
        "BEND_MAP_ID" : 417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32412",
        "source" : "30848",
        "target" : "30922",
        "EdgeBetweenness" : 681.1902854833864,
        "shared_name" : "sorry (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sorry (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32412,
        "BEND_MAP_ID" : 423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32410",
        "source" : "30848",
        "target" : "30484",
        "EdgeBetweenness" : 569.7857498963422,
        "shared_name" : "sorry (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sorry (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32410,
        "BEND_MAP_ID" : 1926,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32408",
        "source" : "30848",
        "target" : "30446",
        "EdgeBetweenness" : 685.935439163621,
        "shared_name" : "sorry (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sorry (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32408,
        "BEND_MAP_ID" : 2156,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32406",
        "source" : "30848",
        "target" : "30246",
        "EdgeBetweenness" : 552.6462527256336,
        "shared_name" : "sorry (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "sorry (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32406,
        "BEND_MAP_ID" : 3134,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32404",
        "source" : "30848",
        "target" : "30078",
        "EdgeBetweenness" : 678.8658246033744,
        "shared_name" : "sorry (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sorry (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 32404,
        "BEND_MAP_ID" : 4076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32402",
        "source" : "30846",
        "target" : "30922",
        "EdgeBetweenness" : 597.5553881896387,
        "shared_name" : "surprised (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "surprised (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32402,
        "BEND_MAP_ID" : 429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32400",
        "source" : "30846",
        "target" : "30446",
        "EdgeBetweenness" : 563.3438771541047,
        "shared_name" : "surprised (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "surprised (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32400,
        "BEND_MAP_ID" : 2171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32398",
        "source" : "30846",
        "target" : "30330",
        "EdgeBetweenness" : 394.6061715452681,
        "shared_name" : "surprised (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "surprised (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32398,
        "BEND_MAP_ID" : 2663,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32396",
        "source" : "30846",
        "target" : "30308",
        "EdgeBetweenness" : 518.3854185168543,
        "shared_name" : "surprised (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "surprised (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32396,
        "BEND_MAP_ID" : 2851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32394",
        "source" : "30846",
        "target" : "30186",
        "EdgeBetweenness" : 318.91321990171133,
        "shared_name" : "surprised (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "surprised (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 32394,
        "BEND_MAP_ID" : 3432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32392",
        "source" : "30844",
        "target" : "30922",
        "EdgeBetweenness" : 496.40611271370153,
        "shared_name" : "terrible (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "terrible (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32392,
        "BEND_MAP_ID" : 435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32390",
        "source" : "30844",
        "target" : "30656",
        "EdgeBetweenness" : 474.61449293162303,
        "shared_name" : "terrible (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "terrible (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32390,
        "BEND_MAP_ID" : 1220,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32388",
        "source" : "30844",
        "target" : "30560",
        "EdgeBetweenness" : 463.7129039784325,
        "shared_name" : "terrible (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "terrible (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32388,
        "BEND_MAP_ID" : 1638,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32386",
        "source" : "30844",
        "target" : "30120",
        "EdgeBetweenness" : 524.5287864267625,
        "shared_name" : "terrible (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "terrible (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32386,
        "BEND_MAP_ID" : 3996,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32384",
        "source" : "30842",
        "target" : "30922",
        "EdgeBetweenness" : 512.1323590282918,
        "shared_name" : "third (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "third (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32384,
        "BEND_MAP_ID" : 441,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32382",
        "source" : "30842",
        "target" : "30144",
        "EdgeBetweenness" : 565.3413363771988,
        "shared_name" : "third (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "third (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32382,
        "BEND_MAP_ID" : 3784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32380",
        "source" : "30840",
        "target" : "30922",
        "EdgeBetweenness" : 640.5371988078949,
        "shared_name" : "true (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "true (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32380,
        "BEND_MAP_ID" : 447,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32378",
        "source" : "30840",
        "target" : "30656",
        "EdgeBetweenness" : 586.6992020470941,
        "shared_name" : "true (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "true (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32378,
        "BEND_MAP_ID" : 1229,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32376",
        "source" : "30840",
        "target" : "30378",
        "EdgeBetweenness" : 705.4059350693605,
        "shared_name" : "true (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "true (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32376,
        "BEND_MAP_ID" : 2517,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32374",
        "source" : "30840",
        "target" : "30330",
        "EdgeBetweenness" : 545.3944614557366,
        "shared_name" : "true (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "true (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32374,
        "BEND_MAP_ID" : 2666,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32372",
        "source" : "30840",
        "target" : "30308",
        "EdgeBetweenness" : 723.5695798512222,
        "shared_name" : "true (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "true (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32372,
        "BEND_MAP_ID" : 2854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32370",
        "source" : "30840",
        "target" : "30174",
        "EdgeBetweenness" : 583.3814071163713,
        "shared_name" : "true (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "true (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32370,
        "BEND_MAP_ID" : 3620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32368",
        "source" : "30840",
        "target" : "30120",
        "EdgeBetweenness" : 891.732835379995,
        "shared_name" : "true (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "true (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32368,
        "BEND_MAP_ID" : 4014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32366",
        "source" : "30838",
        "target" : "30922",
        "EdgeBetweenness" : 499.42281146160957,
        "shared_name" : "whole (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "whole (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32366,
        "BEND_MAP_ID" : 453,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32364",
        "source" : "30838",
        "target" : "30560",
        "EdgeBetweenness" : 507.0943997613513,
        "shared_name" : "whole (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "whole (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32364,
        "BEND_MAP_ID" : 1653,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32362",
        "source" : "30838",
        "target" : "30484",
        "EdgeBetweenness" : 505.6596029645751,
        "shared_name" : "whole (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "whole (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32362,
        "BEND_MAP_ID" : 1968,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32360",
        "source" : "30838",
        "target" : "30226",
        "EdgeBetweenness" : 537.4299456855343,
        "shared_name" : "whole (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "whole (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32360,
        "BEND_MAP_ID" : 3349,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32358",
        "source" : "30836",
        "target" : "30922",
        "EdgeBetweenness" : 758.6193648028511,
        "shared_name" : "wrong (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "wrong (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32358,
        "BEND_MAP_ID" : 459,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32356",
        "source" : "30836",
        "target" : "30656",
        "EdgeBetweenness" : 704.1823438003779,
        "shared_name" : "wrong (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wrong (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32356,
        "BEND_MAP_ID" : 1235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32354",
        "source" : "30836",
        "target" : "30484",
        "EdgeBetweenness" : 837.7980086625159,
        "shared_name" : "wrong (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wrong (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32354,
        "BEND_MAP_ID" : 1971,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32352",
        "source" : "30836",
        "target" : "30446",
        "EdgeBetweenness" : 868.2762437500287,
        "shared_name" : "wrong (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wrong (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32352,
        "BEND_MAP_ID" : 2189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32350",
        "source" : "30836",
        "target" : "30378",
        "EdgeBetweenness" : 804.8389860503303,
        "shared_name" : "wrong (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wrong (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32350,
        "BEND_MAP_ID" : 2526,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32348",
        "source" : "30836",
        "target" : "30246",
        "EdgeBetweenness" : 549.5975248656964,
        "shared_name" : "wrong (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wrong (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32348,
        "BEND_MAP_ID" : 3149,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32346",
        "source" : "30836",
        "target" : "30174",
        "EdgeBetweenness" : 619.8190572164702,
        "shared_name" : "wrong (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "wrong (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32346,
        "BEND_MAP_ID" : 3632,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32344",
        "source" : "30836",
        "target" : "30144",
        "EdgeBetweenness" : 787.9233920549563,
        "shared_name" : "wrong (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wrong (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32344,
        "BEND_MAP_ID" : 3817,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32342",
        "source" : "30834",
        "target" : "30922",
        "EdgeBetweenness" : 573.7940721323711,
        "shared_name" : "young (interacts with) vol-9",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "young (interacts with) vol-9",
        "interaction" : "interacts with",
        "SUID" : 32342,
        "BEND_MAP_ID" : 465,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32340",
        "source" : "30834",
        "target" : "30656",
        "EdgeBetweenness" : 476.9312023012922,
        "shared_name" : "young (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "young (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32340,
        "BEND_MAP_ID" : 1238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32338",
        "source" : "30834",
        "target" : "30378",
        "EdgeBetweenness" : 555.294592647602,
        "shared_name" : "young (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "young (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32338,
        "BEND_MAP_ID" : 2529,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32336",
        "source" : "30834",
        "target" : "30246",
        "EdgeBetweenness" : 458.15740146893745,
        "shared_name" : "young (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "young (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32336,
        "BEND_MAP_ID" : 3152,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32334",
        "source" : "30834",
        "target" : "30174",
        "EdgeBetweenness" : 488.98214895952185,
        "shared_name" : "young (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "young (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32334,
        "BEND_MAP_ID" : 3635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32332",
        "source" : "30834",
        "target" : "30064",
        "EdgeBetweenness" : 535.4610198238264,
        "shared_name" : "young (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "young (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32332,
        "BEND_MAP_ID" : 4252,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32330",
        "source" : "30832",
        "target" : "30830",
        "EdgeBetweenness" : 608.1506163240302,
        "shared_name" : "- (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "- (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32330,
        "BEND_MAP_ID" : 473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32328",
        "source" : "30832",
        "target" : "30694",
        "EdgeBetweenness" : 393.4846859608184,
        "shared_name" : "- (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "- (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 32328,
        "BEND_MAP_ID" : 927,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32326",
        "source" : "30832",
        "target" : "30618",
        "EdgeBetweenness" : 535.7905612941327,
        "shared_name" : "- (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "- (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32326,
        "BEND_MAP_ID" : 1243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32324",
        "source" : "30828",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "153rd (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "153rd (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32324,
        "BEND_MAP_ID" : 479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32322",
        "source" : "30826",
        "target" : "30830",
        "EdgeBetweenness" : 605.0206366719552,
        "shared_name" : "3rd (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "3rd (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32322,
        "BEND_MAP_ID" : 485,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32320",
        "source" : "30826",
        "target" : "30446",
        "EdgeBetweenness" : 561.6887632154162,
        "shared_name" : "3rd (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "3rd (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32320,
        "BEND_MAP_ID" : 1982,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32318",
        "source" : "30824",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "alien (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "alien (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32318,
        "BEND_MAP_ID" : 491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32316",
        "source" : "30822",
        "target" : "30830",
        "EdgeBetweenness" : 699.4954590765841,
        "shared_name" : "amazing (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "amazing (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32316,
        "BEND_MAP_ID" : 497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32314",
        "source" : "30822",
        "target" : "30742",
        "EdgeBetweenness" : 488.2062692922444,
        "shared_name" : "amazing (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "amazing (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32314,
        "BEND_MAP_ID" : 760,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32312",
        "source" : "30822",
        "target" : "30656",
        "EdgeBetweenness" : 489.96628463326726,
        "shared_name" : "amazing (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "amazing (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32312,
        "BEND_MAP_ID" : 1070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32310",
        "source" : "30822",
        "target" : "30174",
        "EdgeBetweenness" : 538.6156986301304,
        "shared_name" : "amazing (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "amazing (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32310,
        "BEND_MAP_ID" : 3440,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32308",
        "source" : "30822",
        "target" : "30120",
        "EdgeBetweenness" : 683.3170069666652,
        "shared_name" : "amazing (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "amazing (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32308,
        "BEND_MAP_ID" : 3825,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32306",
        "source" : "30820",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "artificial (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "artificial (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32306,
        "BEND_MAP_ID" : 503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32304",
        "source" : "30818",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "astonishing (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "astonishing (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32304,
        "BEND_MAP_ID" : 509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32302",
        "source" : "30816",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "astronomical (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "astronomical (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32302,
        "BEND_MAP_ID" : 515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32300",
        "source" : "30814",
        "target" : "30830",
        "EdgeBetweenness" : 744.6066012135796,
        "shared_name" : "careful (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "careful (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32300,
        "BEND_MAP_ID" : 524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32298",
        "source" : "30814",
        "target" : "30560",
        "EdgeBetweenness" : 537.6347177958879,
        "shared_name" : "careful (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "careful (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32298,
        "BEND_MAP_ID" : 1476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32296",
        "source" : "30814",
        "target" : "30186",
        "EdgeBetweenness" : 361.03342393774835,
        "shared_name" : "careful (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "careful (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 32296,
        "BEND_MAP_ID" : 3360,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32294",
        "source" : "30814",
        "target" : "30174",
        "EdgeBetweenness" : 545.3252419027076,
        "shared_name" : "careful (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "careful (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32294,
        "BEND_MAP_ID" : 3461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32292",
        "source" : "30814",
        "target" : "30144",
        "EdgeBetweenness" : 607.3709588599836,
        "shared_name" : "careful (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "careful (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32292,
        "BEND_MAP_ID" : 3661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32290",
        "source" : "30814",
        "target" : "30078",
        "EdgeBetweenness" : 533.2746393243979,
        "shared_name" : "careful (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "careful (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 32290,
        "BEND_MAP_ID" : 4037,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32288",
        "source" : "30812",
        "target" : "30830",
        "EdgeBetweenness" : 639.0233354659177,
        "shared_name" : "cheap (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cheap (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32288,
        "BEND_MAP_ID" : 530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32286",
        "source" : "30812",
        "target" : "30120",
        "EdgeBetweenness" : 574.5103836320189,
        "shared_name" : "cheap (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cheap (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32286,
        "BEND_MAP_ID" : 3852,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32284",
        "source" : "30810",
        "target" : "30830",
        "EdgeBetweenness" : 1074.6695991831868,
        "shared_name" : "cool (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cool (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32284,
        "BEND_MAP_ID" : 536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32282",
        "source" : "30810",
        "target" : "30656",
        "EdgeBetweenness" : 893.2980421956456,
        "shared_name" : "cool (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cool (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32282,
        "BEND_MAP_ID" : 1091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32280",
        "source" : "30810",
        "target" : "30510",
        "EdgeBetweenness" : 911.6836284946572,
        "shared_name" : "cool (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cool (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 32280,
        "BEND_MAP_ID" : 1696,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32278",
        "source" : "30810",
        "target" : "30484",
        "EdgeBetweenness" : 967.6642532454938,
        "shared_name" : "cool (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "cool (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32278,
        "BEND_MAP_ID" : 1812,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32276",
        "source" : "30810",
        "target" : "30446",
        "EdgeBetweenness" : 961.8675403474448,
        "shared_name" : "cool (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cool (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32276,
        "BEND_MAP_ID" : 2033,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32274",
        "source" : "30810",
        "target" : "30246",
        "EdgeBetweenness" : 588.0290897242145,
        "shared_name" : "cool (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cool (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32274,
        "BEND_MAP_ID" : 3017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32272",
        "source" : "30810",
        "target" : "30226",
        "EdgeBetweenness" : 1023.2931180493189,
        "shared_name" : "cool (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cool (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32272,
        "BEND_MAP_ID" : 3202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32270",
        "source" : "30810",
        "target" : "30174",
        "EdgeBetweenness" : 825.7493352506243,
        "shared_name" : "cool (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "cool (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32270,
        "BEND_MAP_ID" : 3479,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32268",
        "source" : "30810",
        "target" : "30064",
        "EdgeBetweenness" : 855.6857735134828,
        "shared_name" : "cool (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cool (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32268,
        "BEND_MAP_ID" : 4117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32266",
        "source" : "30808",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "courageous (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "courageous (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32266,
        "BEND_MAP_ID" : 542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32264",
        "source" : "30806",
        "target" : "30830",
        "EdgeBetweenness" : 685.8502274703828,
        "shared_name" : "curious (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "curious (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32264,
        "BEND_MAP_ID" : 548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32262",
        "source" : "30806",
        "target" : "30618",
        "EdgeBetweenness" : 678.0836890683053,
        "shared_name" : "curious (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "curious (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32262,
        "BEND_MAP_ID" : 1273,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32260",
        "source" : "30806",
        "target" : "30510",
        "EdgeBetweenness" : 487.80294640670513,
        "shared_name" : "curious (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "curious (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 32260,
        "BEND_MAP_ID" : 1699,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32258",
        "source" : "30806",
        "target" : "30484",
        "EdgeBetweenness" : 558.7708069167408,
        "shared_name" : "curious (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "curious (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32258,
        "BEND_MAP_ID" : 1815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32256",
        "source" : "30806",
        "target" : "30246",
        "EdgeBetweenness" : 524.8880895558407,
        "shared_name" : "curious (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "curious (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32256,
        "BEND_MAP_ID" : 3023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32254",
        "source" : "30804",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "earthling (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "earthling (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32254,
        "BEND_MAP_ID" : 554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32252",
        "source" : "30802",
        "target" : "30830",
        "EdgeBetweenness" : 715.016750620793,
        "shared_name" : "easy (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "easy (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32252,
        "BEND_MAP_ID" : 560,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32250",
        "source" : "30802",
        "target" : "30742",
        "EdgeBetweenness" : 485.29358134633515,
        "shared_name" : "easy (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "easy (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32250,
        "BEND_MAP_ID" : 793,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32248",
        "source" : "30802",
        "target" : "30618",
        "EdgeBetweenness" : 684.233783565836,
        "shared_name" : "easy (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "easy (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32248,
        "BEND_MAP_ID" : 1288,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32246",
        "source" : "30802",
        "target" : "30484",
        "EdgeBetweenness" : 570.9243679728781,
        "shared_name" : "easy (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "easy (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32246,
        "BEND_MAP_ID" : 1818,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32244",
        "source" : "30802",
        "target" : "30330",
        "EdgeBetweenness" : 444.93778002860887,
        "shared_name" : "easy (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "easy (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32244,
        "BEND_MAP_ID" : 2567,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32242",
        "source" : "30802",
        "target" : "30246",
        "EdgeBetweenness" : 517.9973705232885,
        "shared_name" : "easy (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "easy (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32242,
        "BEND_MAP_ID" : 3032,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32240",
        "source" : "30800",
        "target" : "30830",
        "EdgeBetweenness" : 560.7279328147217,
        "shared_name" : "enough (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "enough (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32240,
        "BEND_MAP_ID" : 566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32238",
        "source" : "30800",
        "target" : "30268",
        "EdgeBetweenness" : 366.2423946242242,
        "shared_name" : "enough (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "enough (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32238,
        "BEND_MAP_ID" : 2889,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32236",
        "source" : "30800",
        "target" : "30246",
        "EdgeBetweenness" : 428.7163213962786,
        "shared_name" : "enough (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "enough (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32236,
        "BEND_MAP_ID" : 3044,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32234",
        "source" : "30800",
        "target" : "30226",
        "EdgeBetweenness" : 529.9801097974677,
        "shared_name" : "enough (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "enough (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32234,
        "BEND_MAP_ID" : 3217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32232",
        "source" : "30798",
        "target" : "30830",
        "EdgeBetweenness" : 1174.8189439153546,
        "shared_name" : "entire (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "entire (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32232,
        "BEND_MAP_ID" : 572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32230",
        "source" : "30798",
        "target" : "30694",
        "EdgeBetweenness" : 674.547847135849,
        "shared_name" : "entire (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "entire (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 32230,
        "BEND_MAP_ID" : 966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32228",
        "source" : "30798",
        "target" : "30516",
        "EdgeBetweenness" : 1760.0,
        "shared_name" : "entire (interacts with) vol-11",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "entire (interacts with) vol-11",
        "interaction" : "interacts with",
        "SUID" : 32228,
        "BEND_MAP_ID" : 1661,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32226",
        "source" : "30798",
        "target" : "30246",
        "EdgeBetweenness" : 1211.0870891478137,
        "shared_name" : "entire (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "entire (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32226,
        "BEND_MAP_ID" : 3047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32224",
        "source" : "30796",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "existent (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "existent (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32224,
        "BEND_MAP_ID" : 578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32222",
        "source" : "30794",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "fat (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fat (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32222,
        "BEND_MAP_ID" : 584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32220",
        "source" : "30792",
        "target" : "30830",
        "EdgeBetweenness" : 1337.7237170164678,
        "shared_name" : "first (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "first (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32220,
        "BEND_MAP_ID" : 590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32218",
        "source" : "30792",
        "target" : "30694",
        "EdgeBetweenness" : 1058.3370630311533,
        "shared_name" : "first (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "first (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 32218,
        "BEND_MAP_ID" : 975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32216",
        "source" : "30792",
        "target" : "30618",
        "EdgeBetweenness" : 1504.1636715966556,
        "shared_name" : "first (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "first (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32216,
        "BEND_MAP_ID" : 1330,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32214",
        "source" : "30792",
        "target" : "30560",
        "EdgeBetweenness" : 892.6745190569536,
        "shared_name" : "first (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "first (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32214,
        "BEND_MAP_ID" : 1533,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32212",
        "source" : "30792",
        "target" : "30510",
        "EdgeBetweenness" : 1055.8689745025213,
        "shared_name" : "first (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "first (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 32212,
        "BEND_MAP_ID" : 1708,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32210",
        "source" : "30792",
        "target" : "30484",
        "EdgeBetweenness" : 1170.1160730663603,
        "shared_name" : "first (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "first (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32210,
        "BEND_MAP_ID" : 1833,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32208",
        "source" : "30792",
        "target" : "30446",
        "EdgeBetweenness" : 1365.7070817663077,
        "shared_name" : "first (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "first (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32208,
        "BEND_MAP_ID" : 2072,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32206",
        "source" : "30792",
        "target" : "30330",
        "EdgeBetweenness" : 807.6256758819976,
        "shared_name" : "first (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "first (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32206,
        "BEND_MAP_ID" : 2570,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32204",
        "source" : "30792",
        "target" : "30144",
        "EdgeBetweenness" : 1117.3962602113174,
        "shared_name" : "first (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "first (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32204,
        "BEND_MAP_ID" : 3688,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32202",
        "source" : "30792",
        "target" : "30120",
        "EdgeBetweenness" : 1526.1685092579592,
        "shared_name" : "first (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "first (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32202,
        "BEND_MAP_ID" : 3885,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32200",
        "source" : "30792",
        "target" : "30078",
        "EdgeBetweenness" : 1511.9734495503603,
        "shared_name" : "first (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "first (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 32200,
        "BEND_MAP_ID" : 4052,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32198",
        "source" : "30790",
        "target" : "30830",
        "EdgeBetweenness" : 658.6571245587768,
        "shared_name" : "giant (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "giant (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32198,
        "BEND_MAP_ID" : 596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32196",
        "source" : "30790",
        "target" : "30694",
        "EdgeBetweenness" : 390.8219272030979,
        "shared_name" : "giant (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "giant (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 32196,
        "BEND_MAP_ID" : 981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32194",
        "source" : "30788",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "half (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "half (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32194,
        "BEND_MAP_ID" : 608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32192",
        "source" : "30786",
        "target" : "30830",
        "EdgeBetweenness" : 822.5769292098095,
        "shared_name" : "high (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "high (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32192,
        "BEND_MAP_ID" : 614,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32190",
        "source" : "30786",
        "target" : "30618",
        "EdgeBetweenness" : 969.2318414414353,
        "shared_name" : "high (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "high (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32190,
        "BEND_MAP_ID" : 1351,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32188",
        "source" : "30786",
        "target" : "30484",
        "EdgeBetweenness" : 883.680854765577,
        "shared_name" : "high (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "high (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32188,
        "BEND_MAP_ID" : 1845,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32186",
        "source" : "30786",
        "target" : "30404",
        "EdgeBetweenness" : 574.6825385324034,
        "shared_name" : "high (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "high (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32186,
        "BEND_MAP_ID" : 2236,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32184",
        "source" : "30786",
        "target" : "30308",
        "EdgeBetweenness" : 834.3275561314528,
        "shared_name" : "high (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "high (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32184,
        "BEND_MAP_ID" : 2740,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32182",
        "source" : "30786",
        "target" : "30268",
        "EdgeBetweenness" : 495.09065040687324,
        "shared_name" : "high (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "high (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32182,
        "BEND_MAP_ID" : 2904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32180",
        "source" : "30786",
        "target" : "30064",
        "EdgeBetweenness" : 685.3914776893249,
        "shared_name" : "high (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "high (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32180,
        "BEND_MAP_ID" : 4159,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32178",
        "source" : "30784",
        "target" : "30830",
        "EdgeBetweenness" : 523.8599217090864,
        "shared_name" : "impossible (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "impossible (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32178,
        "BEND_MAP_ID" : 620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32176",
        "source" : "30784",
        "target" : "30330",
        "EdgeBetweenness" : 506.01136008993427,
        "shared_name" : "impossible (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "impossible (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32176,
        "BEND_MAP_ID" : 2588,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32174",
        "source" : "30782",
        "target" : "30830",
        "EdgeBetweenness" : 567.8618331068228,
        "shared_name" : "last (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "last (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32174,
        "BEND_MAP_ID" : 626,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32172",
        "source" : "30782",
        "target" : "30064",
        "EdgeBetweenness" : 505.4040354429233,
        "shared_name" : "last (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "last (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32172,
        "BEND_MAP_ID" : 4174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32170",
        "source" : "30780",
        "target" : "30830",
        "EdgeBetweenness" : 611.9583422911815,
        "shared_name" : "like (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "like (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32170,
        "BEND_MAP_ID" : 635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32168",
        "source" : "30780",
        "target" : "30446",
        "EdgeBetweenness" : 562.504058332561,
        "shared_name" : "like (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "like (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32168,
        "BEND_MAP_ID" : 2117,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32166",
        "source" : "30780",
        "target" : "30378",
        "EdgeBetweenness" : 654.4347016485871,
        "shared_name" : "like (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "like (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32166,
        "BEND_MAP_ID" : 2397,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32164",
        "source" : "30778",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "low (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "low (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32164,
        "BEND_MAP_ID" : 644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32162",
        "source" : "30776",
        "target" : "30830",
        "EdgeBetweenness" : 501.7575645698905,
        "shared_name" : "natural (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "natural (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32162,
        "BEND_MAP_ID" : 656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32160",
        "source" : "30776",
        "target" : "30174",
        "EdgeBetweenness" : 586.7803336652357,
        "shared_name" : "natural (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "natural (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32160,
        "BEND_MAP_ID" : 3542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32158",
        "source" : "30774",
        "target" : "30830",
        "EdgeBetweenness" : 658.6571245587766,
        "shared_name" : "non (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "non (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32158,
        "BEND_MAP_ID" : 662,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32156",
        "source" : "30774",
        "target" : "30694",
        "EdgeBetweenness" : 390.82192720309814,
        "shared_name" : "non (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "non (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 32156,
        "BEND_MAP_ID" : 1005,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32154",
        "source" : "30772",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "notorious (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "notorious (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32154,
        "BEND_MAP_ID" : 668,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32152",
        "source" : "30770",
        "target" : "30830",
        "EdgeBetweenness" : 1630.070283738935,
        "shared_name" : "other (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "other (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32152,
        "BEND_MAP_ID" : 674,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32150",
        "source" : "30770",
        "target" : "30656",
        "EdgeBetweenness" : 1106.5795997393363,
        "shared_name" : "other (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "other (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32150,
        "BEND_MAP_ID" : 1172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32148",
        "source" : "30770",
        "target" : "30560",
        "EdgeBetweenness" : 1017.9291318461889,
        "shared_name" : "other (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "other (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32148,
        "BEND_MAP_ID" : 1587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32146",
        "source" : "30770",
        "target" : "30446",
        "EdgeBetweenness" : 1521.5825840740108,
        "shared_name" : "other (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "other (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32146,
        "BEND_MAP_ID" : 2132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32144",
        "source" : "30770",
        "target" : "30404",
        "EdgeBetweenness" : 872.3621981986533,
        "shared_name" : "other (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "other (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32144,
        "BEND_MAP_ID" : 2266,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32142",
        "source" : "30770",
        "target" : "30378",
        "EdgeBetweenness" : 1375.9909816825236,
        "shared_name" : "other (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "other (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32142,
        "BEND_MAP_ID" : 2436,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32140",
        "source" : "30770",
        "target" : "30330",
        "EdgeBetweenness" : 813.6996879252393,
        "shared_name" : "other (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "other (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32140,
        "BEND_MAP_ID" : 2633,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32138",
        "source" : "30770",
        "target" : "30308",
        "EdgeBetweenness" : 1357.5561602314601,
        "shared_name" : "other (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "other (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32138,
        "BEND_MAP_ID" : 2806,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32136",
        "source" : "30770",
        "target" : "30268",
        "EdgeBetweenness" : 747.8051133742802,
        "shared_name" : "other (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "other (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32136,
        "BEND_MAP_ID" : 2934,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32134",
        "source" : "30770",
        "target" : "30246",
        "EdgeBetweenness" : 884.1912862974826,
        "shared_name" : "other (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "other (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32134,
        "BEND_MAP_ID" : 3116,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32132",
        "source" : "30770",
        "target" : "30226",
        "EdgeBetweenness" : 1461.9336273195581,
        "shared_name" : "other (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "other (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32132,
        "BEND_MAP_ID" : 3277,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32130",
        "source" : "30770",
        "target" : "30186",
        "EdgeBetweenness" : 734.0780293154014,
        "shared_name" : "other (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "other (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 32130,
        "BEND_MAP_ID" : 3411,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32128",
        "source" : "30770",
        "target" : "30174",
        "EdgeBetweenness" : 972.7747651686016,
        "shared_name" : "other (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "other (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32128,
        "BEND_MAP_ID" : 3557,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32126",
        "source" : "30770",
        "target" : "30144",
        "EdgeBetweenness" : 1268.1911562966948,
        "shared_name" : "other (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "other (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32126,
        "BEND_MAP_ID" : 3751,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32124",
        "source" : "30770",
        "target" : "30064",
        "EdgeBetweenness" : 1153.564297551352,
        "shared_name" : "other (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "other (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32124,
        "BEND_MAP_ID" : 4204,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32122",
        "source" : "30768",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "rainy (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "rainy (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32122,
        "BEND_MAP_ID" : 680,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32120",
        "source" : "30766",
        "target" : "30830",
        "EdgeBetweenness" : 525.4906207619769,
        "shared_name" : "ridiculous (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "ridiculous (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32120,
        "BEND_MAP_ID" : 686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32118",
        "source" : "30766",
        "target" : "30560",
        "EdgeBetweenness" : 548.8407561517135,
        "shared_name" : "ridiculous (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ridiculous (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32118,
        "BEND_MAP_ID" : 1599,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32116",
        "source" : "30764",
        "target" : "30830",
        "EdgeBetweenness" : 1621.3033998215392,
        "shared_name" : "same (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "same (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32116,
        "BEND_MAP_ID" : 695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32114",
        "source" : "30764",
        "target" : "30742",
        "EdgeBetweenness" : 1072.7564601704762,
        "shared_name" : "same (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "same (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32114,
        "BEND_MAP_ID" : 880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32112",
        "source" : "30764",
        "target" : "30694",
        "EdgeBetweenness" : 1382.6054072315205,
        "shared_name" : "same (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "same (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 32112,
        "BEND_MAP_ID" : 1035,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32110",
        "source" : "30764",
        "target" : "30618",
        "EdgeBetweenness" : 1880.0713784950915,
        "shared_name" : "same (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "same (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 32110,
        "BEND_MAP_ID" : 1426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32108",
        "source" : "30764",
        "target" : "30484",
        "EdgeBetweenness" : 1505.7620943976701,
        "shared_name" : "same (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "same (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32108,
        "BEND_MAP_ID" : 1911,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32106",
        "source" : "30764",
        "target" : "30446",
        "EdgeBetweenness" : 1597.3615272671277,
        "shared_name" : "same (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "same (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32106,
        "BEND_MAP_ID" : 2150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32104",
        "source" : "30764",
        "target" : "30330",
        "EdgeBetweenness" : 857.0912669438926,
        "shared_name" : "same (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "same (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32104,
        "BEND_MAP_ID" : 2639,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32102",
        "source" : "30764",
        "target" : "30308",
        "EdgeBetweenness" : 1631.203918271261,
        "shared_name" : "same (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "same (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32102,
        "BEND_MAP_ID" : 2827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32100",
        "source" : "30764",
        "target" : "30268",
        "EdgeBetweenness" : 905.7592955005989,
        "shared_name" : "same (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "same (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32100,
        "BEND_MAP_ID" : 2946,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32098",
        "source" : "30764",
        "target" : "30246",
        "EdgeBetweenness" : 1007.430166693897,
        "shared_name" : "same (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "same (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32098,
        "BEND_MAP_ID" : 3122,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32096",
        "source" : "30764",
        "target" : "30186",
        "EdgeBetweenness" : 876.500509574202,
        "shared_name" : "same (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "same (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 32096,
        "BEND_MAP_ID" : 3414,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32094",
        "source" : "30764",
        "target" : "30174",
        "EdgeBetweenness" : 1121.2410324249804,
        "shared_name" : "same (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "same (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32094,
        "BEND_MAP_ID" : 3584,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32092",
        "source" : "30764",
        "target" : "30144",
        "EdgeBetweenness" : 1330.3300131548435,
        "shared_name" : "same (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "same (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32092,
        "BEND_MAP_ID" : 3769,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32090",
        "source" : "30764",
        "target" : "30120",
        "EdgeBetweenness" : 2007.9322778858086,
        "shared_name" : "same (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "same (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32090,
        "BEND_MAP_ID" : 3966,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32088",
        "source" : "30764",
        "target" : "30064",
        "EdgeBetweenness" : 1400.454715006008,
        "shared_name" : "same (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "same (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32088,
        "BEND_MAP_ID" : 4225,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32086",
        "source" : "30762",
        "target" : "30830",
        "EdgeBetweenness" : 896.7403183519516,
        "shared_name" : "serious (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "serious (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32086,
        "BEND_MAP_ID" : 701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32084",
        "source" : "30762",
        "target" : "30656",
        "EdgeBetweenness" : 606.259727423036,
        "shared_name" : "serious (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "serious (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32084,
        "BEND_MAP_ID" : 1205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32082",
        "source" : "30762",
        "target" : "30378",
        "EdgeBetweenness" : 726.3846173109115,
        "shared_name" : "serious (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "serious (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 32082,
        "BEND_MAP_ID" : 2487,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32080",
        "source" : "30762",
        "target" : "30308",
        "EdgeBetweenness" : 691.2926735355724,
        "shared_name" : "serious (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "serious (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32080,
        "BEND_MAP_ID" : 2830,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32078",
        "source" : "30762",
        "target" : "30268",
        "EdgeBetweenness" : 416.89109763291793,
        "shared_name" : "serious (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "serious (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32078,
        "BEND_MAP_ID" : 2955,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32076",
        "source" : "30762",
        "target" : "30246",
        "EdgeBetweenness" : 518.391950671431,
        "shared_name" : "serious (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "serious (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 32076,
        "BEND_MAP_ID" : 3128,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32074",
        "source" : "30762",
        "target" : "30226",
        "EdgeBetweenness" : 765.6483738676624,
        "shared_name" : "serious (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "serious (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32074,
        "BEND_MAP_ID" : 3328,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32072",
        "source" : "30760",
        "target" : "30830",
        "EdgeBetweenness" : 698.4288822485726,
        "shared_name" : "short (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "short (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32072,
        "BEND_MAP_ID" : 707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32070",
        "source" : "30760",
        "target" : "30560",
        "EdgeBetweenness" : 482.67759157448546,
        "shared_name" : "short (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "short (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32070,
        "BEND_MAP_ID" : 1605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32068",
        "source" : "30760",
        "target" : "30510",
        "EdgeBetweenness" : 528.5532873816103,
        "shared_name" : "short (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "short (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 32068,
        "BEND_MAP_ID" : 1765,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32066",
        "source" : "30760",
        "target" : "30404",
        "EdgeBetweenness" : 485.23254012388804,
        "shared_name" : "short (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "short (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32066,
        "BEND_MAP_ID" : 2269,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32064",
        "source" : "30760",
        "target" : "30120",
        "EdgeBetweenness" : 719.4155730657171,
        "shared_name" : "short (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "short (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 32064,
        "BEND_MAP_ID" : 3969,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32062",
        "source" : "30758",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "snowy (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "snowy (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32062,
        "BEND_MAP_ID" : 713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32060",
        "source" : "30756",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "somethign (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "somethign (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32060,
        "BEND_MAP_ID" : 719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32058",
        "source" : "30754",
        "target" : "30830",
        "EdgeBetweenness" : 544.8098740685908,
        "shared_name" : "strong (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "strong (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32058,
        "BEND_MAP_ID" : 725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32056",
        "source" : "30754",
        "target" : "30560",
        "EdgeBetweenness" : 476.8996971071813,
        "shared_name" : "strong (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "strong (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32056,
        "BEND_MAP_ID" : 1623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32054",
        "source" : "30754",
        "target" : "30484",
        "EdgeBetweenness" : 465.50344350855903,
        "shared_name" : "strong (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "strong (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 32054,
        "BEND_MAP_ID" : 1944,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32052",
        "source" : "30754",
        "target" : "30330",
        "EdgeBetweenness" : 395.3015492233298,
        "shared_name" : "strong (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "strong (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32052,
        "BEND_MAP_ID" : 2654,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32050",
        "source" : "30752",
        "target" : "30830",
        "EdgeBetweenness" : 566.3262123662107,
        "shared_name" : "stupid (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "stupid (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32050,
        "BEND_MAP_ID" : 731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32048",
        "source" : "30752",
        "target" : "30656",
        "EdgeBetweenness" : 487.6589542891996,
        "shared_name" : "stupid (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "stupid (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32048,
        "BEND_MAP_ID" : 1214,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32046",
        "source" : "30752",
        "target" : "30186",
        "EdgeBetweenness" : 318.1395312578567,
        "shared_name" : "stupid (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "stupid (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 32046,
        "BEND_MAP_ID" : 3426,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32044",
        "source" : "30752",
        "target" : "30064",
        "EdgeBetweenness" : 462.35154472448187,
        "shared_name" : "stupid (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "stupid (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32044,
        "BEND_MAP_ID" : 4246,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32042",
        "source" : "30750",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sunny (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sunny (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32042,
        "BEND_MAP_ID" : 737,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32040",
        "source" : "30748",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "waterproof (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "waterproof (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32040,
        "BEND_MAP_ID" : 743,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32038",
        "source" : "30746",
        "target" : "30830",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "wooden (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wooden (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32038,
        "BEND_MAP_ID" : 749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32036",
        "source" : "30744",
        "target" : "30830",
        "EdgeBetweenness" : 562.8227595326368,
        "shared_name" : "worth (interacts with) vol-8",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "worth (interacts with) vol-8",
        "interaction" : "interacts with",
        "SUID" : 32036,
        "BEND_MAP_ID" : 755,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32034",
        "source" : "30744",
        "target" : "30144",
        "EdgeBetweenness" : 575.6154116671403,
        "shared_name" : "worth (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "worth (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 32034,
        "BEND_MAP_ID" : 3814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32032",
        "source" : "30740",
        "target" : "30742",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "awesome (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "awesome (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32032,
        "BEND_MAP_ID" : 766,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32030",
        "source" : "30738",
        "target" : "30742",
        "EdgeBetweenness" : 634.6458246693057,
        "shared_name" : "big (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "big (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32030,
        "BEND_MAP_ID" : 772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32028",
        "source" : "30738",
        "target" : "30656",
        "EdgeBetweenness" : 707.493053894755,
        "shared_name" : "big (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "big (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32028,
        "BEND_MAP_ID" : 1076,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32026",
        "source" : "30738",
        "target" : "30560",
        "EdgeBetweenness" : 695.9128995257125,
        "shared_name" : "big (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "big (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32026,
        "BEND_MAP_ID" : 1461,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32024",
        "source" : "30738",
        "target" : "30404",
        "EdgeBetweenness" : 525.9388429787666,
        "shared_name" : "big (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "big (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 32024,
        "BEND_MAP_ID" : 2203,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32022",
        "source" : "30738",
        "target" : "30330",
        "EdgeBetweenness" : 561.2369885507072,
        "shared_name" : "big (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "big (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 32022,
        "BEND_MAP_ID" : 2540,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32020",
        "source" : "30738",
        "target" : "30308",
        "EdgeBetweenness" : 818.0273199628396,
        "shared_name" : "big (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "big (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 32020,
        "BEND_MAP_ID" : 2686,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32018",
        "source" : "30738",
        "target" : "30268",
        "EdgeBetweenness" : 489.9030101578279,
        "shared_name" : "big (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "big (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 32018,
        "BEND_MAP_ID" : 2874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32016",
        "source" : "30738",
        "target" : "30226",
        "EdgeBetweenness" : 915.4990012074496,
        "shared_name" : "big (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "big (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 32016,
        "BEND_MAP_ID" : 3178,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32014",
        "source" : "30738",
        "target" : "30174",
        "EdgeBetweenness" : 667.6558504042868,
        "shared_name" : "big (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "big (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 32014,
        "BEND_MAP_ID" : 3452,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32012",
        "source" : "30738",
        "target" : "30064",
        "EdgeBetweenness" : 755.6911559495669,
        "shared_name" : "big (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "big (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 32012,
        "BEND_MAP_ID" : 4114,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32010",
        "source" : "30736",
        "target" : "30742",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "convenient (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "convenient (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32010,
        "BEND_MAP_ID" : 778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32008",
        "source" : "30734",
        "target" : "30742",
        "EdgeBetweenness" : 383.2593665473889,
        "shared_name" : "deep (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "deep (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32008,
        "BEND_MAP_ID" : 784,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32006",
        "source" : "30734",
        "target" : "30656",
        "EdgeBetweenness" : 411.519558297667,
        "shared_name" : "deep (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "deep (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 32006,
        "BEND_MAP_ID" : 1094,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32004",
        "source" : "30734",
        "target" : "30560",
        "EdgeBetweenness" : 473.7323773737259,
        "shared_name" : "deep (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "deep (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 32004,
        "BEND_MAP_ID" : 1506,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32002",
        "source" : "30734",
        "target" : "30446",
        "EdgeBetweenness" : 488.0129997485723,
        "shared_name" : "deep (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "deep (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 32002,
        "BEND_MAP_ID" : 2042,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "32000",
        "source" : "30732",
        "target" : "30742",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "delicious (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "delicious (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 32000,
        "BEND_MAP_ID" : 790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31998",
        "source" : "30730",
        "target" : "30742",
        "EdgeBetweenness" : 528.2374701970451,
        "shared_name" : "eld (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "eld (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31998,
        "BEND_MAP_ID" : 799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31996",
        "source" : "30730",
        "target" : "30618",
        "EdgeBetweenness" : 516.6934003254637,
        "shared_name" : "eld (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "eld (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31996,
        "BEND_MAP_ID" : 1297,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31994",
        "source" : "30728",
        "target" : "30742",
        "EdgeBetweenness" : 538.6531375076772,
        "shared_name" : "happy (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "happy (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31994,
        "BEND_MAP_ID" : 808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31992",
        "source" : "30728",
        "target" : "30694",
        "EdgeBetweenness" : 670.0423452659196,
        "shared_name" : "happy (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "happy (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31992,
        "BEND_MAP_ID" : 987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31990",
        "source" : "30728",
        "target" : "30510",
        "EdgeBetweenness" : 611.4719243961603,
        "shared_name" : "happy (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "happy (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31990,
        "BEND_MAP_ID" : 1723,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31988",
        "source" : "30728",
        "target" : "30484",
        "EdgeBetweenness" : 641.2328162625562,
        "shared_name" : "happy (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "happy (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31988,
        "BEND_MAP_ID" : 1836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31986",
        "source" : "30728",
        "target" : "30446",
        "EdgeBetweenness" : 720.3586253363309,
        "shared_name" : "happy (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "happy (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31986,
        "BEND_MAP_ID" : 2093,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31984",
        "source" : "30728",
        "target" : "30330",
        "EdgeBetweenness" : 466.7918644352344,
        "shared_name" : "happy (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "happy (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31984,
        "BEND_MAP_ID" : 2585,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31982",
        "source" : "30728",
        "target" : "30246",
        "EdgeBetweenness" : 516.121823561511,
        "shared_name" : "happy (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "happy (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31982,
        "BEND_MAP_ID" : 3056,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31980",
        "source" : "30728",
        "target" : "30186",
        "EdgeBetweenness" : 414.6473495795024,
        "shared_name" : "happy (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "happy (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31980,
        "BEND_MAP_ID" : 3384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31978",
        "source" : "30726",
        "target" : "30742",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "horrendous (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "horrendous (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31978,
        "BEND_MAP_ID" : 814,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31976",
        "source" : "30724",
        "target" : "30742",
        "EdgeBetweenness" : 372.48061348595905,
        "shared_name" : "huge (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "huge (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31976,
        "BEND_MAP_ID" : 820,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31974",
        "source" : "30724",
        "target" : "30378",
        "EdgeBetweenness" : 501.02138600144946,
        "shared_name" : "huge (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "huge (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31974,
        "BEND_MAP_ID" : 2382,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31972",
        "source" : "30724",
        "target" : "30308",
        "EdgeBetweenness" : 462.9676231515985,
        "shared_name" : "huge (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "huge (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31972,
        "BEND_MAP_ID" : 2749,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31970",
        "source" : "30724",
        "target" : "30246",
        "EdgeBetweenness" : 447.6042471207353,
        "shared_name" : "huge (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "huge (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31970,
        "BEND_MAP_ID" : 3065,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31968",
        "source" : "30722",
        "target" : "30742",
        "EdgeBetweenness" : 951.7820099068625,
        "shared_name" : "little (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "little (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31968,
        "BEND_MAP_ID" : 826,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31966",
        "source" : "30722",
        "target" : "30560",
        "EdgeBetweenness" : 937.3319388096315,
        "shared_name" : "little (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "little (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31966,
        "BEND_MAP_ID" : 1563,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31964",
        "source" : "30722",
        "target" : "30510",
        "EdgeBetweenness" : 1262.9751233414368,
        "shared_name" : "little (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "little (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31964,
        "BEND_MAP_ID" : 1738,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31962",
        "source" : "30722",
        "target" : "30484",
        "EdgeBetweenness" : 1313.9561304211054,
        "shared_name" : "little (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "little (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31962,
        "BEND_MAP_ID" : 1863,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31960",
        "source" : "30722",
        "target" : "30446",
        "EdgeBetweenness" : 1408.640359316119,
        "shared_name" : "little (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "little (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31960,
        "BEND_MAP_ID" : 2120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31958",
        "source" : "30722",
        "target" : "30378",
        "EdgeBetweenness" : 1314.1458030825827,
        "shared_name" : "little (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "little (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31958,
        "BEND_MAP_ID" : 2400,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31956",
        "source" : "30722",
        "target" : "30330",
        "EdgeBetweenness" : 824.4020537361303,
        "shared_name" : "little (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "little (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31956,
        "BEND_MAP_ID" : 2600,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31954",
        "source" : "30722",
        "target" : "30246",
        "EdgeBetweenness" : 906.1346516731763,
        "shared_name" : "little (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "little (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31954,
        "BEND_MAP_ID" : 3080,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31952",
        "source" : "30722",
        "target" : "30226",
        "EdgeBetweenness" : 1432.2594979525536,
        "shared_name" : "little (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "little (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31952,
        "BEND_MAP_ID" : 3247,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31950",
        "source" : "30722",
        "target" : "30186",
        "EdgeBetweenness" : 750.871162848448,
        "shared_name" : "little (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "little (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31950,
        "BEND_MAP_ID" : 3402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31948",
        "source" : "30722",
        "target" : "30174",
        "EdgeBetweenness" : 1061.2038409583479,
        "shared_name" : "little (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "little (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31948,
        "BEND_MAP_ID" : 3524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31946",
        "source" : "30722",
        "target" : "30144",
        "EdgeBetweenness" : 1226.5662391312621,
        "shared_name" : "little (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "little (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31946,
        "BEND_MAP_ID" : 3724,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31944",
        "source" : "30722",
        "target" : "30120",
        "EdgeBetweenness" : 1754.963296192682,
        "shared_name" : "little (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 5,
        "name" : "little (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31944,
        "BEND_MAP_ID" : 3909,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31942",
        "source" : "30722",
        "target" : "30064",
        "EdgeBetweenness" : 1234.5867246308474,
        "shared_name" : "little (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "little (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31942,
        "BEND_MAP_ID" : 4177,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31940",
        "source" : "30720",
        "target" : "30742",
        "EdgeBetweenness" : 470.25920231653396,
        "shared_name" : "nice (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "nice (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31940,
        "BEND_MAP_ID" : 841,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31938",
        "source" : "30720",
        "target" : "30694",
        "EdgeBetweenness" : 635.9861927911953,
        "shared_name" : "nice (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "nice (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31938,
        "BEND_MAP_ID" : 1002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31936",
        "source" : "30720",
        "target" : "30656",
        "EdgeBetweenness" : 631.4784017519532,
        "shared_name" : "nice (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "nice (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31936,
        "BEND_MAP_ID" : 1163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31934",
        "source" : "30720",
        "target" : "30560",
        "EdgeBetweenness" : 518.8802614658281,
        "shared_name" : "nice (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "nice (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31934,
        "BEND_MAP_ID" : 1581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31932",
        "source" : "30720",
        "target" : "30510",
        "EdgeBetweenness" : 665.4661611106437,
        "shared_name" : "nice (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "nice (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31932,
        "BEND_MAP_ID" : 1750,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31930",
        "source" : "30720",
        "target" : "30378",
        "EdgeBetweenness" : 655.6416582121451,
        "shared_name" : "nice (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "nice (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31930,
        "BEND_MAP_ID" : 2415,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31928",
        "source" : "30720",
        "target" : "30268",
        "EdgeBetweenness" : 491.43389545814784,
        "shared_name" : "nice (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "nice (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31928,
        "BEND_MAP_ID" : 2925,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31926",
        "source" : "30718",
        "target" : "30742",
        "EdgeBetweenness" : 450.93207853250834,
        "shared_name" : "normal (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "normal (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31926,
        "BEND_MAP_ID" : 847,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31924",
        "source" : "30718",
        "target" : "30510",
        "EdgeBetweenness" : 497.20971874925976,
        "shared_name" : "normal (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "normal (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31924,
        "BEND_MAP_ID" : 1753,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31922",
        "source" : "30718",
        "target" : "30378",
        "EdgeBetweenness" : 594.2901836981036,
        "shared_name" : "normal (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "normal (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31922,
        "BEND_MAP_ID" : 2418,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31920",
        "source" : "30718",
        "target" : "30226",
        "EdgeBetweenness" : 572.8169083129237,
        "shared_name" : "normal (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "normal (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31920,
        "BEND_MAP_ID" : 3271,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31918",
        "source" : "30718",
        "target" : "30064",
        "EdgeBetweenness" : 528.3462523250661,
        "shared_name" : "normal (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "normal (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31918,
        "BEND_MAP_ID" : 4198,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31916",
        "source" : "30716",
        "target" : "30742",
        "EdgeBetweenness" : 360.49939175324386,
        "shared_name" : "only (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "only (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31916,
        "BEND_MAP_ID" : 853,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31914",
        "source" : "30716",
        "target" : "30378",
        "EdgeBetweenness" : 477.41851756111805,
        "shared_name" : "only (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "only (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31914,
        "BEND_MAP_ID" : 2427,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31912",
        "source" : "30716",
        "target" : "30268",
        "EdgeBetweenness" : 353.8720940762199,
        "shared_name" : "only (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "only (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31912,
        "BEND_MAP_ID" : 2931,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31910",
        "source" : "30714",
        "target" : "30742",
        "EdgeBetweenness" : 479.4258215319852,
        "shared_name" : "own (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "own (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31910,
        "BEND_MAP_ID" : 859,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31908",
        "source" : "30714",
        "target" : "30656",
        "EdgeBetweenness" : 715.6274372708322,
        "shared_name" : "own (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "own (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31908,
        "BEND_MAP_ID" : 1175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31906",
        "source" : "30714",
        "target" : "30618",
        "EdgeBetweenness" : 879.5297468085012,
        "shared_name" : "own (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "own (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31906,
        "BEND_MAP_ID" : 1408,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31904",
        "source" : "30714",
        "target" : "30378",
        "EdgeBetweenness" : 643.9319452758001,
        "shared_name" : "own (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "own (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31904,
        "BEND_MAP_ID" : 2439,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31902",
        "source" : "30714",
        "target" : "30226",
        "EdgeBetweenness" : 732.1330162230473,
        "shared_name" : "own (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "own (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31902,
        "BEND_MAP_ID" : 3280,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31900",
        "source" : "30714",
        "target" : "30144",
        "EdgeBetweenness" : 617.1875605834088,
        "shared_name" : "own (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "own (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31900,
        "BEND_MAP_ID" : 3754,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31898",
        "source" : "30712",
        "target" : "30742",
        "EdgeBetweenness" : 490.70669882826235,
        "shared_name" : "quick (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "quick (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31898,
        "BEND_MAP_ID" : 868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31896",
        "source" : "30712",
        "target" : "30446",
        "EdgeBetweenness" : 560.2126064956809,
        "shared_name" : "quick (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "quick (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31896,
        "BEND_MAP_ID" : 2147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31894",
        "source" : "30710",
        "target" : "30742",
        "EdgeBetweenness" : 452.2561819609791,
        "shared_name" : "ready (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "ready (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31894,
        "BEND_MAP_ID" : 874,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31892",
        "source" : "30710",
        "target" : "30510",
        "EdgeBetweenness" : 359.1076759009255,
        "shared_name" : "ready (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ready (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31892,
        "BEND_MAP_ID" : 1762,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31890",
        "source" : "30710",
        "target" : "30484",
        "EdgeBetweenness" : 478.31933087349245,
        "shared_name" : "ready (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ready (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31890,
        "BEND_MAP_ID" : 1905,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31888",
        "source" : "30708",
        "target" : "30742",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "shocked (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "shocked (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31888,
        "BEND_MAP_ID" : 886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31886",
        "source" : "30706",
        "target" : "30742",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sick (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "sick (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31886,
        "BEND_MAP_ID" : 892,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31884",
        "source" : "30704",
        "target" : "30742",
        "EdgeBetweenness" : 410.96509320191643,
        "shared_name" : "such (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "such (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31884,
        "BEND_MAP_ID" : 898,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31882",
        "source" : "30704",
        "target" : "30656",
        "EdgeBetweenness" : 453.93788317952135,
        "shared_name" : "such (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "such (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31882,
        "BEND_MAP_ID" : 1217,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31880",
        "source" : "30704",
        "target" : "30446",
        "EdgeBetweenness" : 498.5415026496856,
        "shared_name" : "such (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "such (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31880,
        "BEND_MAP_ID" : 2165,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31878",
        "source" : "30704",
        "target" : "30330",
        "EdgeBetweenness" : 382.35835791574794,
        "shared_name" : "such (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "such (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31878,
        "BEND_MAP_ID" : 2657,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31876",
        "source" : "30704",
        "target" : "30186",
        "EdgeBetweenness" : 268.58034296654307,
        "shared_name" : "such (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "such (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31876,
        "BEND_MAP_ID" : 3429,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31874",
        "source" : "30704",
        "target" : "30174",
        "EdgeBetweenness" : 471.9268918118954,
        "shared_name" : "such (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "such (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31874,
        "BEND_MAP_ID" : 3605,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31872",
        "source" : "30702",
        "target" : "30742",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "super (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "super (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31872,
        "BEND_MAP_ID" : 904,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31870",
        "source" : "30700",
        "target" : "30742",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "trivial (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "trivial (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31870,
        "BEND_MAP_ID" : 910,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31868",
        "source" : "30698",
        "target" : "30742",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "twisty (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "twisty (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31868,
        "BEND_MAP_ID" : 916,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31866",
        "source" : "30696",
        "target" : "30742",
        "EdgeBetweenness" : 497.20101674534965,
        "shared_name" : "webbed (interacts with) vol-16",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "webbed (interacts with) vol-16",
        "interaction" : "interacts with",
        "SUID" : 31866,
        "BEND_MAP_ID" : 922,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31864",
        "source" : "30696",
        "target" : "30484",
        "EdgeBetweenness" : 517.6425178166212,
        "shared_name" : "webbed (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "webbed (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31864,
        "BEND_MAP_ID" : 1965,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31862",
        "source" : "30692",
        "target" : "30694",
        "EdgeBetweenness" : 565.3805273460191,
        "shared_name" : "able (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "able (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31862,
        "BEND_MAP_ID" : 933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31860",
        "source" : "30692",
        "target" : "30186",
        "EdgeBetweenness" : 403.87909504004705,
        "shared_name" : "able (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "able (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31860,
        "BEND_MAP_ID" : 3354,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31858",
        "source" : "30692",
        "target" : "30144",
        "EdgeBetweenness" : 632.4459974897565,
        "shared_name" : "able (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "able (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31858,
        "BEND_MAP_ID" : 3640,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31856",
        "source" : "30692",
        "target" : "30120",
        "EdgeBetweenness" : 768.2810479422792,
        "shared_name" : "able (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "able (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31856,
        "BEND_MAP_ID" : 3822,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31854",
        "source" : "30692",
        "target" : "30078",
        "EdgeBetweenness" : 533.3436046305465,
        "shared_name" : "able (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "able (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 31854,
        "BEND_MAP_ID" : 4031,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31852",
        "source" : "30690",
        "target" : "30694",
        "EdgeBetweenness" : 476.3538068528364,
        "shared_name" : "ancient (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "ancient (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31852,
        "BEND_MAP_ID" : 939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31850",
        "source" : "30690",
        "target" : "30618",
        "EdgeBetweenness" : 617.0042190565027,
        "shared_name" : "ancient (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ancient (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31850,
        "BEND_MAP_ID" : 1258,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31848",
        "source" : "30688",
        "target" : "30694",
        "EdgeBetweenness" : 417.36216013369375,
        "shared_name" : "awful (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "awful (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31848,
        "BEND_MAP_ID" : 945,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31846",
        "source" : "30688",
        "target" : "30378",
        "EdgeBetweenness" : 704.9543278758624,
        "shared_name" : "awful (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "awful (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31846,
        "BEND_MAP_ID" : 2304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31844",
        "source" : "30686",
        "target" : "30694",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "beautiful (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "beautiful (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31844,
        "BEND_MAP_ID" : 951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31842",
        "source" : "30684",
        "target" : "30694",
        "EdgeBetweenness" : 647.6692759144436,
        "shared_name" : "correct (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "correct (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31842,
        "BEND_MAP_ID" : 957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31840",
        "source" : "30684",
        "target" : "30330",
        "EdgeBetweenness" : 432.460535992977,
        "shared_name" : "correct (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "correct (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31840,
        "BEND_MAP_ID" : 2552,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31838",
        "source" : "30684",
        "target" : "30308",
        "EdgeBetweenness" : 631.6712580756357,
        "shared_name" : "correct (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "correct (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31838,
        "BEND_MAP_ID" : 2689,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31836",
        "source" : "30684",
        "target" : "30246",
        "EdgeBetweenness" : 471.23151657025034,
        "shared_name" : "correct (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "correct (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31836,
        "BEND_MAP_ID" : 3020,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31834",
        "source" : "30684",
        "target" : "30226",
        "EdgeBetweenness" : 662.4847114622603,
        "shared_name" : "correct (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "correct (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31834,
        "BEND_MAP_ID" : 3205,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31832",
        "source" : "30684",
        "target" : "30064",
        "EdgeBetweenness" : 594.3560847730693,
        "shared_name" : "correct (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "correct (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31832,
        "BEND_MAP_ID" : 4120,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31830",
        "source" : "30682",
        "target" : "30694",
        "EdgeBetweenness" : 356.07963011166083,
        "shared_name" : "difficult (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "difficult (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31830,
        "BEND_MAP_ID" : 963,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31828",
        "source" : "30682",
        "target" : "30378",
        "EdgeBetweenness" : 545.6564049381443,
        "shared_name" : "difficult (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "difficult (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31828,
        "BEND_MAP_ID" : 2334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31826",
        "source" : "30682",
        "target" : "30246",
        "EdgeBetweenness" : 461.78562903692915,
        "shared_name" : "difficult (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "difficult (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31826,
        "BEND_MAP_ID" : 3029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31824",
        "source" : "30680",
        "target" : "30694",
        "EdgeBetweenness" : 511.9113139410311,
        "shared_name" : "extra (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "extra (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31824,
        "BEND_MAP_ID" : 972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31822",
        "source" : "30680",
        "target" : "30226",
        "EdgeBetweenness" : 701.2521580964899,
        "shared_name" : "extra (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "extra (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31822,
        "BEND_MAP_ID" : 3226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31820",
        "source" : "30678",
        "target" : "30694",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "horned (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "horned (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31820,
        "BEND_MAP_ID" : 993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31818",
        "source" : "30676",
        "target" : "30694",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "mammalian (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "mammalian (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31818,
        "BEND_MAP_ID" : 999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31816",
        "source" : "30674",
        "target" : "30694",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "official (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "official (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31816,
        "BEND_MAP_ID" : 1011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31814",
        "source" : "30672",
        "target" : "30694",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "original (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "original (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31814,
        "BEND_MAP_ID" : 1017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31812",
        "source" : "30670",
        "target" : "30694",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "precise (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "precise (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31812,
        "BEND_MAP_ID" : 1023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31810",
        "source" : "30668",
        "target" : "30694",
        "EdgeBetweenness" : 362.2654368173893,
        "shared_name" : "random (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "random (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31810,
        "BEND_MAP_ID" : 1029,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31808",
        "source" : "30668",
        "target" : "30174",
        "EdgeBetweenness" : 696.4402162467449,
        "shared_name" : "random (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "random (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31808,
        "BEND_MAP_ID" : 3569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31806",
        "source" : "30666",
        "target" : "30694",
        "EdgeBetweenness" : 540.1693988928462,
        "shared_name" : "sure (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sure (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31806,
        "BEND_MAP_ID" : 1041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31804",
        "source" : "30666",
        "target" : "30484",
        "EdgeBetweenness" : 539.4286191089329,
        "shared_name" : "sure (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sure (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31804,
        "BEND_MAP_ID" : 1950,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31802",
        "source" : "30666",
        "target" : "30446",
        "EdgeBetweenness" : 587.8073535721805,
        "shared_name" : "sure (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sure (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31802,
        "BEND_MAP_ID" : 2168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31800",
        "source" : "30666",
        "target" : "30330",
        "EdgeBetweenness" : 383.9008299500907,
        "shared_name" : "sure (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sure (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31800,
        "BEND_MAP_ID" : 2660,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31798",
        "source" : "30666",
        "target" : "30246",
        "EdgeBetweenness" : 433.88791431218726,
        "shared_name" : "sure (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "sure (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31798,
        "BEND_MAP_ID" : 3140,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31796",
        "source" : "30666",
        "target" : "30174",
        "EdgeBetweenness" : 550.2704782342353,
        "shared_name" : "sure (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sure (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31796,
        "BEND_MAP_ID" : 3611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31794",
        "source" : "30664",
        "target" : "30694",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "swedish (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "swedish (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31794,
        "BEND_MAP_ID" : 1047,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31792",
        "source" : "30662",
        "target" : "30694",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "unnecessary (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "unnecessary (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31792,
        "BEND_MAP_ID" : 1053,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31790",
        "source" : "30660",
        "target" : "30694",
        "EdgeBetweenness" : 551.142494075957,
        "shared_name" : "wonderful (interacts with) vol-17",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wonderful (interacts with) vol-17",
        "interaction" : "interacts with",
        "SUID" : 31790,
        "BEND_MAP_ID" : 1059,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31788",
        "source" : "30660",
        "target" : "30656",
        "EdgeBetweenness" : 576.0894051573463,
        "shared_name" : "wonderful (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wonderful (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31788,
        "BEND_MAP_ID" : 1232,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31786",
        "source" : "30660",
        "target" : "30560",
        "EdgeBetweenness" : 490.0101471066621,
        "shared_name" : "wonderful (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wonderful (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31786,
        "BEND_MAP_ID" : 1656,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31784",
        "source" : "30660",
        "target" : "30144",
        "EdgeBetweenness" : 575.8129875476942,
        "shared_name" : "wonderful (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wonderful (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31784,
        "BEND_MAP_ID" : 3811,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31782",
        "source" : "30660",
        "target" : "30120",
        "EdgeBetweenness" : 617.9858465670877,
        "shared_name" : "wonderful (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wonderful (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31782,
        "BEND_MAP_ID" : 4026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31780",
        "source" : "30658",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "100th (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "100th (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31780,
        "BEND_MAP_ID" : 1067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31778",
        "source" : "30654",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "canadian (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "canadian (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31778,
        "BEND_MAP_ID" : 1082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31776",
        "source" : "30652",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "chure (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "chure (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31776,
        "BEND_MAP_ID" : 1088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31774",
        "source" : "30650",
        "target" : "30656",
        "EdgeBetweenness" : 517.2954247509559,
        "shared_name" : "exciting (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "exciting (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31774,
        "BEND_MAP_ID" : 1100,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31772",
        "source" : "30650",
        "target" : "30446",
        "EdgeBetweenness" : 535.5480951328658,
        "shared_name" : "exciting (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "exciting (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31772,
        "BEND_MAP_ID" : 2063,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31770",
        "source" : "30648",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "further (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "further (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31770,
        "BEND_MAP_ID" : 1106,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31768",
        "source" : "30646",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "future (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "future (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31768,
        "BEND_MAP_ID" : 1112,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31766",
        "source" : "30644",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "grand (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "grand (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31766,
        "BEND_MAP_ID" : 1121,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31764",
        "source" : "30642",
        "target" : "30656",
        "EdgeBetweenness" : 353.0574580930143,
        "shared_name" : "important (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "important (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31764,
        "BEND_MAP_ID" : 1127,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31762",
        "source" : "30642",
        "target" : "30246",
        "EdgeBetweenness" : 411.8370340609417,
        "shared_name" : "important (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "important (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31762,
        "BEND_MAP_ID" : 3068,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31760",
        "source" : "30642",
        "target" : "30174",
        "EdgeBetweenness" : 439.8492180632589,
        "shared_name" : "important (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "important (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31760,
        "BEND_MAP_ID" : 3512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31758",
        "source" : "30640",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "knowledgeable (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "knowledgeable (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31758,
        "BEND_MAP_ID" : 1133,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31756",
        "source" : "30638",
        "target" : "30656",
        "EdgeBetweenness" : 489.66650018031396,
        "shared_name" : "least (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "least (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31756,
        "BEND_MAP_ID" : 1139,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31754",
        "source" : "30638",
        "target" : "30446",
        "EdgeBetweenness" : 547.1078401117587,
        "shared_name" : "least (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "least (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31754,
        "BEND_MAP_ID" : 2111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31752",
        "source" : "30638",
        "target" : "30120",
        "EdgeBetweenness" : 569.9134373036384,
        "shared_name" : "least (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "least (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31752,
        "BEND_MAP_ID" : 3906,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31750",
        "source" : "30636",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "live (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "live (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31750,
        "BEND_MAP_ID" : 1145,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31748",
        "source" : "30634",
        "target" : "30656",
        "EdgeBetweenness" : 460.7449954061885,
        "shared_name" : "middle (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "middle (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31748,
        "BEND_MAP_ID" : 1151,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31746",
        "source" : "30634",
        "target" : "30446",
        "EdgeBetweenness" : 650.1497901556291,
        "shared_name" : "middle (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "middle (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31746,
        "BEND_MAP_ID" : 2126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31744",
        "source" : "30634",
        "target" : "30378",
        "EdgeBetweenness" : 607.9538780942972,
        "shared_name" : "middle (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "middle (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31744,
        "BEND_MAP_ID" : 2406,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31742",
        "source" : "30634",
        "target" : "30308",
        "EdgeBetweenness" : 549.2149642376423,
        "shared_name" : "middle (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "middle (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31742,
        "BEND_MAP_ID" : 2782,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31740",
        "source" : "30634",
        "target" : "30268",
        "EdgeBetweenness" : 361.112047730557,
        "shared_name" : "middle (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "middle (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31740,
        "BEND_MAP_ID" : 2919,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31738",
        "source" : "30632",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "olden (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "olden (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31738,
        "BEND_MAP_ID" : 1169,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31736",
        "source" : "30630",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "pathetic (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "pathetic (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31736,
        "BEND_MAP_ID" : 1181,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31734",
        "source" : "30628",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "portuguese (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "portuguese (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31734,
        "BEND_MAP_ID" : 1187,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31732",
        "source" : "30626",
        "target" : "30656",
        "EdgeBetweenness" : 555.6064482421446,
        "shared_name" : "real (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "real (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31732,
        "BEND_MAP_ID" : 1193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31730",
        "source" : "30626",
        "target" : "30560",
        "EdgeBetweenness" : 527.6989116523459,
        "shared_name" : "real (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "real (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31730,
        "BEND_MAP_ID" : 1596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31728",
        "source" : "30626",
        "target" : "30378",
        "EdgeBetweenness" : 668.4387338953084,
        "shared_name" : "real (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "real (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31728,
        "BEND_MAP_ID" : 2454,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31726",
        "source" : "30626",
        "target" : "30174",
        "EdgeBetweenness" : 520.5752445552001,
        "shared_name" : "real (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "real (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31726,
        "BEND_MAP_ID" : 3572,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31724",
        "source" : "30626",
        "target" : "30078",
        "EdgeBetweenness" : 628.7152887396912,
        "shared_name" : "real (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "real (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 31724,
        "BEND_MAP_ID" : 4070,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31722",
        "source" : "30626",
        "target" : "30064",
        "EdgeBetweenness" : 543.7410616693762,
        "shared_name" : "real (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "real (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31722,
        "BEND_MAP_ID" : 4222,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31720",
        "source" : "30624",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "secondhand (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "secondhand (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31720,
        "BEND_MAP_ID" : 1202,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31718",
        "source" : "30622",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "stupi (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "stupi (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31718,
        "BEND_MAP_ID" : 1211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31716",
        "source" : "30620",
        "target" : "30656",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "tough (interacts with) vol-15",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "tough (interacts with) vol-15",
        "interaction" : "interacts with",
        "SUID" : 31716,
        "BEND_MAP_ID" : 1226,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31714",
        "source" : "30616",
        "target" : "30618",
        "EdgeBetweenness" : 637.9396753225321,
        "shared_name" : "4th (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "4th (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31714,
        "BEND_MAP_ID" : 1249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31712",
        "source" : "30616",
        "target" : "30446",
        "EdgeBetweenness" : 624.152460017271,
        "shared_name" : "4th (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "4th (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31712,
        "BEND_MAP_ID" : 1985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31710",
        "source" : "30616",
        "target" : "30226",
        "EdgeBetweenness" : 622.8262584395069,
        "shared_name" : "4th (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "4th (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31710,
        "BEND_MAP_ID" : 3163,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31708",
        "source" : "30614",
        "target" : "30618",
        "EdgeBetweenness" : 576.7195608447993,
        "shared_name" : "ahem (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ahem (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31708,
        "BEND_MAP_ID" : 1255,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31706",
        "source" : "30614",
        "target" : "30446",
        "EdgeBetweenness" : 657.0988086241522,
        "shared_name" : "ahem (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ahem (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31706,
        "BEND_MAP_ID" : 2012,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31704",
        "source" : "30612",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "comic (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "comic (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31704,
        "BEND_MAP_ID" : 1264,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31702",
        "source" : "30610",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "cross (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cross (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31702,
        "BEND_MAP_ID" : 1270,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31700",
        "source" : "30608",
        "target" : "30618",
        "EdgeBetweenness" : 515.8587112723337,
        "shared_name" : "cute (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cute (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31700,
        "BEND_MAP_ID" : 1279,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31698",
        "source" : "30608",
        "target" : "30560",
        "EdgeBetweenness" : 475.77969945526087,
        "shared_name" : "cute (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "cute (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31698,
        "BEND_MAP_ID" : 1497,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31696",
        "source" : "30608",
        "target" : "30378",
        "EdgeBetweenness" : 545.3732794721438,
        "shared_name" : "cute (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "cute (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31696,
        "BEND_MAP_ID" : 2319,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31694",
        "source" : "30608",
        "target" : "30144",
        "EdgeBetweenness" : 457.76311002664386,
        "shared_name" : "cute (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cute (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31694,
        "BEND_MAP_ID" : 3667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31692",
        "source" : "30606",
        "target" : "30618",
        "EdgeBetweenness" : 471.1155643677468,
        "shared_name" : "drunk (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "drunk (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31692,
        "BEND_MAP_ID" : 1285,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31690",
        "source" : "30606",
        "target" : "30330",
        "EdgeBetweenness" : 582.5124246720109,
        "shared_name" : "drunk (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "drunk (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31690,
        "BEND_MAP_ID" : 2564,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31688",
        "source" : "30604",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "egyptian (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "egyptian (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31688,
        "BEND_MAP_ID" : 1294,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31686",
        "source" : "30602",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "esp (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "esp (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31686,
        "BEND_MAP_ID" : 1303,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31684",
        "source" : "30600",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "everyday (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "everyday (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31684,
        "BEND_MAP_ID" : 1309,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31682",
        "source" : "30598",
        "target" : "30618",
        "EdgeBetweenness" : 453.0182052830621,
        "shared_name" : "exact (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "exact (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31682,
        "BEND_MAP_ID" : 1315,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31680",
        "source" : "30598",
        "target" : "30144",
        "EdgeBetweenness" : 593.2318333838632,
        "shared_name" : "exact (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "exact (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31680,
        "BEND_MAP_ID" : 3679,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31678",
        "source" : "30596",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "excited (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "excited (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31678,
        "BEND_MAP_ID" : 1321,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31676",
        "source" : "30594",
        "target" : "30618",
        "EdgeBetweenness" : 495.9773290654366,
        "shared_name" : "expensive (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "expensive (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31676,
        "BEND_MAP_ID" : 1327,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31674",
        "source" : "30594",
        "target" : "30174",
        "EdgeBetweenness" : 580.8040570047726,
        "shared_name" : "expensive (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "expensive (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31674,
        "BEND_MAP_ID" : 3482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31672",
        "source" : "30594",
        "target" : "30064",
        "EdgeBetweenness" : 444.51859380524826,
        "shared_name" : "expensive (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "expensive (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31672,
        "BEND_MAP_ID" : 4147,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31670",
        "source" : "30592",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "henohenou_chi (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "henohenou_chi (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31670,
        "BEND_MAP_ID" : 1342,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31668",
        "source" : "30590",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "hey (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "hey (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31668,
        "BEND_MAP_ID" : 1348,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31666",
        "source" : "30588",
        "target" : "30618",
        "EdgeBetweenness" : 569.2825243332471,
        "shared_name" : "interested (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "interested (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31666,
        "BEND_MAP_ID" : 1357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31664",
        "source" : "30588",
        "target" : "30484",
        "EdgeBetweenness" : 519.6888446966416,
        "shared_name" : "interested (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "interested (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31664,
        "BEND_MAP_ID" : 1854,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31662",
        "source" : "30588",
        "target" : "30446",
        "EdgeBetweenness" : 640.5125634074321,
        "shared_name" : "interested (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "interested (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31662,
        "BEND_MAP_ID" : 2102,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31660",
        "source" : "30588",
        "target" : "30144",
        "EdgeBetweenness" : 584.1892390894624,
        "shared_name" : "interested (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "interested (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31660,
        "BEND_MAP_ID" : 3709,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31658",
        "source" : "30586",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "italian (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "italian (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31658,
        "BEND_MAP_ID" : 1363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31656",
        "source" : "30584",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "legged (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "legged (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31656,
        "BEND_MAP_ID" : 1369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31654",
        "source" : "30582",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "maaa (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "maaa (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31654,
        "BEND_MAP_ID" : 1375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31652",
        "source" : "30580",
        "target" : "30618",
        "EdgeBetweenness" : 471.115564367747,
        "shared_name" : "mean (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "mean (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31652,
        "BEND_MAP_ID" : 1384,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31650",
        "source" : "30580",
        "target" : "30330",
        "EdgeBetweenness" : 582.5124246720109,
        "shared_name" : "mean (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "mean (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31650,
        "BEND_MAP_ID" : 2609,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31648",
        "source" : "30578",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "miraculous (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "miraculous (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31648,
        "BEND_MAP_ID" : 1390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31646",
        "source" : "30576",
        "target" : "30618",
        "EdgeBetweenness" : 689.4909934905751,
        "shared_name" : "new (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "new (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31646,
        "BEND_MAP_ID" : 1396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31644",
        "source" : "30576",
        "target" : "30560",
        "EdgeBetweenness" : 536.1056256526259,
        "shared_name" : "new (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "new (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31644,
        "BEND_MAP_ID" : 1578,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31642",
        "source" : "30576",
        "target" : "30510",
        "EdgeBetweenness" : 530.1045146666776,
        "shared_name" : "new (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "new (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31642,
        "BEND_MAP_ID" : 1747,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31640",
        "source" : "30576",
        "target" : "30246",
        "EdgeBetweenness" : 545.9216275344886,
        "shared_name" : "new (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "new (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31640,
        "BEND_MAP_ID" : 3104,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31638",
        "source" : "30576",
        "target" : "30144",
        "EdgeBetweenness" : 592.2017191842756,
        "shared_name" : "new (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "new (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31638,
        "BEND_MAP_ID" : 3736,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31636",
        "source" : "30576",
        "target" : "30064",
        "EdgeBetweenness" : 553.8364721687369,
        "shared_name" : "new (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "new (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31636,
        "BEND_MAP_ID" : 4195,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31634",
        "source" : "30574",
        "target" : "30618",
        "EdgeBetweenness" : 453.01820528306166,
        "shared_name" : "odd (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "odd (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31634,
        "BEND_MAP_ID" : 1402,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31632",
        "source" : "30574",
        "target" : "30144",
        "EdgeBetweenness" : 593.2318333838635,
        "shared_name" : "odd (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "odd (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31632,
        "BEND_MAP_ID" : 3745,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31630",
        "source" : "30572",
        "target" : "30618",
        "EdgeBetweenness" : 589.8223637686151,
        "shared_name" : "raw (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "raw (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31630,
        "BEND_MAP_ID" : 1417,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31628",
        "source" : "30572",
        "target" : "30120",
        "EdgeBetweenness" : 652.2573199511301,
        "shared_name" : "raw (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "raw (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31628,
        "BEND_MAP_ID" : 3960,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31626",
        "source" : "30570",
        "target" : "30618",
        "EdgeBetweenness" : 453.0182052830615,
        "shared_name" : "striped (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "striped (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31626,
        "BEND_MAP_ID" : 1432,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31624",
        "source" : "30570",
        "target" : "30144",
        "EdgeBetweenness" : 593.2318333838637,
        "shared_name" : "striped (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "striped (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31624,
        "BEND_MAP_ID" : 3781,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31622",
        "source" : "30568",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sweet (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sweet (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31622,
        "BEND_MAP_ID" : 1438,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31620",
        "source" : "30566",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "tyrannical (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "tyrannical (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31620,
        "BEND_MAP_ID" : 1444,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31618",
        "source" : "30564",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "usoooooopp (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "usoooooopp (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31618,
        "BEND_MAP_ID" : 1450,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31616",
        "source" : "30562",
        "target" : "30618",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "vulgar (interacts with) vol-14",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "vulgar (interacts with) vol-14",
        "interaction" : "interacts with",
        "SUID" : 31616,
        "BEND_MAP_ID" : 1456,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31614",
        "source" : "30558",
        "target" : "30560",
        "EdgeBetweenness" : 503.8758383053531,
        "shared_name" : "bottom (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bottom (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31614,
        "BEND_MAP_ID" : 1467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31612",
        "source" : "30558",
        "target" : "30510",
        "EdgeBetweenness" : 338.58058083525157,
        "shared_name" : "bottom (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bottom (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31612,
        "BEND_MAP_ID" : 1678,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31610",
        "source" : "30558",
        "target" : "30446",
        "EdgeBetweenness" : 522.7970554319055,
        "shared_name" : "bottom (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bottom (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31610,
        "BEND_MAP_ID" : 2024,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31608",
        "source" : "30556",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "bzzzt (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bzzzt (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31608,
        "BEND_MAP_ID" : 1473,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31606",
        "source" : "30554",
        "target" : "30560",
        "EdgeBetweenness" : 443.3565709219388,
        "shared_name" : "certain (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "certain (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31606,
        "BEND_MAP_ID" : 1482,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31604",
        "source" : "30554",
        "target" : "30510",
        "EdgeBetweenness" : 453.6316725726701,
        "shared_name" : "certain (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "certain (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31604,
        "BEND_MAP_ID" : 1681,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31602",
        "source" : "30554",
        "target" : "30378",
        "EdgeBetweenness" : 573.0653316111485,
        "shared_name" : "certain (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "certain (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31602,
        "BEND_MAP_ID" : 2313,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31600",
        "source" : "30554",
        "target" : "30246",
        "EdgeBetweenness" : 548.7526645424042,
        "shared_name" : "certain (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "certain (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31600,
        "BEND_MAP_ID" : 3011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31598",
        "source" : "30554",
        "target" : "30120",
        "EdgeBetweenness" : 670.541460662264,
        "shared_name" : "certain (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "certain (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31598,
        "BEND_MAP_ID" : 3849,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31596",
        "source" : "30552",
        "target" : "30560",
        "EdgeBetweenness" : 409.45895200548364,
        "shared_name" : "chinese (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "chinese (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31596,
        "BEND_MAP_ID" : 1488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31594",
        "source" : "30552",
        "target" : "30404",
        "EdgeBetweenness" : 314.5653012921185,
        "shared_name" : "chinese (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "chinese (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31594,
        "BEND_MAP_ID" : 2206,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31592",
        "source" : "30552",
        "target" : "30378",
        "EdgeBetweenness" : 488.8790011585649,
        "shared_name" : "chinese (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "chinese (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31592,
        "BEND_MAP_ID" : 2316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31590",
        "source" : "30552",
        "target" : "30268",
        "EdgeBetweenness" : 303.49161726080644,
        "shared_name" : "chinese (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "chinese (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31590,
        "BEND_MAP_ID" : 2883,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31588",
        "source" : "30552",
        "target" : "30174",
        "EdgeBetweenness" : 441.54283210051074,
        "shared_name" : "chinese (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "chinese (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31588,
        "BEND_MAP_ID" : 3470,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31586",
        "source" : "30550",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "crazy (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "crazy (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31586,
        "BEND_MAP_ID" : 1494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31584",
        "source" : "30548",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "decorative (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "decorative (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31584,
        "BEND_MAP_ID" : 1503,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31582",
        "source" : "30546",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "dreadful (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dreadful (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31582,
        "BEND_MAP_ID" : 1512,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31580",
        "source" : "30544",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "favorite (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "favorite (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31580,
        "BEND_MAP_ID" : 1518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31578",
        "source" : "30542",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "final (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "final (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31578,
        "BEND_MAP_ID" : 1524,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31576",
        "source" : "30540",
        "target" : "30560",
        "EdgeBetweenness" : 551.3364568319912,
        "shared_name" : "fine (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fine (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31576,
        "BEND_MAP_ID" : 1530,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31574",
        "source" : "30540",
        "target" : "30404",
        "EdgeBetweenness" : 287.42724259391525,
        "shared_name" : "fine (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fine (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31574,
        "BEND_MAP_ID" : 2224,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31572",
        "source" : "30540",
        "target" : "30186",
        "EdgeBetweenness" : 280.0549002722933,
        "shared_name" : "fine (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fine (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31572,
        "BEND_MAP_ID" : 3372,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31570",
        "source" : "30538",
        "target" : "30560",
        "EdgeBetweenness" : 436.2281022854881,
        "shared_name" : "funny (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "funny (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31570,
        "BEND_MAP_ID" : 1542,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31568",
        "source" : "30538",
        "target" : "30446",
        "EdgeBetweenness" : 532.5668804777348,
        "shared_name" : "funny (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "funny (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31568,
        "BEND_MAP_ID" : 2087,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31566",
        "source" : "30538",
        "target" : "30174",
        "EdgeBetweenness" : 494.9408734518077,
        "shared_name" : "funny (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "funny (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31566,
        "BEND_MAP_ID" : 3500,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31564",
        "source" : "30538",
        "target" : "30120",
        "EdgeBetweenness" : 536.7145721788811,
        "shared_name" : "funny (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "funny (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31564,
        "BEND_MAP_ID" : 3897,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31562",
        "source" : "30536",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "gigantic (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "gigantic (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31562,
        "BEND_MAP_ID" : 1548,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31560",
        "source" : "30534",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "glad (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "glad (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31560,
        "BEND_MAP_ID" : 1554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31558",
        "source" : "30532",
        "target" : "30560",
        "EdgeBetweenness" : 466.552145283455,
        "shared_name" : "main (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "main (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31558,
        "BEND_MAP_ID" : 1569,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31556",
        "source" : "30532",
        "target" : "30446",
        "EdgeBetweenness" : 506.6162186047833,
        "shared_name" : "main (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "main (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31556,
        "BEND_MAP_ID" : 2123,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31554",
        "source" : "30532",
        "target" : "30268",
        "EdgeBetweenness" : 359.03787384803536,
        "shared_name" : "main (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "main (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31554,
        "BEND_MAP_ID" : 2913,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31552",
        "source" : "30532",
        "target" : "30246",
        "EdgeBetweenness" : 434.0397440831506,
        "shared_name" : "main (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "main (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31552,
        "BEND_MAP_ID" : 3083,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31550",
        "source" : "30532",
        "target" : "30186",
        "EdgeBetweenness" : 256.2061874350912,
        "shared_name" : "main (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "main (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31550,
        "BEND_MAP_ID" : 3405,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31548",
        "source" : "30532",
        "target" : "30174",
        "EdgeBetweenness" : 435.404246276243,
        "shared_name" : "main (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "main (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31548,
        "BEND_MAP_ID" : 3527,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31546",
        "source" : "30530",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "pointless (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "pointless (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31546,
        "BEND_MAP_ID" : 1593,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31544",
        "source" : "30528",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sixth (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sixth (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31544,
        "BEND_MAP_ID" : 1611,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31542",
        "source" : "30526",
        "target" : "30560",
        "EdgeBetweenness" : 522.2455112068833,
        "shared_name" : "straight (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "straight (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31542,
        "BEND_MAP_ID" : 1620,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31540",
        "source" : "30526",
        "target" : "30510",
        "EdgeBetweenness" : 311.7945940810033,
        "shared_name" : "straight (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "straight (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31540,
        "BEND_MAP_ID" : 1777,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31538",
        "source" : "30526",
        "target" : "30484",
        "EdgeBetweenness" : 463.59373459105154,
        "shared_name" : "straight (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "straight (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31538,
        "BEND_MAP_ID" : 1941,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31536",
        "source" : "30524",
        "target" : "30560",
        "EdgeBetweenness" : 465.1200518633258,
        "shared_name" : "sudden (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sudden (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31536,
        "BEND_MAP_ID" : 1629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31534",
        "source" : "30524",
        "target" : "30484",
        "EdgeBetweenness" : 529.4856070165196,
        "shared_name" : "sudden (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sudden (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31534,
        "BEND_MAP_ID" : 1947,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31532",
        "source" : "30524",
        "target" : "30308",
        "EdgeBetweenness" : 531.634065133567,
        "shared_name" : "sudden (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sudden (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31532,
        "BEND_MAP_ID" : 2842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31530",
        "source" : "30524",
        "target" : "30174",
        "EdgeBetweenness" : 492.1711715156885,
        "shared_name" : "sudden (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sudden (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31530,
        "BEND_MAP_ID" : 3608,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31528",
        "source" : "30522",
        "target" : "30560",
        "EdgeBetweenness" : 499.2819903419783,
        "shared_name" : "tall (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "tall (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31528,
        "BEND_MAP_ID" : 1635,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31526",
        "source" : "30522",
        "target" : "30378",
        "EdgeBetweenness" : 514.6676998269835,
        "shared_name" : "tall (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "tall (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31526,
        "BEND_MAP_ID" : 2496,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31524",
        "source" : "30520",
        "target" : "30560",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "unyielding (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "unyielding (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31524,
        "BEND_MAP_ID" : 1644,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31522",
        "source" : "30518",
        "target" : "30560",
        "EdgeBetweenness" : 484.4786242043539,
        "shared_name" : "upper (interacts with) vol-10",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "upper (interacts with) vol-10",
        "interaction" : "interacts with",
        "SUID" : 31522,
        "BEND_MAP_ID" : 1650,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31520",
        "source" : "30518",
        "target" : "30446",
        "EdgeBetweenness" : 538.3232494823579,
        "shared_name" : "upper (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "upper (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31520,
        "BEND_MAP_ID" : 2174,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31518",
        "source" : "30518",
        "target" : "30120",
        "EdgeBetweenness" : 503.6149489668862,
        "shared_name" : "upper (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "upper (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31518,
        "BEND_MAP_ID" : 4017,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31516",
        "source" : "30514",
        "target" : "30516",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "frequent (interacts with) vol-11",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "frequent (interacts with) vol-11",
        "interaction" : "interacts with",
        "SUID" : 31516,
        "BEND_MAP_ID" : 1667,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31514",
        "source" : "30512",
        "target" : "30510",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "blurry (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "blurry (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31514,
        "BEND_MAP_ID" : 1675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31512",
        "source" : "30508",
        "target" : "30510",
        "EdgeBetweenness" : 384.24883691943495,
        "shared_name" : "close (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "close (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31512,
        "BEND_MAP_ID" : 1687,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31510",
        "source" : "30508",
        "target" : "30330",
        "EdgeBetweenness" : 634.5869484787113,
        "shared_name" : "close (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "close (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31510,
        "BEND_MAP_ID" : 2549,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31508",
        "source" : "30506",
        "target" : "30510",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "confusing (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "confusing (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31508,
        "BEND_MAP_ID" : 1693,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31506",
        "source" : "30504",
        "target" : "30510",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "excellent (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "excellent (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31506,
        "BEND_MAP_ID" : 1705,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31504",
        "source" : "30502",
        "target" : "30510",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "graphic (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "graphic (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31504,
        "BEND_MAP_ID" : 1717,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31502",
        "source" : "30500",
        "target" : "30510",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "impressive (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "impressive (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31502,
        "BEND_MAP_ID" : 1729,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31500",
        "source" : "30498",
        "target" : "30510",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "likely (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "likely (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31500,
        "BEND_MAP_ID" : 1735,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31498",
        "source" : "30496",
        "target" : "30510",
        "EdgeBetweenness" : 428.50095775405634,
        "shared_name" : "naked (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "naked (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31498,
        "BEND_MAP_ID" : 1744,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31496",
        "source" : "30496",
        "target" : "30308",
        "EdgeBetweenness" : 554.9096886419967,
        "shared_name" : "naked (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "naked (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31496,
        "BEND_MAP_ID" : 2788,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31494",
        "source" : "30496",
        "target" : "30246",
        "EdgeBetweenness" : 503.1889579389033,
        "shared_name" : "naked (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "naked (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31494,
        "BEND_MAP_ID" : 3101,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31492",
        "source" : "30494",
        "target" : "30510",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "outward (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "outward (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31492,
        "BEND_MAP_ID" : 1759,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31490",
        "source" : "30492",
        "target" : "30510",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sighted (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "sighted (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31490,
        "BEND_MAP_ID" : 1771,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31488",
        "source" : "30490",
        "target" : "30510",
        "EdgeBetweenness" : 721.8792960095235,
        "shared_name" : "white (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "white (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31488,
        "BEND_MAP_ID" : 1783,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31486",
        "source" : "30490",
        "target" : "30078",
        "EdgeBetweenness" : 362.78852158764676,
        "shared_name" : "white (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "white (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 31486,
        "BEND_MAP_ID" : 4091,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31484",
        "source" : "30488",
        "target" : "30510",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "worthy (interacts with) vol-13",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "worthy (interacts with) vol-13",
        "interaction" : "interacts with",
        "SUID" : 31484,
        "BEND_MAP_ID" : 1789,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31482",
        "source" : "30486",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "41st (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "41st (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31482,
        "BEND_MAP_ID" : 1797,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31480",
        "source" : "30482",
        "target" : "30484",
        "EdgeBetweenness" : 446.30409736961354,
        "shared_name" : "cold (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cold (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31480,
        "BEND_MAP_ID" : 1803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31478",
        "source" : "30482",
        "target" : "30246",
        "EdgeBetweenness" : 465.12195854413255,
        "shared_name" : "cold (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "cold (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31478,
        "BEND_MAP_ID" : 3014,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31476",
        "source" : "30482",
        "target" : "30226",
        "EdgeBetweenness" : 479.56302232868427,
        "shared_name" : "cold (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cold (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31476,
        "BEND_MAP_ID" : 3193,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31474",
        "source" : "30480",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "complicated (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "complicated (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31474,
        "BEND_MAP_ID" : 1809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31472",
        "source" : "30478",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "facial (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "facial (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31472,
        "BEND_MAP_ID" : 1827,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31470",
        "source" : "30476",
        "target" : "30484",
        "EdgeBetweenness" : 596.9083806369048,
        "shared_name" : "hard (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "hard (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31470,
        "BEND_MAP_ID" : 1842,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31468",
        "source" : "30476",
        "target" : "30378",
        "EdgeBetweenness" : 596.214000670797,
        "shared_name" : "hard (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "hard (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31468,
        "BEND_MAP_ID" : 2379,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31466",
        "source" : "30476",
        "target" : "30144",
        "EdgeBetweenness" : 527.9448039140542,
        "shared_name" : "hard (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "hard (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31466,
        "BEND_MAP_ID" : 3700,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31464",
        "source" : "30476",
        "target" : "30120",
        "EdgeBetweenness" : 585.2983897196011,
        "shared_name" : "hard (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "hard (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31464,
        "BEND_MAP_ID" : 3903,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31462",
        "source" : "30474",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "hot (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "hot (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31462,
        "BEND_MAP_ID" : 1851,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31460",
        "source" : "30472",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "la (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "la (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31460,
        "BEND_MAP_ID" : 1860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31458",
        "source" : "30470",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "local (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "local (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31458,
        "BEND_MAP_ID" : 1869,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31456",
        "source" : "30468",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "lucky (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "lucky (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31456,
        "BEND_MAP_ID" : 1875,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31454",
        "source" : "30466",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "ooh (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ooh (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31454,
        "BEND_MAP_ID" : 1890,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31452",
        "source" : "30464",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "part (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "part (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31452,
        "BEND_MAP_ID" : 1896,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31450",
        "source" : "30462",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "previous (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "previous (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31450,
        "BEND_MAP_ID" : 1902,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31448",
        "source" : "30460",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "several (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "several (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31448,
        "BEND_MAP_ID" : 1917,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31446",
        "source" : "30458",
        "target" : "30484",
        "EdgeBetweenness" : 507.03433873745786,
        "shared_name" : "sexy (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "sexy (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31446,
        "BEND_MAP_ID" : 1923,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31444",
        "source" : "30458",
        "target" : "30446",
        "EdgeBetweenness" : 557.3626376129234,
        "shared_name" : "sexy (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "sexy (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31444,
        "BEND_MAP_ID" : 2153,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31442",
        "source" : "30456",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "specific (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "specific (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31442,
        "BEND_MAP_ID" : 1932,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31440",
        "source" : "30454",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "splendid (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "splendid (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31440,
        "BEND_MAP_ID" : 1938,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31438",
        "source" : "30452",
        "target" : "30484",
        "EdgeBetweenness" : 458.43868166631427,
        "shared_name" : "uhhh (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "uhhh (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31438,
        "BEND_MAP_ID" : 1956,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31436",
        "source" : "30452",
        "target" : "30330",
        "EdgeBetweenness" : 535.510373173316,
        "shared_name" : "uhhh (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "uhhh (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31436,
        "BEND_MAP_ID" : 2669,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31434",
        "source" : "30450",
        "target" : "30484",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "unauthorized (interacts with) vol-12",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "unauthorized (interacts with) vol-12",
        "interaction" : "interacts with",
        "SUID" : 31434,
        "BEND_MAP_ID" : 1962,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31432",
        "source" : "30448",
        "target" : "30446",
        "EdgeBetweenness" : 480.7027936838051,
        "shared_name" : "2nd (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "2nd (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31432,
        "BEND_MAP_ID" : 1979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31430",
        "source" : "30448",
        "target" : "30330",
        "EdgeBetweenness" : 421.3010688818123,
        "shared_name" : "2nd (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "2nd (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31430,
        "BEND_MAP_ID" : 2534,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31428",
        "source" : "30448",
        "target" : "30226",
        "EdgeBetweenness" : 485.78447933488343,
        "shared_name" : "2nd (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "2nd (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31428,
        "BEND_MAP_ID" : 3160,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31426",
        "source" : "30444",
        "target" : "30446",
        "EdgeBetweenness" : 480.9725354048396,
        "shared_name" : "5th (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "5th (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31426,
        "BEND_MAP_ID" : 1991,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31424",
        "source" : "30444",
        "target" : "30330",
        "EdgeBetweenness" : 504.5659984128865,
        "shared_name" : "5th (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "5th (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31424,
        "BEND_MAP_ID" : 2537,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31422",
        "source" : "30442",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "6th (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "6th (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31422,
        "BEND_MAP_ID" : 1997,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31420",
        "source" : "30440",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "7th (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "7th (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31420,
        "BEND_MAP_ID" : 2003,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31418",
        "source" : "30438",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "afraid (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "afraid (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31418,
        "BEND_MAP_ID" : 2009,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31416",
        "source" : "30436",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "best (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "best (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31416,
        "BEND_MAP_ID" : 2021,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31414",
        "source" : "30434",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "changed (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "changed (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31414,
        "BEND_MAP_ID" : 2030,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31412",
        "source" : "30432",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "dedicated (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dedicated (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31412,
        "BEND_MAP_ID" : 2039,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31410",
        "source" : "30430",
        "target" : "30446",
        "EdgeBetweenness" : 398.8858459718874,
        "shared_name" : "different (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "different (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31410,
        "BEND_MAP_ID" : 2048,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31408",
        "source" : "30430",
        "target" : "30330",
        "EdgeBetweenness" : 362.3622520417012,
        "shared_name" : "different (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "different (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31408,
        "BEND_MAP_ID" : 2561,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31406",
        "source" : "30430",
        "target" : "30246",
        "EdgeBetweenness" : 426.6926172194409,
        "shared_name" : "different (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "different (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31406,
        "BEND_MAP_ID" : 3026,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31404",
        "source" : "30430",
        "target" : "30186",
        "EdgeBetweenness" : 213.9056245494013,
        "shared_name" : "different (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "different (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31404,
        "BEND_MAP_ID" : 3363,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31402",
        "source" : "30428",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "duper (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "duper (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31402,
        "BEND_MAP_ID" : 2054,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31400",
        "source" : "30426",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "esoteric (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "esoteric (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31400,
        "BEND_MAP_ID" : 2060,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31398",
        "source" : "30424",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "fair (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fair (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31398,
        "BEND_MAP_ID" : 2069,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31396",
        "source" : "30422",
        "target" : "30446",
        "EdgeBetweenness" : 618.7500956390535,
        "shared_name" : "foreign (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "foreign (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31396,
        "BEND_MAP_ID" : 2078,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31394",
        "source" : "30422",
        "target" : "30186",
        "EdgeBetweenness" : 332.58921610658285,
        "shared_name" : "foreign (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "foreign (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31394,
        "BEND_MAP_ID" : 3375,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31392",
        "source" : "30420",
        "target" : "30446",
        "EdgeBetweenness" : 456.01158886296304,
        "shared_name" : "free (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "free (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31392,
        "BEND_MAP_ID" : 2084,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31390",
        "source" : "30420",
        "target" : "30174",
        "EdgeBetweenness" : 582.7602051176307,
        "shared_name" : "free (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "free (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31390,
        "BEND_MAP_ID" : 3491,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31388",
        "source" : "30418",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "humorous (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "humorous (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31388,
        "BEND_MAP_ID" : 2099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31386",
        "source" : "30416",
        "target" : "30446",
        "EdgeBetweenness" : 585.8829109275671,
        "shared_name" : "ish (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ish (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31386,
        "BEND_MAP_ID" : 2108,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31384",
        "source" : "30416",
        "target" : "30226",
        "EdgeBetweenness" : 559.9854732025598,
        "shared_name" : "ish (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ish (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31384,
        "BEND_MAP_ID" : 3238,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31382",
        "source" : "30414",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "professional (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "professional (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31382,
        "BEND_MAP_ID" : 2138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31380",
        "source" : "30412",
        "target" : "30446",
        "EdgeBetweenness" : 594.1813783482816,
        "shared_name" : "proper (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "proper (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31380,
        "BEND_MAP_ID" : 2144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31378",
        "source" : "30412",
        "target" : "30308",
        "EdgeBetweenness" : 558.59406456599,
        "shared_name" : "proper (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "proper (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31378,
        "BEND_MAP_ID" : 2809,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31376",
        "source" : "30410",
        "target" : "30446",
        "EdgeBetweenness" : 618.7500956390533,
        "shared_name" : "strange (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "strange (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31376,
        "BEND_MAP_ID" : 2162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31374",
        "source" : "30410",
        "target" : "30186",
        "EdgeBetweenness" : 332.58921610658285,
        "shared_name" : "strange (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "strange (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31374,
        "BEND_MAP_ID" : 3423,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31372",
        "source" : "30408",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "western (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "western (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31372,
        "BEND_MAP_ID" : 2180,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31370",
        "source" : "30406",
        "target" : "30446",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "worldly (interacts with) vol-23",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "worldly (interacts with) vol-23",
        "interaction" : "interacts with",
        "SUID" : 31370,
        "BEND_MAP_ID" : 2186,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31368",
        "source" : "30402",
        "target" : "30404",
        "EdgeBetweenness" : 406.5819387928965,
        "shared_name" : "basic (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "basic (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31368,
        "BEND_MAP_ID" : 2200,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31366",
        "source" : "30402",
        "target" : "30226",
        "EdgeBetweenness" : 633.4092134906427,
        "shared_name" : "basic (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "basic (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31366,
        "BEND_MAP_ID" : 3175,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31364",
        "source" : "30400",
        "target" : "30404",
        "EdgeBetweenness" : 881.9999999999999,
        "shared_name" : "direct (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "direct (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31364,
        "BEND_MAP_ID" : 2212,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31362",
        "source" : "30398",
        "target" : "30404",
        "EdgeBetweenness" : 881.9999999999999,
        "shared_name" : "expeditionary (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "expeditionary (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31362,
        "BEND_MAP_ID" : 2218,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31360",
        "source" : "30396",
        "target" : "30404",
        "EdgeBetweenness" : 344.49782475093815,
        "shared_name" : "green (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "green (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31360,
        "BEND_MAP_ID" : 2233,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31358",
        "source" : "30396",
        "target" : "30330",
        "EdgeBetweenness" : 621.0663940116065,
        "shared_name" : "green (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "green (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31358,
        "BEND_MAP_ID" : 2582,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31356",
        "source" : "30394",
        "target" : "30404",
        "EdgeBetweenness" : 291.7996757531526,
        "shared_name" : "japanese (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "japanese (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31356,
        "BEND_MAP_ID" : 2242,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31354",
        "source" : "30394",
        "target" : "30246",
        "EdgeBetweenness" : 429.30389253721324,
        "shared_name" : "japanese (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "japanese (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31354,
        "BEND_MAP_ID" : 3077,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31352",
        "source" : "30394",
        "target" : "30186",
        "EdgeBetweenness" : 241.7941695637983,
        "shared_name" : "japanese (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "japanese (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31352,
        "BEND_MAP_ID" : 3399,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31350",
        "source" : "30394",
        "target" : "30174",
        "EdgeBetweenness" : 450.40212970004904,
        "shared_name" : "japanese (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "japanese (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31350,
        "BEND_MAP_ID" : 3515,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31348",
        "source" : "30394",
        "target" : "30144",
        "EdgeBetweenness" : 471.1781737281997,
        "shared_name" : "japanese (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "japanese (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31348,
        "BEND_MAP_ID" : 3712,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31346",
        "source" : "30392",
        "target" : "30404",
        "EdgeBetweenness" : 881.9999999999999,
        "shared_name" : "korean (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "korean (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31346,
        "BEND_MAP_ID" : 2248,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31344",
        "source" : "30390",
        "target" : "30404",
        "EdgeBetweenness" : 286.93004844406516,
        "shared_name" : "mysterious (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "mysterious (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31344,
        "BEND_MAP_ID" : 2260,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31342",
        "source" : "30390",
        "target" : "30144",
        "EdgeBetweenness" : 518.3515782746487,
        "shared_name" : "mysterious (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "mysterious (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31342,
        "BEND_MAP_ID" : 3733,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31340",
        "source" : "30390",
        "target" : "30064",
        "EdgeBetweenness" : 444.505771585178,
        "shared_name" : "mysterious (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "mysterious (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31340,
        "BEND_MAP_ID" : 4189,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31338",
        "source" : "30388",
        "target" : "30404",
        "EdgeBetweenness" : 881.9999999999999,
        "shared_name" : "suigun (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "suigun (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31338,
        "BEND_MAP_ID" : 2275,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31336",
        "source" : "30386",
        "target" : "30404",
        "EdgeBetweenness" : 481.7952278260969,
        "shared_name" : "unique (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "unique (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31336,
        "BEND_MAP_ID" : 2281,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31334",
        "source" : "30386",
        "target" : "30186",
        "EdgeBetweenness" : 452.3354969078294,
        "shared_name" : "unique (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "unique (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31334,
        "BEND_MAP_ID" : 3435,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31332",
        "source" : "30384",
        "target" : "30404",
        "EdgeBetweenness" : 390.03419615943915,
        "shared_name" : "weird (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "weird (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31332,
        "BEND_MAP_ID" : 2287,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31330",
        "source" : "30384",
        "target" : "30144",
        "EdgeBetweenness" : 583.4507515096881,
        "shared_name" : "weird (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 4,
        "name" : "weird (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31330,
        "BEND_MAP_ID" : 3802,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31328",
        "source" : "30384",
        "target" : "30078",
        "EdgeBetweenness" : 380.55610462463466,
        "shared_name" : "weird (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "weird (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 31328,
        "BEND_MAP_ID" : 4085,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31326",
        "source" : "30384",
        "target" : "30064",
        "EdgeBetweenness" : 496.41199111044523,
        "shared_name" : "weird (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "weird (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31326,
        "BEND_MAP_ID" : 4249,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31324",
        "source" : "30382",
        "target" : "30404",
        "EdgeBetweenness" : 881.9999999999999,
        "shared_name" : "widespread (interacts with) vol-22",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "widespread (interacts with) vol-22",
        "interaction" : "interacts with",
        "SUID" : 31324,
        "BEND_MAP_ID" : 2293,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31322",
        "source" : "30380",
        "target" : "30378",
        "EdgeBetweenness" : 594.1615761060475,
        "shared_name" : "17th (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "17th (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31322,
        "BEND_MAP_ID" : 2301,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31320",
        "source" : "30380",
        "target" : "30226",
        "EdgeBetweenness" : 487.5975257531556,
        "shared_name" : "17th (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "17th (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31320,
        "BEND_MAP_ID" : 3157,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31318",
        "source" : "30376",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "baroque (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "baroque (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31318,
        "BEND_MAP_ID" : 2310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31316",
        "source" : "30374",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "dang (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dang (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31316,
        "BEND_MAP_ID" : 2325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31314",
        "source" : "30372",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "dear (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dear (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31314,
        "BEND_MAP_ID" : 2331,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31312",
        "source" : "30370",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "dirty (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dirty (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31312,
        "BEND_MAP_ID" : 2340,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31310",
        "source" : "30368",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "editorial (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "editorial (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31310,
        "BEND_MAP_ID" : 2346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31308",
        "source" : "30366",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "enthusiastic (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "enthusiastic (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31308,
        "BEND_MAP_ID" : 2352,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31306",
        "source" : "30364",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "extravagant (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "extravagant (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31306,
        "BEND_MAP_ID" : 2358,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31304",
        "source" : "30362",
        "target" : "30378",
        "EdgeBetweenness" : 448.91426740865575,
        "shared_name" : "female (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "female (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31304,
        "BEND_MAP_ID" : 2364,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31302",
        "source" : "30362",
        "target" : "30246",
        "EdgeBetweenness" : 429.1449783231169,
        "shared_name" : "female (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "female (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31302,
        "BEND_MAP_ID" : 3050,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31300",
        "source" : "30362",
        "target" : "30144",
        "EdgeBetweenness" : 436.34570220309234,
        "shared_name" : "female (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "female (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31300,
        "BEND_MAP_ID" : 3685,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31298",
        "source" : "30360",
        "target" : "30378",
        "EdgeBetweenness" : 497.5371230573849,
        "shared_name" : "former (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "former (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31298,
        "BEND_MAP_ID" : 2370,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31296",
        "source" : "30360",
        "target" : "30330",
        "EdgeBetweenness" : 435.29470278390306,
        "shared_name" : "former (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "former (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31296,
        "BEND_MAP_ID" : 2573,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31294",
        "source" : "30360",
        "target" : "30064",
        "EdgeBetweenness" : 406.36522866656964,
        "shared_name" : "former (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "former (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31294,
        "BEND_MAP_ID" : 4150,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31292",
        "source" : "30358",
        "target" : "30378",
        "EdgeBetweenness" : 555.2838935008585,
        "shared_name" : "human (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "human (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31292,
        "BEND_MAP_ID" : 2388,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31290",
        "source" : "30358",
        "target" : "30268",
        "EdgeBetweenness" : 422.4725679352368,
        "shared_name" : "human (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "human (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31290,
        "BEND_MAP_ID" : 2907,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31288",
        "source" : "30356",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "impressed (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "impressed (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31288,
        "BEND_MAP_ID" : 2394,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31286",
        "source" : "30354",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "ostentatious (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ostentatious (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31286,
        "BEND_MAP_ID" : 2433,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31284",
        "source" : "30352",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "picky (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "picky (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31284,
        "BEND_MAP_ID" : 2445,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31282",
        "source" : "30350",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "prevalent (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "prevalent (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31282,
        "BEND_MAP_ID" : 2451,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31280",
        "source" : "30348",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "relentless (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "relentless (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31280,
        "BEND_MAP_ID" : 2463,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31278",
        "source" : "30346",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sacred (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sacred (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31278,
        "BEND_MAP_ID" : 2472,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31276",
        "source" : "30344",
        "target" : "30378",
        "EdgeBetweenness" : 537.6555149875344,
        "shared_name" : "scary (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "scary (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31276,
        "BEND_MAP_ID" : 2478,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31274",
        "source" : "30344",
        "target" : "30144",
        "EdgeBetweenness" : 513.0807483196292,
        "shared_name" : "scary (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "scary (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31274,
        "BEND_MAP_ID" : 3772,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31272",
        "source" : "30342",
        "target" : "30378",
        "EdgeBetweenness" : 427.0360006320418,
        "shared_name" : "secret (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "secret (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31272,
        "BEND_MAP_ID" : 2484,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31270",
        "source" : "30342",
        "target" : "30246",
        "EdgeBetweenness" : 392.4672857324869,
        "shared_name" : "secret (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "secret (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31270,
        "BEND_MAP_ID" : 3125,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31268",
        "source" : "30342",
        "target" : "30174",
        "EdgeBetweenness" : 436.6751406148246,
        "shared_name" : "secret (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "secret (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31268,
        "BEND_MAP_ID" : 3587,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31266",
        "source" : "30340",
        "target" : "30378",
        "EdgeBetweenness" : 667.2264138898952,
        "shared_name" : "simple (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "simple (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31266,
        "BEND_MAP_ID" : 2493,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31264",
        "source" : "30340",
        "target" : "30226",
        "EdgeBetweenness" : 749.7293049815227,
        "shared_name" : "simple (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "simple (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31264,
        "BEND_MAP_ID" : 3337,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31262",
        "source" : "30340",
        "target" : "30174",
        "EdgeBetweenness" : 575.4538993651564,
        "shared_name" : "simple (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "simple (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31262,
        "BEND_MAP_ID" : 3590,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31260",
        "source" : "30340",
        "target" : "30078",
        "EdgeBetweenness" : 673.6594503605107,
        "shared_name" : "simple (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "simple (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 31260,
        "BEND_MAP_ID" : 4073,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31258",
        "source" : "30340",
        "target" : "30064",
        "EdgeBetweenness" : 496.7785903579944,
        "shared_name" : "simple (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "simple (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31258,
        "BEND_MAP_ID" : 4240,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31256",
        "source" : "30338",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "tense (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "tense (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31256,
        "BEND_MAP_ID" : 2502,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31254",
        "source" : "30336",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "tootin (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "tootin (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31254,
        "BEND_MAP_ID" : 2508,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31252",
        "source" : "30334",
        "target" : "30378",
        "EdgeBetweenness" : 615.5892103126316,
        "shared_name" : "top (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "top (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31252,
        "BEND_MAP_ID" : 2514,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31250",
        "source" : "30334",
        "target" : "30120",
        "EdgeBetweenness" : 515.726138137403,
        "shared_name" : "top (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "top (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31250,
        "BEND_MAP_ID" : 4011,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31248",
        "source" : "30332",
        "target" : "30378",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "witted (interacts with) vol-20",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "witted (interacts with) vol-20",
        "interaction" : "interacts with",
        "SUID" : 31248,
        "BEND_MAP_ID" : 2523,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31246",
        "source" : "30328",
        "target" : "30330",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "boring (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "boring (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31246,
        "BEND_MAP_ID" : 2546,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31244",
        "source" : "30326",
        "target" : "30330",
        "EdgeBetweenness" : 488.2955038763532,
        "shared_name" : "current (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "current (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31244,
        "BEND_MAP_ID" : 2558,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31242",
        "source" : "30326",
        "target" : "30144",
        "EdgeBetweenness" : 516.5120988577548,
        "shared_name" : "current (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "current (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31242,
        "BEND_MAP_ID" : 3664,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31240",
        "source" : "30324",
        "target" : "30330",
        "EdgeBetweenness" : 375.97822695013326,
        "shared_name" : "large (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "large (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31240,
        "BEND_MAP_ID" : 2594,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31238",
        "source" : "30324",
        "target" : "30308",
        "EdgeBetweenness" : 386.4739032947966,
        "shared_name" : "large (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "large (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31238,
        "BEND_MAP_ID" : 2752,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31236",
        "source" : "30324",
        "target" : "30174",
        "EdgeBetweenness" : 485.1479186644105,
        "shared_name" : "large (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "large (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31236,
        "BEND_MAP_ID" : 3518,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31234",
        "source" : "30322",
        "target" : "30330",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "lonely (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "lonely (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31234,
        "BEND_MAP_ID" : 2606,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31232",
        "source" : "30320",
        "target" : "30330",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "most (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "most (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31232,
        "BEND_MAP_ID" : 2618,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31230",
        "source" : "30318",
        "target" : "30330",
        "EdgeBetweenness" : 536.7023236175056,
        "shared_name" : "orange (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "orange (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31230,
        "BEND_MAP_ID" : 2630,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31228",
        "source" : "30318",
        "target" : "30226",
        "EdgeBetweenness" : 483.67910033514306,
        "shared_name" : "orange (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 3,
        "name" : "orange (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31228,
        "BEND_MAP_ID" : 3274,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31226",
        "source" : "30316",
        "target" : "30330",
        "EdgeBetweenness" : 488.29550387635294,
        "shared_name" : "second (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "second (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31226,
        "BEND_MAP_ID" : 2645,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31224",
        "source" : "30316",
        "target" : "30144",
        "EdgeBetweenness" : 516.5120988577554,
        "shared_name" : "second (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "second (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31224,
        "BEND_MAP_ID" : 3775,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31222",
        "source" : "30314",
        "target" : "30330",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sober (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sober (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31222,
        "BEND_MAP_ID" : 2651,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31220",
        "source" : "30312",
        "target" : "30330",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "uhhhhhh (interacts with) vol-21",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "uhhhhhh (interacts with) vol-21",
        "interaction" : "interacts with",
        "SUID" : 31220,
        "BEND_MAP_ID" : 2675,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31218",
        "source" : "30310",
        "target" : "30308",
        "EdgeBetweenness" : 616.575408579011,
        "shared_name" : "american (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "american (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31218,
        "BEND_MAP_ID" : 2683,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31216",
        "source" : "30310",
        "target" : "30186",
        "EdgeBetweenness" : 380.35611660010676,
        "shared_name" : "american (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "american (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31216,
        "BEND_MAP_ID" : 3357,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31214",
        "source" : "30306",
        "target" : "30308",
        "EdgeBetweenness" : 451.60937225178407,
        "shared_name" : "dangerous (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dangerous (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31214,
        "BEND_MAP_ID" : 2695,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31212",
        "source" : "30306",
        "target" : "30268",
        "EdgeBetweenness" : 354.24532166899127,
        "shared_name" : "dangerous (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dangerous (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31212,
        "BEND_MAP_ID" : 2886,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31210",
        "source" : "30306",
        "target" : "30144",
        "EdgeBetweenness" : 536.9712394826298,
        "shared_name" : "dangerous (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dangerous (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31210,
        "BEND_MAP_ID" : 3670,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31208",
        "source" : "30304",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "english (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "english (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31208,
        "BEND_MAP_ID" : 2701,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31206",
        "source" : "30302",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "fast (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fast (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31206,
        "BEND_MAP_ID" : 2707,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31204",
        "source" : "30300",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "favourite (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "favourite (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31204,
        "BEND_MAP_ID" : 2713,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31202",
        "source" : "30298",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "floaty (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "floaty (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31202,
        "BEND_MAP_ID" : 2719,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31200",
        "source" : "30296",
        "target" : "30308",
        "EdgeBetweenness" : 615.8111503663231,
        "shared_name" : "fun (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fun (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31200,
        "BEND_MAP_ID" : 2725,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31198",
        "source" : "30296",
        "target" : "30120",
        "EdgeBetweenness" : 629.294008258288,
        "shared_name" : "fun (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "fun (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31198,
        "BEND_MAP_ID" : 3888,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31196",
        "source" : "30294",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "fuzzy (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "fuzzy (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31196,
        "BEND_MAP_ID" : 2731,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31194",
        "source" : "30292",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "honorific (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "honorific (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31194,
        "BEND_MAP_ID" : 2746,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31192",
        "source" : "30290",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "late (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "late (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31192,
        "BEND_MAP_ID" : 2758,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31190",
        "source" : "30288",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "massive (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "massive (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31190,
        "BEND_MAP_ID" : 2773,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31188",
        "source" : "30286",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "merry (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "merry (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31188,
        "BEND_MAP_ID" : 2779,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31186",
        "source" : "30284",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "near (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "near (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31186,
        "BEND_MAP_ID" : 2794,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31184",
        "source" : "30282",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "north (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "north (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31184,
        "BEND_MAP_ID" : 2803,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31182",
        "source" : "30280",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "related (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "related (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31182,
        "BEND_MAP_ID" : 2815,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31180",
        "source" : "30278",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "ro (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ro (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31180,
        "BEND_MAP_ID" : 2824,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31178",
        "source" : "30276",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "single (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "single (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31178,
        "BEND_MAP_ID" : 2836,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31176",
        "source" : "30274",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sumo (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sumo (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31176,
        "BEND_MAP_ID" : 2848,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31174",
        "source" : "30272",
        "target" : "30308",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "violent (interacts with) vol-25",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "violent (interacts with) vol-25",
        "interaction" : "interacts with",
        "SUID" : 31174,
        "BEND_MAP_ID" : 2860,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31172",
        "source" : "30270",
        "target" : "30268",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "8th (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "8th (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31172,
        "BEND_MAP_ID" : 2868,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31170",
        "source" : "30266",
        "target" : "30268",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "bloody (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "bloody (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31170,
        "BEND_MAP_ID" : 2880,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31168",
        "source" : "30264",
        "target" : "30268",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "fried (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fried (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31168,
        "BEND_MAP_ID" : 2895,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31166",
        "source" : "30262",
        "target" : "30268",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "possible (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "possible (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31166,
        "BEND_MAP_ID" : 2940,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31164",
        "source" : "30260",
        "target" : "30268",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sayeen (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sayeen (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31164,
        "BEND_MAP_ID" : 2952,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31162",
        "source" : "30258",
        "target" : "30268",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "slow (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "slow (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31162,
        "BEND_MAP_ID" : 2961,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31160",
        "source" : "30256",
        "target" : "30268",
        "EdgeBetweenness" : 334.05601110933327,
        "shared_name" : "special (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "special (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31160,
        "BEND_MAP_ID" : 2967,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31158",
        "source" : "30256",
        "target" : "30246",
        "EdgeBetweenness" : 413.79489623909853,
        "shared_name" : "special (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "special (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31158,
        "BEND_MAP_ID" : 3137,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31156",
        "source" : "30256",
        "target" : "30144",
        "EdgeBetweenness" : 449.6710104354943,
        "shared_name" : "special (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "special (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31156,
        "BEND_MAP_ID" : 3778,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31154",
        "source" : "30256",
        "target" : "30064",
        "EdgeBetweenness" : 391.87720381655237,
        "shared_name" : "special (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "special (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31154,
        "BEND_MAP_ID" : 4243,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31152",
        "source" : "30254",
        "target" : "30268",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "surprising (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "surprising (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31152,
        "BEND_MAP_ID" : 2973,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31150",
        "source" : "30252",
        "target" : "30268",
        "EdgeBetweenness" : 506.30732321856857,
        "shared_name" : "well (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "well (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31150,
        "BEND_MAP_ID" : 2979,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31148",
        "source" : "30252",
        "target" : "30174",
        "EdgeBetweenness" : 587.5727893899644,
        "shared_name" : "well (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "well (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31148,
        "BEND_MAP_ID" : 3623,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31146",
        "source" : "30252",
        "target" : "30078",
        "EdgeBetweenness" : 335.6500253999768,
        "shared_name" : "well (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "well (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 31146,
        "BEND_MAP_ID" : 4088,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31144",
        "source" : "30250",
        "target" : "30268",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "worried (interacts with) vol-19",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "worried (interacts with) vol-19",
        "interaction" : "interacts with",
        "SUID" : 31144,
        "BEND_MAP_ID" : 2985,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31142",
        "source" : "30248",
        "target" : "30246",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "MOST (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "MOST (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31142,
        "BEND_MAP_ID" : 2993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31140",
        "source" : "30244",
        "target" : "30246",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "actual (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "actual (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31140,
        "BEND_MAP_ID" : 2999,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31138",
        "source" : "30242",
        "target" : "30246",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "beloved (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "beloved (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31138,
        "BEND_MAP_ID" : 3008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31136",
        "source" : "30240",
        "target" : "30246",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "embarrassing (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "embarrassing (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31136,
        "BEND_MAP_ID" : 3041,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31134",
        "source" : "30238",
        "target" : "30246",
        "EdgeBetweenness" : 542.9698582671997,
        "shared_name" : "hilarious (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "hilarious (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31134,
        "BEND_MAP_ID" : 3062,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31132",
        "source" : "30238",
        "target" : "30064",
        "EdgeBetweenness" : 452.3988983467348,
        "shared_name" : "hilarious (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "hilarious (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31132,
        "BEND_MAP_ID" : 4162,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31130",
        "source" : "30236",
        "target" : "30246",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "incredible (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "incredible (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31130,
        "BEND_MAP_ID" : 3074,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31128",
        "source" : "30234",
        "target" : "30246",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "male (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "male (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31128,
        "BEND_MAP_ID" : 3089,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31126",
        "source" : "30232",
        "target" : "30246",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "mighty (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "mighty (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31126,
        "BEND_MAP_ID" : 3095,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31124",
        "source" : "30230",
        "target" : "30246",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "open (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "open (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31124,
        "BEND_MAP_ID" : 3113,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31122",
        "source" : "30228",
        "target" : "30246",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "unapologetic (interacts with) vol-18",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "unapologetic (interacts with) vol-18",
        "interaction" : "interacts with",
        "SUID" : 31122,
        "BEND_MAP_ID" : 3146,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31120",
        "source" : "30224",
        "target" : "30226",
        "EdgeBetweenness" : 503.6680612819158,
        "shared_name" : "armed (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "armed (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31120,
        "BEND_MAP_ID" : 3172,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31118",
        "source" : "30224",
        "target" : "30144",
        "EdgeBetweenness" : 583.5137387464597,
        "shared_name" : "armed (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "armed (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31118,
        "BEND_MAP_ID" : 3649,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31116",
        "source" : "30222",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "calm (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "calm (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31116,
        "BEND_MAP_ID" : 3184,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31114",
        "source" : "30220",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "clever (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "clever (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31114,
        "BEND_MAP_ID" : 3190,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31112",
        "source" : "30218",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "common (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "common (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31112,
        "BEND_MAP_ID" : 3199,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31110",
        "source" : "30216",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "drawn (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "drawn (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31110,
        "BEND_MAP_ID" : 3211,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31108",
        "source" : "30214",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "erotic (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "erotic (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31108,
        "BEND_MAP_ID" : 3223,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31106",
        "source" : "30212",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "instant (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "instant (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31106,
        "BEND_MAP_ID" : 3235,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31104",
        "source" : "30210",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "jealous (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "jealous (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31104,
        "BEND_MAP_ID" : 3244,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31102",
        "source" : "30208",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "major (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "major (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31102,
        "BEND_MAP_ID" : 3253,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31100",
        "source" : "30206",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "marine (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "marine (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31100,
        "BEND_MAP_ID" : 3262,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31098",
        "source" : "30204",
        "target" : "30226",
        "EdgeBetweenness" : 503.66806128191575,
        "shared_name" : "personal (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "personal (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31098,
        "BEND_MAP_ID" : 3286,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31096",
        "source" : "30204",
        "target" : "30144",
        "EdgeBetweenness" : 583.51373874646,
        "shared_name" : "personal (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "personal (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31096,
        "BEND_MAP_ID" : 3757,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31094",
        "source" : "30202",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "presumptuous (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "presumptuous (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31094,
        "BEND_MAP_ID" : 3292,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31092",
        "source" : "30200",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "private (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "private (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31092,
        "BEND_MAP_ID" : 3298,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31090",
        "source" : "30198",
        "target" : "30226",
        "EdgeBetweenness" : 524.8151347646307,
        "shared_name" : "proud (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "proud (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31090,
        "BEND_MAP_ID" : 3304,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31088",
        "source" : "30198",
        "target" : "30064",
        "EdgeBetweenness" : 531.8983564334235,
        "shared_name" : "proud (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "proud (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31088,
        "BEND_MAP_ID" : 4219,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31086",
        "source" : "30196",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "red (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "red (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31086,
        "BEND_MAP_ID" : 3310,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31084",
        "source" : "30194",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "regular (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "regular (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31084,
        "BEND_MAP_ID" : 3316,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31082",
        "source" : "30192",
        "target" : "30226",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "royalist (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "royalist (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31082,
        "BEND_MAP_ID" : 3325,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31080",
        "source" : "30190",
        "target" : "30226",
        "EdgeBetweenness" : 628.9020329645374,
        "shared_name" : "similar (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "similar (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31080,
        "BEND_MAP_ID" : 3334,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31078",
        "source" : "30190",
        "target" : "30120",
        "EdgeBetweenness" : 631.6909731765174,
        "shared_name" : "similar (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "similar (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31078,
        "BEND_MAP_ID" : 3975,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31076",
        "source" : "30188",
        "target" : "30226",
        "EdgeBetweenness" : 503.66806128191575,
        "shared_name" : "weekly (interacts with) vol-24",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "weekly (interacts with) vol-24",
        "interaction" : "interacts with",
        "SUID" : 31076,
        "BEND_MAP_ID" : 3346,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31074",
        "source" : "30188",
        "target" : "30144",
        "EdgeBetweenness" : 583.5137387464601,
        "shared_name" : "weekly (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "weekly (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31074,
        "BEND_MAP_ID" : 3799,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31072",
        "source" : "30184",
        "target" : "30186",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "few (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "few (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31072,
        "BEND_MAP_ID" : 3369,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31070",
        "source" : "30182",
        "target" : "30186",
        "EdgeBetweenness" : 278.6874518131775,
        "shared_name" : "french (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "french (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31070,
        "BEND_MAP_ID" : 3381,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31068",
        "source" : "30182",
        "target" : "30174",
        "EdgeBetweenness" : 670.3128267160166,
        "shared_name" : "french (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "french (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31068,
        "BEND_MAP_ID" : 3494,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31066",
        "source" : "30180",
        "target" : "30186",
        "EdgeBetweenness" : 363.77730655010953,
        "shared_name" : "interesting (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "interesting (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31066,
        "BEND_MAP_ID" : 3390,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31064",
        "source" : "30180",
        "target" : "30064",
        "EdgeBetweenness" : 616.6917688681428,
        "shared_name" : "interesting (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "interesting (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 31064,
        "BEND_MAP_ID" : 4171,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31062",
        "source" : "30178",
        "target" : "30186",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "international (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "international (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31062,
        "BEND_MAP_ID" : 3396,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31060",
        "source" : "30176",
        "target" : "30186",
        "EdgeBetweenness" : 405.64341049024375,
        "shared_name" : "silly (interacts with) vol-26",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "silly (interacts with) vol-26",
        "interaction" : "interacts with",
        "SUID" : 31060,
        "BEND_MAP_ID" : 3420,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31058",
        "source" : "30176",
        "target" : "30120",
        "EdgeBetweenness" : 644.3907185561045,
        "shared_name" : "silly (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "silly (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31058,
        "BEND_MAP_ID" : 3972,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31056",
        "source" : "30172",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "ashamed (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ashamed (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31056,
        "BEND_MAP_ID" : 3446,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31054",
        "source" : "30170",
        "target" : "30174",
        "EdgeBetweenness" : 822.8220042341843,
        "shared_name" : "black (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "black (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31054,
        "BEND_MAP_ID" : 3458,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31052",
        "source" : "30170",
        "target" : "30078",
        "EdgeBetweenness" : 221.97857051504317,
        "shared_name" : "black (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "black (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 31052,
        "BEND_MAP_ID" : 4034,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31050",
        "source" : "30168",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "careless (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "careless (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31050,
        "BEND_MAP_ID" : 3467,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31048",
        "source" : "30166",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "convinced (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "convinced (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31048,
        "BEND_MAP_ID" : 3476,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31046",
        "source" : "30164",
        "target" : "30174",
        "EdgeBetweenness" : 525.7845656780789,
        "shared_name" : "fake (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fake (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31046,
        "BEND_MAP_ID" : 3488,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31044",
        "source" : "30164",
        "target" : "30144",
        "EdgeBetweenness" : 465.7872636581976,
        "shared_name" : "fake (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fake (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31044,
        "BEND_MAP_ID" : 3682,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31042",
        "source" : "30164",
        "target" : "30120",
        "EdgeBetweenness" : 460.7396903577529,
        "shared_name" : "fake (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "fake (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31042,
        "BEND_MAP_ID" : 3882,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31040",
        "source" : "30162",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "horrible (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "horrible (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31040,
        "BEND_MAP_ID" : 3509,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31038",
        "source" : "30160",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "maximum (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "maximum (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31038,
        "BEND_MAP_ID" : 3536,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31036",
        "source" : "30158",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "opposite (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "opposite (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31036,
        "BEND_MAP_ID" : 3554,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31034",
        "source" : "30156",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "queenly (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "queenly (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31034,
        "BEND_MAP_ID" : 3566,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31032",
        "source" : "30154",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "rude (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "rude (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31032,
        "BEND_MAP_ID" : 3581,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31030",
        "source" : "30152",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "sisterly (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sisterly (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31030,
        "BEND_MAP_ID" : 3596,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31028",
        "source" : "30150",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "stuck (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "stuck (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31028,
        "BEND_MAP_ID" : 3602,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31026",
        "source" : "30148",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "traditional (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "traditional (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31026,
        "BEND_MAP_ID" : 3617,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31024",
        "source" : "30146",
        "target" : "30174",
        "EdgeBetweenness" : 882.0000000000002,
        "shared_name" : "wide (interacts with) vol-27",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "wide (interacts with) vol-27",
        "interaction" : "interacts with",
        "SUID" : 31024,
        "BEND_MAP_ID" : 3629,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31022",
        "source" : "30142",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "accurate (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "accurate (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31022,
        "BEND_MAP_ID" : 3646,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31020",
        "source" : "30140",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "brown (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "brown (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31020,
        "BEND_MAP_ID" : 3658,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31018",
        "source" : "30138",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "disgusting (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "disgusting (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31018,
        "BEND_MAP_ID" : 3676,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31016",
        "source" : "30136",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "handy (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "handy (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31016,
        "BEND_MAP_ID" : 3697,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31014",
        "source" : "30134",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "hungry (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "hungry (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31014,
        "BEND_MAP_ID" : 3706,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31012",
        "source" : "30132",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "key (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "key (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31012,
        "BEND_MAP_ID" : 3718,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31010",
        "source" : "30130",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "occasional (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "occasional (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31010,
        "BEND_MAP_ID" : 3742,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31008",
        "source" : "30128",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "relaxing (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "relaxing (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31008,
        "BEND_MAP_ID" : 3763,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31006",
        "source" : "30126",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "useful (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "useful (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31006,
        "BEND_MAP_ID" : 3790,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31004",
        "source" : "30124",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "various (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "various (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31004,
        "BEND_MAP_ID" : 3796,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31002",
        "source" : "30122",
        "target" : "30144",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "weirdo (interacts with) vol-6",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "weirdo (interacts with) vol-6",
        "interaction" : "interacts with",
        "SUID" : 31002,
        "BEND_MAP_ID" : 3808,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "31000",
        "source" : "30118",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "artistic (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "artistic (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 31000,
        "BEND_MAP_ID" : 3831,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30998",
        "source" : "30116",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "braided (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "braided (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30998,
        "BEND_MAP_ID" : 3840,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30996",
        "source" : "30114",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "broken (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "broken (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30996,
        "BEND_MAP_ID" : 3846,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30994",
        "source" : "30112",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "circular (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "circular (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30994,
        "BEND_MAP_ID" : 3858,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30992",
        "source" : "30110",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "clear (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "clear (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30992,
        "BEND_MAP_ID" : 3864,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30990",
        "source" : "30108",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "double (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "double (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30990,
        "BEND_MAP_ID" : 3870,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30988",
        "source" : "30106",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "dumb (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dumb (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30988,
        "BEND_MAP_ID" : 3876,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30986",
        "source" : "30104",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "funky (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "funky (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30986,
        "BEND_MAP_ID" : 3894,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30984",
        "source" : "30102",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "mad (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 2,
        "name" : "mad (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30984,
        "BEND_MAP_ID" : 3915,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30982",
        "source" : "30100",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "mammoth (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "mammoth (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30982,
        "BEND_MAP_ID" : 3921,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30980",
        "source" : "30098",
        "target" : "30120",
        "EdgeBetweenness" : 591.3769140601435,
        "shared_name" : "nervous (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "nervous (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30980,
        "BEND_MAP_ID" : 3933,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30978",
        "source" : "30098",
        "target" : "30064",
        "EdgeBetweenness" : 597.8352446513177,
        "shared_name" : "nervous (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "nervous (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30978,
        "BEND_MAP_ID" : 4192,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30976",
        "source" : "30096",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "ok (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "ok (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30976,
        "BEND_MAP_ID" : 3939,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30974",
        "source" : "30094",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "perfect (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "perfect (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30974,
        "BEND_MAP_ID" : 3951,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30972",
        "source" : "30092",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "powerful (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "powerful (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30972,
        "BEND_MAP_ID" : 3957,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30970",
        "source" : "30090",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "spanish (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "spanish (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30970,
        "BEND_MAP_ID" : 3981,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30968",
        "source" : "30088",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "strained (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "strained (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30968,
        "BEND_MAP_ID" : 3987,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30966",
        "source" : "30086",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "technical (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "technical (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30966,
        "BEND_MAP_ID" : 3993,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30964",
        "source" : "30084",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "tidal (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "tidal (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30964,
        "BEND_MAP_ID" : 4002,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30962",
        "source" : "30082",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "tired (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "tired (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30962,
        "BEND_MAP_ID" : 4008,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30960",
        "source" : "30080",
        "target" : "30120",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "valuable (interacts with) vol-7",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "valuable (interacts with) vol-7",
        "interaction" : "interacts with",
        "SUID" : 30960,
        "BEND_MAP_ID" : 4023,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30958",
        "source" : "30076",
        "target" : "30078",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "damn (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "damn (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 30958,
        "BEND_MAP_ID" : 4043,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30956",
        "source" : "30074",
        "target" : "30078",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "donnnn (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "donnnn (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 30956,
        "BEND_MAP_ID" : 4049,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30954",
        "source" : "30072",
        "target" : "30078",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "german (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "german (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 30954,
        "BEND_MAP_ID" : 4058,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30952",
        "source" : "30070",
        "target" : "30078",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "partial (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "partial (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 30952,
        "BEND_MAP_ID" : 4067,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30950",
        "source" : "30068",
        "target" : "30078",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sound (interacts with) vol-5",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sound (interacts with) vol-5",
        "interaction" : "interacts with",
        "SUID" : 30950,
        "BEND_MAP_ID" : 4082,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30948",
        "source" : "30066",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "Most (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "Most (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30948,
        "BEND_MAP_ID" : 4099,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30946",
        "source" : "30062",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "alive (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "alive (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30946,
        "BEND_MAP_ID" : 4105,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30944",
        "source" : "30060",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "axe (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "axe (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30944,
        "BEND_MAP_ID" : 4111,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30942",
        "source" : "30058",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "cruel (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "cruel (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30942,
        "BEND_MAP_ID" : 4126,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30940",
        "source" : "30056",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "d (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "d (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30940,
        "BEND_MAP_ID" : 4132,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30938",
        "source" : "30054",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "dead (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "dead (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30938,
        "BEND_MAP_ID" : 4138,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30936",
        "source" : "30052",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "disrespectful (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "disrespectful (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30936,
        "BEND_MAP_ID" : 4144,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30934",
        "source" : "30050",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "honest (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "honest (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30934,
        "BEND_MAP_ID" : 4168,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30932",
        "source" : "30048",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "painful (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "painful (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30932,
        "BEND_MAP_ID" : 4210,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30930",
        "source" : "30046",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "patient (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "patient (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30930,
        "BEND_MAP_ID" : 4216,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30928",
        "source" : "30044",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "secondary (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "secondary (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30928,
        "BEND_MAP_ID" : 4231,
        "selected" : false
      },
      "selected" : false
    }, {
      "data" : {
        "id" : "30926",
        "source" : "30042",
        "target" : "30064",
        "EdgeBetweenness" : 882.0,
        "shared_name" : "sharp (interacts with) vol-4",
        "shared_interaction" : "interacts with",
        "count" : 1,
        "name" : "sharp (interacts with) vol-4",
        "interaction" : "interacts with",
        "SUID" : 30926,
        "BEND_MAP_ID" : 4237,
        "selected" : false
      },
      "selected" : false
    } ]
  }
}}